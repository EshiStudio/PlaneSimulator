class_name PlayerShadow
extends Node3D

const SHADOW_SHADER := preload("res://shaders/player_shadow.gdshader")
const FLOOR_Y := 0.018
const MIN_ALPHA := 0.012

var shadow_plane: MeshInstance3D
var shadow_material: ShaderMaterial


func _ready() -> void:
	_build_shadow_plane()


func update_shadow(source_position: Vector3, sun_direction: Vector3, width: float, depth: float, alpha: float, lift_factor: float) -> void:
	_build_shadow_plane()

	var clamped_alpha := clampf(alpha, 0.0, 0.65)
	visible = clamped_alpha > MIN_ALPHA
	if not visible:
		return

	var ground_sun := Vector3(sun_direction.x, 0.0, sun_direction.z)
	var ground_sun_length := ground_sun.length()
	var shadow_offset := Vector3.ZERO
	if ground_sun_length > 0.001:
		var shadow_direction := -ground_sun / ground_sun_length
		var offset_strength := ground_sun_length * lerpf(0.200, 0.620, clampf(lift_factor, 0.0, 1.0))
		shadow_offset = shadow_direction * offset_strength

	var shadow_position := Vector3(source_position.x + shadow_offset.x, FLOOR_Y, source_position.z + shadow_offset.z)
	var basis := Basis().scaled(Vector3(maxf(width, 0.05), 1.0, maxf(depth, 0.05)))
	global_transform = Transform3D(basis, shadow_position)
	shadow_material.set_shader_parameter("shadow_color", Color(0.0, 0.0, 0.0, clamped_alpha))


func _build_shadow_plane() -> void:
	if shadow_plane != null:
		return

	var mesh := PlaneMesh.new()
	mesh.size = Vector2(1.0, 1.0)

	shadow_material = ShaderMaterial.new()
	shadow_material.shader = SHADOW_SHADER
	shadow_material.set_shader_parameter("shadow_color", Color(0.0, 0.0, 0.0, 0.28))

	shadow_plane = MeshInstance3D.new()
	shadow_plane.name = "ShadowPlane"
	shadow_plane.mesh = mesh
	shadow_plane.material_override = shadow_material
	shadow_plane.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(shadow_plane)
