class_name PlanetArchitectGenerator
extends RefCounted

const OPEN_SIMPLEX_NOISE_SCRIPT := preload("res://scripts/open_simplex_noise.gd")
const KD_TREE_SCRIPT := preload("res://scripts/kd_tree.gd")

# Ported from Planet Architect Lite v0.2.0 NewAssembly.dll:
# EarthlikeSettings, GenerateMesh, TectonicPlates, EarthlikePipeline,
# TerrainOutline, Climate, Noise, WaterChunk and GenerateTexture terrain draw.
const DEFAULT_SEED := 12345
const CHUNK_DIMENSIONS := 64
const MIN_QUAD_LEVEL := 2
const CHUNKS_PER_FACE_ROW := 1 << MIN_QUAD_LEVEL
const SPHERE_RADIUS := 6000.0
const WORLD_SCALE := 1.0
const PLANET_CENTER := Vector3(0.0, -SPHERE_RADIUS * WORLD_SCALE, 0.0)

const PLATE_POINT_COUNT := 2500
const MINOR_PLATE_COUNT := 3
const MAJOR_PLATE_COUNT := 10
const OCEANIC_PLATE_RATIO := 0.60
const MOVEMENT_ITERATIONS := 4
const TECTONIC_EDGE_WIDTH := 0.02
const OCEANIC_PLATE_WATER_AMOUNT := 0.10

const FLAT_WORLD := true
const GENERATE_WATER := false
const DEBUG_DISPLACE := true
const DEBUG_MOUNTAINS := false
const DEBUG_BIOME_COLORS := false
const DEBUG_FLAT := false
const WATER_CUTOFF := 0.50
const TERRAIN_HEIGHT_MULTIPLIER := 0.5
const HEIGHT_CURVE_AMPLITUDE := 1.0
const HEIGHT_CURVE_POWER := 1.00
const PLANET_WATER_SHADER := preload("res://shaders/planet_water.gdshader")
const PLANET_ATMOSPHERE_SHADER := preload("res://shaders/planet_atmosphere.gdshader")
const TECTONIC_MOUNTAINS_MAGNITUDE := 0.50
const MOUNTAIN_SMOOTHING_WIDTH := 0.20
const MIN_MOUNTAIN_CUTOFF := 0.20
const MAX_MOUNTAIN_CUTOFF := 0.40

const NOISE_SCALE := 0.35
const NOISE_OCTAVES := 4
const OCTAVE_PERSISTENCE := 0.50
const OCTAVE_LACUNARITY := 0.50

const BOUNDARY_NOISE_SCALE := 0.35
const BOUNDARY_NOISE_AMPLITUDE := 1.0

const MOUNTAIN_NOISE_SCALE := 0.20
const MOUNTAIN_NOISE_PERSISTENCE := 0.50
const MOUNTAIN_NOISE_LACUNARITY := 0.40
const MOUNTAIN_NOISE_OCTAVES := 3
const MOUNTAIN_RIDGE_SLOPE := 2.0
const MAX_RIDGE_INFLUENCE := 1.0
const RIDGE_HEIGHT_MULTIPLIER := 0.70

const PLANET_TILT := 23.0
const STAR_STRENGTH := 1.0
const TEMPERATURE_NOISE_SCALE := 0.12
const TEMPERATURE_NOISE_STRENGTH := 12.0
const TEMPERATURE_NOISE_OCTAVES := 2
const MINIMUM_PRECIPITATION_LATITUDE := 18.0
const PRECIPITATION_NOISE_SCALE := 0.30
const PRECIPITATION_NOISE_STRENGTH := 0.50
const ALTITUDE_TEMPERATURE_DROP_CONSTANT := 200.0

const BIOME_VORONOI_POINT_COUNT := 2000
const BIOME_TEMPERATURE_WEIGHT := 1.0
const RANDOMIZE_BIOME_VORONOI_AMOUNT := 0.0
const BIOME_CLEAR_ARTIFACT_ITERATIONS := 5
const BIOME_DOMAIN_WARP_STRENGTH := 0.05
const BIOME_DOMAIN_WARP_SCALE := 0.35
const BIOME_DOMAIN_WARP_OCTAVES := 3
const BIOME_DOMAIN_WARP_PERSISTENCE := 0.5
const BIOME_DOMAIN_WARP_LACUNARITY := 2.0
const BIOME_EDGE_WIDTH := 0.04

const FACE_NAMES := ["U", "D", "R", "L", "F", "B"]
const FACE_UPS := [
	Vector3.UP,
	Vector3.DOWN,
	Vector3.LEFT,
	Vector3.RIGHT,
	Vector3(0.0, 0.0, 1.0),
	Vector3(0.0, 0.0, -1.0),
]
const FACE_XS := [
	Vector3.RIGHT,
	Vector3.LEFT,
	Vector3.UP,
	Vector3.DOWN,
	Vector3.UP,
	Vector3.DOWN,
]
const FACE_YS := [
	Vector3(0.0, 0.0, 1.0),
	Vector3(0.0, 0.0, 1.0),
	Vector3(0.0, 0.0, 1.0),
	Vector3(0.0, 0.0, 1.0),
	Vector3.RIGHT,
	Vector3.RIGHT,
]

class DotNetRandom:
	const MBIG := 2147483647
	const MSEED := 161803398

	var _seed_array: Array[int] = []
	var _inext := 0
	var _inextp := 0

	func _init(seed_value: int):
		_seed_array.resize(56)
		var subtraction = abs(seed_value)
		var mj = MSEED - subtraction
		if mj < 0:
			mj += MBIG
		_seed_array[55] = mj
		var mk = 1
		for i in range(1, 55):
			var ii = (21 * i) % 55
			_seed_array[ii] = mk
			mk = mj - mk
			if mk < 0:
				mk += MBIG
			mj = _seed_array[ii]
		for k in 4:
			for i in range(1, 56):
				_seed_array[i] -= _seed_array[1 + (i + 30) % 55]
				if _seed_array[i] < 0:
					_seed_array[i] += MBIG
		_inext = 0
		_inextp = 21

	func internal_sample() -> int:
		_inext += 1
		if _inext >= 56:
			_inext = 1
		_inextp += 1
		if _inextp >= 56:
			_inextp = 1
		var ret = _seed_array[_inext] - _seed_array[_inextp]
		if ret == MBIG:
			ret -= 1
		if ret < 0:
			ret += MBIG
		_seed_array[_inext] = ret
		return ret

	func next_max(max_value: int) -> int:
		if max_value <= 0:
			return 0
		return int(floor(sample() * float(max_value)))

	func next_range(min_value: int, max_value: int) -> int:
		if max_value <= min_value:
			return min_value
		return min_value + next_max(max_value - min_value)

	func sample() -> float:
		return float(internal_sample()) * (1.0 / float(MBIG))


var seed := DEFAULT_SEED
var root: Node3D
var ground_visuals: Array[MeshInstance3D] = []
var water_visuals: Array[MeshInstance3D] = []
var _water_chunk_meshes: Array[Dictionary] = []
var tree_root: Node3D
var grass_root: Node3D

var _random: DotNetRandom
var _simplex
var _water_cutoff_normalized := 0.0
var _edge_width_cartesian := 0.0
var _tectonic_noise_offset := Vector3.ZERO

var _points: Array[Dictionary] = []
var _point_positions: Array[Vector3] = []
var _edge_point_positions: Array[Vector3] = []
var _edge_point_indices: Array[int] = []
var _plates: Array[Dictionary] = []
var _point_kd_tree
var _edge_kd_tree

var _terrain_offsets: Array = []
var _oceanic_values: Array[float] = []
var _terrain_amplitudes: Array[float] = []
var _terrain_scales: Array[float] = []
var _mountain_amplitudes: Array[float] = []
var _mountain_scales: Array[float] = []
var _ridge_plate_index := 0

var _temperature_noise_offset := Vector3.ZERO
var _precipitation_noise_offset := Vector3.ZERO
var _north_pole := Vector3.ZERO
var _inv_sphere_radius := 0.0
var _minimum_precipitation_latitude := 0.0
var _equator_temperature := 0.0
var _latitude_temperature_drop := 0.0
var _temperature_noise_amplitudes: Array[float] = []
var _temperature_noise_frequencies: Array[float] = []

var _biomes: Array[Dictionary] = []
var _biome_points: Array[Vector3] = []
var _biome_point_biome_indices: Array[int] = []
var _biome_edge_point_indices: Array[int] = []
var _biome_edge_positions: Array[Vector3] = []
var _biome_tree
var _biome_edge_tree
var _biome_temperature_scale := 1.0
var _biome_edge_search_radius := 0.0
var _biome_warp_offset_x := Vector3.ZERO
var _biome_warp_offset_y := Vector3.ZERO
var _biome_warp_offset_z := Vector3.ZERO
var _biome_warp_amplitudes: Array[float] = []
var _biome_warp_scales: Array[float] = []
var _biome_warp_amplitude_sum := 0.0
var _spawn_platform: StaticBody3D
var _spawn_flat := {}
var _cached_chunks: Array[Dictionary] = []
var _pole_ground_height := 0.0
var _pole_height_cached := false
var _main_qbuf: Dictionary = {}
const _CACHE_VERSION := 3


func _cache_path() -> String:
	return "user://planet_cache_d%d_m%d_b%d_f%d.bin" % [
		(1 if DEBUG_DISPLACE else 0),
		(1 if DEBUG_MOUNTAINS else 0),
		(1 if DEBUG_BIOME_COLORS else 0),
		(1 if DEBUG_FLAT else 0),
	]


func _new_qbuf() -> Dictionary:
	return {"n": [], "tp": PackedVector3Array(), "d": PackedFloat64Array()}


func _sphere_to_flat(v: Vector3) -> Vector3:
	# Gnomonic projection of the sphere around the north pole onto a flat
	# ground plane: radial height above the sphere becomes Y, the direction
	# from the pole is laid out on XZ. Player gravity (-Y) and the terrain
	# stay exactly as before, but the world reads as a flat plane to the
	# horizon instead of a giant sphere falling away below the player.
	var h := v.length() - SPHERE_RADIUS
	var dir := v / SPHERE_RADIUS
	var inv_y := 1.0 / maxf(dir.y, 0.001)
	return Vector3(dir.x * inv_y * SPHERE_RADIUS, h, dir.z * inv_y * SPHERE_RADIUS)


func _build_flat_grid() -> void:
	# Debug aid for the flat world: a visible grid on the ground so movement
	# and the flatness of the plane are readable at a glance.
	var grid := MeshInstance3D.new()
	grid.name = "FlatDebugGrid"
	var mesh := ImmediateMesh.new()
	var y := 0.05
	var half := 1000.0
	var fine_step := 20.0
	var major_step := 100.0
	var fine := Color(0.30, 0.30, 0.30, 0.8)
	var major := Color(0.55, 0.55, 0.55, 0.9)
	for step in [fine_step, major_step]:
		var c: Color = fine if step == fine_step else major
		var pos := -half
		while pos <= half:
			mesh.surface_begin(Mesh.PRIMITIVE_LINES)
			mesh.surface_set_color(c)
			mesh.surface_add_vertex(Vector3(pos, y, -half))
			mesh.surface_add_vertex(Vector3(pos, y, half))
			mesh.surface_set_color(c)
			mesh.surface_add_vertex(Vector3(-half, y, pos))
			mesh.surface_add_vertex(Vector3(half, y, pos))
			mesh.surface_end()
			pos += step
	grid.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true
	grid.material_override = mat
	root.add_child(grid)


func generate(parent: Node3D, collision_layer: int) -> Dictionary:
	var t0 := Time.get_ticks_msec()
	seed = _seed_from_args()
	ground_visuals.clear()
	water_visuals.clear()
	_water_chunk_meshes.clear()
	_cached_chunks.clear()

	root = Node3D.new()
	root.name = "GeographicPlanetWorld"
	parent.add_child(root)

	tree_root = Node3D.new()
	tree_root.name = "PlanetArchitectTrees"
	root.add_child(tree_root)
	grass_root = Node3D.new()
	grass_root.name = "PlanetArchitectGrass"
	root.add_child(grass_root)

	_build_flat_grid()

	if _try_load_cache(parent, collision_layer):
		print("[timing] cache_load=", Time.get_ticks_msec() - t0, "ms")
		print("[planet] spawn=", get_spawn_position())
		return _result_dict()

	_prepare_pipeline()
	print("[timing] pipeline=", Time.get_ticks_msec() - t0, "ms")
	_spawn_flat = _compute_spawn_flat() if DEBUG_FLAT else {}
	_pole_ground_height = get_ground_height(0.0, 0.0)
	_pole_height_cached = true
	_build_planet_faces(collision_layer, _spawn_flat)
	print("[timing] faces=", Time.get_ticks_msec() - t0, "ms")
	_build_water_nodes()
	print("[timing] water=", Time.get_ticks_msec() - t0, "ms")
	_build_atmosphere()
	print("[timing] atmosphere=", Time.get_ticks_msec() - t0, "ms")
	_add_spawn_platform(collision_layer)
	print("[timing] platform=", Time.get_ticks_msec() - t0, "ms")
	var spawn_land := _find_spawn_land()
	_spawn_flat = {
		"center_x": spawn_land.x,
		"center_z": spawn_land.z,
		"height": spawn_land.y,
	}
	_save_cache()
	var spawn := get_spawn_position()
	print("[planet] spawn=", spawn)
	print("[planet] land=", spawn_land, " sea_level=", (0.0 if FLAT_WORLD else PLANET_CENTER.y + SPHERE_RADIUS * WORLD_SCALE))
	for off in [[100.0, 0.0], [-100.0, 0.0], [0.0, 100.0], [0.0, -100.0]]:
		print("[planet] nearby=", get_ground_point(spawn_land.x + off[0], spawn_land.z + off[1]))

	return _result_dict()


func _result_dict() -> Dictionary:
	return {
		"root": root,
		"ground": ground_visuals[0] if ground_visuals.size() > 0 else null,
		"water": water_visuals[0] if water_visuals.size() > 0 else null,
		"trees": tree_root,
		"grass": grass_root,
		"seed": seed,
	}


func _save_cache() -> void:
	var payload := {
		"version": _CACHE_VERSION,
		"seed": seed,
		"spawn_flat": _spawn_flat,
		"pole_ground_height": _pole_ground_height,
		"chunks": _cached_chunks,
	}
	var bytes := var_to_bytes(payload)
	var f := FileAccess.open(_cache_path(), FileAccess.WRITE)
	if f == null:
		print("[cache] write failed: ", _cache_path())
		return
	f.store_32(bytes.size())
	f.store_buffer(bytes)
	print("[cache] saved ", bytes.size(), " bytes to ", _cache_path())


func _try_load_cache(parent: Node3D, collision_layer: int) -> bool:
	var f := FileAccess.open(_cache_path(), FileAccess.READ)
	if f == null:
		return false
	var size := f.get_32()
	var payload = bytes_to_var(f.get_buffer(size))
	if not (payload is Dictionary):
		return false
	if payload.get("version", -1) != _CACHE_VERSION or payload.get("seed", -1) != seed:
		print("[cache] version/seed mismatch, regenerating")
		return false
	_spawn_flat = payload.get("spawn_flat", {})
	_pole_ground_height = payload.get("pole_ground_height", 0.0)
	_pole_height_cached = true
	if _spawn_flat.is_empty():
		# Old caches have no spawn point; the pole height is still a real
		# ground height, so spawn above it instead of at y=0 (which would
		# hang the player over a pit on displaced terrain).
		_spawn_flat = {"center_x": 0.0, "center_z": 0.0, "height": _pole_ground_height}
	var chunks: Array = payload.get("chunks", [])
	if chunks.is_empty():
		return false

	var results: Array[Dictionary] = []
	results.resize(chunks.size())
	var thread_count := clampi(OS.get_processor_count() / 2, 1, 10)
	var per_thread := ceili(float(chunks.size()) / float(thread_count))
	var batch_specs: Array = []
	for t in thread_count:
		var start = t * per_thread
		var end = mini(start + per_thread, chunks.size())
		if start >= end:
			break
		var thread := Thread.new()
		thread.start(_cache_build_batch.bind(start, end, chunks))
		batch_specs.append([thread, start])
	for spec in batch_specs:
		var batch: Array = spec[0].wait_to_finish()
		var start_idx: int = spec[1]
		for k in batch.size():
			results[start_idx + k] = batch[k]

	var chunk_data: Array[Dictionary] = []
	for i in results.size():
		chunk_data.append(results[i])
	_attach_planet_nodes(collision_layer, chunk_data)
	_build_water_nodes()
	_build_atmosphere()
	_add_spawn_platform(collision_layer)
	return true


func _cache_build_batch(start: int, end: int, chunks: Array) -> Array:
	var batch: Array = []
	for i in range(start, end):
		var c: Dictionary = chunks[i]
		var mesh := ArrayMesh.new()
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, c["arrays"])
		var shape := ConcavePolygonShape3D.new()
		shape.set_faces(c["collision_faces"])
		batch.append({
			"name": c["name"],
			"water_name": c["water_name"],
			"arrays": c["arrays"],
			"collision_faces": c["collision_faces"],
			"has_water": c["has_water"],
			"water_arrays": c["water_arrays"],
			"mesh": mesh,
			"shape": shape,
		})
	return batch


func get_spawn_position() -> Vector3:
	if not _spawn_flat.is_empty():
		return Vector3(_spawn_flat["center_x"], _spawn_flat["height"] + 1.45, _spawn_flat["center_z"])
	var ground := _find_spawn_land()
	return ground + Vector3.UP * 1.45


func _compute_spawn_flat() -> Dictionary:
	# The pole region of this seed is mostly ocean and narrow ridges, so the
	# terrain is flattened into a pad at the chosen spawn point (world-down
	# gravity needs flat ground under the player). Sources: C# spawns on land
	# via PlayerController.ChooseStartingPosition (spherical gravity there).
	var point := _find_spawn_land()
	if point.y <= 0.3:
		return {}
	var height: float = point.y
	var offsets := [
		[40.0, 0.0], [-40.0, 0.0], [0.0, 40.0], [0.0, -40.0],
		[28.28, 28.28], [-28.28, 28.28], [28.28, -28.28], [-28.28, -28.28],
	]
	for off in offsets:
		height = maxf(height, get_ground_point(point.x + off[0], point.z + off[1]).y)
	var radius := 40.0
	return {
		"center_x": point.x,
		"center_z": point.z,
		"radius_sq": radius * radius,
		"height": height,
	}


func _find_spawn_land() -> Vector3:
	# sources: C# PlayerController.ChooseStartingPosition — spawn on land
	# (terrainOutlineNoiseValue > waterCutoffNormalized). This port keeps
	# world-down gravity, so flat land is searched on the top cap in a dense
	# spiral; the flattest candidate wins if nothing is gentle enough.
	var pole_point := get_ground_point(0.0, 0.0)
	if pole_point.y > 0.3 and _land_slope(pole_point) < 8.0:
		return pole_point
	var best := {}
	var ring_radius := 50.0
	while ring_radius < 3800.0:
		var steps := clampi(roundi(ring_radius / 60.0), 12, 48)
		for s in steps:
			var angle := TAU * float(s) / float(steps)
			var point := get_ground_point(cos(angle) * ring_radius, sin(angle) * ring_radius)
			if point.y <= 0.5:
				continue
			var slope := _land_slope(point)
			if slope < 10.0:
				return point
			if best.is_empty() or slope < best["slope"]:
				best = {"point": point, "slope": slope}
		ring_radius *= 1.35
	if not best.is_empty():
		return best["point"]
	return pole_point


func _land_slope(point: Vector3) -> float:
	var worst := 0.0
	for off in [[20.0, 0.0], [-20.0, 0.0], [0.0, 20.0], [0.0, -20.0]]:
		var h: float = get_ground_point(point.x + off[0], point.z + off[1]).y
		worst = maxf(worst, absf(h - point.y))
	return worst


func get_ground_point(x: float, z: float) -> Vector3:
	var top_radius = SPHERE_RADIUS * WORLD_SCALE
	var dir = Vector3(x, top_radius, z).normalized()
	if dir.length_squared() < 0.001:
		dir = Vector3.UP
	var terrain = _sample_point(dir * SPHERE_RADIUS)
	var pos: Vector3 = terrain["final_pos"] if DEBUG_DISPLACE else terrain["pos"]
	return _sphere_to_flat(pos) if FLAT_WORLD else (pos * WORLD_SCALE + PLANET_CENTER)


func get_ground_height(x: float, z: float) -> float:
	return get_ground_point(x, z).y


func _seed_from_args() -> int:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--planet-seed="):
			var value = arg.get_slice("=", 1)
			if value.is_valid_int():
				return int(value)
	return DEFAULT_SEED


func _prepare_pipeline() -> void:
	var t0 := Time.get_ticks_msec()
	_random = DotNetRandom.new(seed)
	_simplex = OPEN_SIMPLEX_NOISE_SCRIPT.new(seed)
	_water_cutoff_normalized = _normalize_water_cutoff(NOISE_OCTAVES, OCTAVE_PERSISTENCE, WATER_CUTOFF)
	_edge_width_cartesian = 5.0 * SPHERE_RADIUS * sin(TECTONIC_EDGE_WIDTH / 2.0)
	_tectonic_noise_offset = Vector3(_random.next_range(1000, 100000), _random.next_range(1000, 100000), _random.next_range(1000, 100000))
	_init_biomes()
	print("[timing] biomes=", Time.get_ticks_msec() - t0, "ms")
	_generate_tectonic_plates()
	print("[timing] tectonic=", Time.get_ticks_msec() - t0, "ms")
	_create_terrain_outline_offsets()
	print("[timing] outline=", Time.get_ticks_msec() - t0, "ms")
	_initialize_climate_values()
	print("[timing] climate=", Time.get_ticks_msec() - t0, "ms")


func _normalize_water_cutoff(octaves: int, persistence: float, water: float) -> float:
	var sum = float(octaves) if is_equal_approx(persistence, 1.0) else (1.0 - pow(persistence, octaves)) / (1.0 - persistence)
	return water * sum


func _build_planet_faces(collision_layer: int, flat: Dictionary = {}) -> void:
	# sources: C# ChunkManager.SmoothBorders (line 663-675)
	# Chunk mesh data is pure computation over read-only pipeline state, so chunks,
	# meshes and collision shapes are built in parallel worker threads. Borders are
	# smoothed on the main thread afterwards; the main thread only adds nodes.
	var t0 := Time.get_ticks_msec()
	var tasks: Array[Dictionary] = []
	for face_idx in (1 if FLAT_WORLD else 6):
		for chunk_i in CHUNKS_PER_FACE_ROW:
			for chunk_j in CHUNKS_PER_FACE_ROW:
				tasks.append({"face_idx": face_idx, "chunk_i": chunk_i, "chunk_j": chunk_j, "flat": flat})

	var results: Array[Dictionary] = []
	results.resize(tasks.size())
	var thread_count := clampi(OS.get_processor_count() / 2, 1, 10)
	var per_thread := ceili(float(tasks.size()) / float(thread_count))
	var batch_specs: Array = []
	for t in thread_count:
		var start = t * per_thread
		var end = mini(start + per_thread, tasks.size())
		if start >= end:
			break
		var thread := Thread.new()
		thread.start(_generate_chunk_batch.bind(start, end, tasks))
		batch_specs.append([thread, start])
	for spec in batch_specs:
		var batch: Array = spec[0].wait_to_finish()
		var start_idx: int = spec[1]
		for k in batch.size():
			results[start_idx + k] = batch[k]
	print("[timing] chunk_threads=", Time.get_ticks_msec() - t0, "ms")

	var chunk_data: Array[Dictionary] = []
	for i in results.size():
		var face: Dictionary = results[i]
		var t: Dictionary = tasks[i]
		var name := "PlanetArchitectFace%s_%s_%s" % [FACE_NAMES[t["face_idx"]], t["chunk_i"], t["chunk_j"]]
		chunk_data.append({
			"name": name,
			"water_name": "PlanetArchitectWaterFace%s_%s_%s" % [FACE_NAMES[t["face_idx"]], t["chunk_i"], t["chunk_j"]],
			"arrays": face["arrays"],
			"normals": face["arrays"][Mesh.ARRAY_NORMAL],
			"sphere_vertices": face["sphere_vertices"],
			"collision_faces": face["collision_faces"],
			"has_water": face["has_water"],
			"water_arrays": face["water_arrays"],
			"mesh": face["mesh"],
			"shape": face["shape"],
		})
		_cached_chunks.append({
			"name": name,
			"water_name": "PlanetArchitectWaterFace%s_%s_%s" % [FACE_NAMES[t["face_idx"]], t["chunk_i"], t["chunk_j"]],
			"arrays": face["arrays"],
			"collision_faces": face["collision_faces"],
			"has_water": face["has_water"],
			"water_arrays": face["water_arrays"],
		})

	_smooth_chunk_borders(chunk_data)
	print("[timing] smooth=", Time.get_ticks_msec() - t0, "ms")
	_attach_planet_nodes(collision_layer, chunk_data)
	print("[timing] node_add=", Time.get_ticks_msec() - t0, "ms")


func _attach_planet_nodes(collision_layer: int, chunk_data: Array[Dictionary]) -> void:
	var collision_body := StaticBody3D.new()
	collision_body.name = "PlanetGroundCollision"
	collision_body.collision_layer = collision_layer
	collision_body.collision_mask = 0
	root.add_child(collision_body)

	var material := StandardMaterial3D.new()
	material.vertex_color_use_as_albedo = true
	material.roughness = 0.92
	material.metallic = 0.0

	for data in chunk_data:
		var visual := MeshInstance3D.new()
		visual.name = data["name"]
		visual.mesh = data["mesh"]
		visual.material_override = material
		root.add_child(visual)
		ground_visuals.append(visual)

		var shape := CollisionShape3D.new()
		var concave := ConcavePolygonShape3D.new()
		concave.set_faces(data["collision_faces"])
		shape.shape = concave
		collision_body.add_child(shape)

		if data["has_water"]:
			_water_chunk_meshes.append({
				"name": data["water_name"],
				"arrays": data["water_arrays"],
			})


func _generate_face_mesh(face_idx: int, displaced: bool, chunks_per_row: int = 1, chunk_i: int = 0, chunk_j: int = 0, flat: Dictionary = {}, qbuf: Dictionary = {}) -> Dictionary:
	var dim = CHUNK_DIMENSIONS
	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var uvs := PackedVector2Array()
	var colors := PackedColorArray()
	var indices := PackedInt32Array()
	var collision_faces := PackedVector3Array()
	var sphere_vertices := PackedVector3Array()
	var water_vertices := PackedVector3Array()
	var water_normals := PackedVector3Array()
	var water_uvs := PackedVector2Array()
	var water_colors := PackedColorArray()
	var water_indices := PackedInt32Array()
	var points: Array[Dictionary] = []
	points.resize(dim * dim)
	var has_water := false

	var up: Vector3 = FACE_UPS[face_idx]
	var x_vec: Vector3 = FACE_XS[face_idx]
	var y_vec: Vector3 = FACE_YS[face_idx]
	var chunk_pos := Vector2(
		-1.0 + (float(chunk_i) * 2.0 + 1.0) / float(chunks_per_row),
		-1.0 + (float(chunk_j) * 2.0 + 1.0) / float(chunks_per_row)
	)
	var face_center = (up + x_vec * chunk_pos.x + y_vec * chunk_pos.y) * SPHERE_RADIUS
	var spacing = 2.0 * SPHERE_RADIUS / float(chunks_per_row * (dim - 1))
	var half = float(dim - 1) * 0.5

	for i in dim:
		var u = (float(i) - half) * spacing
		for j in dim:
			var v = (float(j) - half) * spacing
			var idx = i * dim + j
			var sphere_pos = (face_center + x_vec * u + y_vec * v).normalized() * SPHERE_RADIUS
			var point = _sample_point(sphere_pos, qbuf)
			points[idx] = point
			if point["terrain_outline_noise_value"] < _water_cutoff_normalized:
				has_water = true

	for i in dim:
		for j in dim:
			var idx = i * dim + j
			var point = points[idx]
			var final_pos: Vector3 = point["final_pos"] if displaced else point["pos"]
			var local_pos = _sphere_to_flat(final_pos) if FLAT_WORLD else (final_pos * WORLD_SCALE + PLANET_CENTER)
			var sphere_out: Vector3 = final_pos
			if not flat.is_empty():
				var dx: float = local_pos.x - float(flat["center_x"])
				var dz: float = local_pos.z - float(flat["center_z"])
				if dx * dx + dz * dz <= flat["radius_sq"]:
					local_pos.y = flat["height"]
			var water_pos: Vector3 = (_sphere_to_flat(point["pos"]) if FLAT_WORLD else (point["pos"] * WORLD_SCALE + PLANET_CENTER))
			vertices.append(local_pos)
			sphere_vertices.append(sphere_out)
			normals.append(Vector3.ZERO)
			uvs.append(Vector2(float(j) / float(dim), float(i) / float(dim)))
			colors.append(_terrain_outline_color(points, dim, i, j) if displaced else Color(0.16, 0.44, 0.20, 1.0))
			water_vertices.append(water_pos)
			water_normals.append(Vector3.UP if FLAT_WORLD else (water_pos - PLANET_CENTER).normalized())
			water_uvs.append(Vector2(float(j) / float(dim), float(i) / float(dim)))
			water_colors.append(Color(0.075, 0.27, 0.58, 0.46))
			if i < dim - 1 and j < dim - 1:
				var base = idx
				indices.append(base)
				indices.append(base + dim + 1)
				indices.append(base + dim)
				indices.append(base + dim + 1)
				indices.append(base)
				indices.append(base + 1)
				water_indices.append(base)
				water_indices.append(base + dim + 1)
				water_indices.append(base + dim)
				water_indices.append(base + dim + 1)
				water_indices.append(base)
				water_indices.append(base + 1)

	normals = _calculate_mesh_normals(vertices, indices)

	for k in range(0, indices.size(), 3):
		collision_faces.append(vertices[indices[k]])
		collision_faces.append(vertices[indices[k + 1]])
		collision_faces.append(vertices[indices[k + 2]])

	var arrays = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_INDEX] = indices

	var water_arrays = []
	water_arrays.resize(Mesh.ARRAY_MAX)
	water_arrays[Mesh.ARRAY_VERTEX] = water_vertices
	water_arrays[Mesh.ARRAY_NORMAL] = water_normals
	water_arrays[Mesh.ARRAY_TEX_UV] = water_uvs
	water_arrays[Mesh.ARRAY_COLOR] = water_colors
	water_arrays[Mesh.ARRAY_INDEX] = water_indices

	return {
		"arrays": arrays,
		"sphere_vertices": sphere_vertices,
		"collision_faces": collision_faces,
		"has_water": has_water,
		"water_arrays": water_arrays,
	}


func _generate_chunk_batch(start: int, end: int, tasks: Array) -> Array:
	var batch: Array = []
	var qbuf := _new_qbuf()
	for i in range(start, end):
		var t: Dictionary = tasks[i]
		var face: Dictionary = _generate_face_mesh(t["face_idx"], true, CHUNKS_PER_FACE_ROW, t["chunk_i"], t["chunk_j"], t["flat"], qbuf)
		var mesh := ArrayMesh.new()
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, face["arrays"])
		var shape := ConcavePolygonShape3D.new()
		shape.set_faces(face["collision_faces"])
		var out: Dictionary = face.duplicate()
		out["mesh"] = mesh
		out["shape"] = shape
		batch.append(out)
		print("[planet] chunk %d/%d generated" % [i + 1, tasks.size()])
	return batch


func _calculate_mesh_normals(vertices: PackedVector3Array, indices: PackedInt32Array) -> PackedVector3Array:
	var normals := PackedVector3Array()
	normals.resize(vertices.size())
	for i in normals.size():
		normals[i] = Vector3.ZERO

	for k in range(0, indices.size(), 3):
		var ia := indices[k]
		var ib := indices[k + 1]
		var ic := indices[k + 2]
		var face_normal := (vertices[ib] - vertices[ia]).cross(vertices[ic] - vertices[ia])
		if face_normal.length_squared() <= 0.0000001:
			continue
		face_normal = face_normal.normalized()
		normals[ia] = normals[ia] + face_normal
		normals[ib] = normals[ib] + face_normal
		normals[ic] = normals[ic] + face_normal

	for i in normals.size():
		# sources: C# MeshData.CalculateBaseNormals, line 47-73
		# C# computes Cross(lhs: v1-v0, rhs: v2-v0). GDScript earlier had the
		# operands reversed ((v2-v0).cross(v1-v0)), which inverted every terrain
		# normal toward the planet center and made mountains look like inverted
		# relief under the sun. Now matches the C# operand order.
		normals[i] = normals[i].normalized()
	return normals


func _smooth_chunk_borders(chunk_data: Array[Dictionary]) -> void:
	# sources: C# ChunkManager.SmoothBorders (line 663-675),
	# GenerateMesh.RegisterSharedVerticesBetween (line 114-180) and
	# GenerateMesh.RebuildChunkNormals (line 182-226)
	# C# keeps per-chunk meshes and does NOT merge vertices into a shared buffer.
	# Border vertices of adjacent chunks are matched by rounded position
	# (SharedVertexPrecision = 0.001, GenerateMesh.cs line 18) and each matched group
	# gets the average of the base normals written back into every chunk's working normals.
	var border_indices := _chunk_border_indices(CHUNK_DIMENSIONS)
	var border_map := {}
	for c in chunk_data.size():
		var sphere_vertices: PackedVector3Array = chunk_data[c]["sphere_vertices"]
		for idx in border_indices:
			var key = _rounded_vertex_key(sphere_vertices[idx])
			if not border_map.has(key):
				border_map[key] = []
			border_map[key].append([c, idx])
	for key in border_map:
		var group: Array = border_map[key]
		if group.size() < 2:
			continue
		var average := Vector3.ZERO
		for entry in group:
			average += chunk_data[entry[0]]["normals"][entry[1]]
		average = average.normalized()
		for entry in group:
			chunk_data[entry[0]]["normals"][entry[1]] = average


func _chunk_border_indices(dim: int) -> Array[int]:
	# sources: C# GenerateMesh.GetBorderIndices (line 90-112)
	var border: Array[int] = []
	for i in dim:
		var num = i * dim
		border.append(num)
		border.append(num + dim - 1)
	var num2 = (dim - 1) * dim
	for j in range(1, dim - 1):
		border.append(j)
		border.append(num2 + j)
	return border


func _rounded_vertex_key(pos: Vector3) -> String:
	# sources: C# GenerateMesh.RoundVector (line 253-257) with
	# SharedVertexPrecision = 0.001 (GenerateMesh.cs line 18)
	var inv := 1.0 / 0.001
	return "%d,%d,%d" % [roundi(pos.x * inv), roundi(pos.y * inv), roundi(pos.z * inv)]


func _build_water_nodes() -> void:
	# sources: C# RenderingManager.CreateWaterChunk, line 88-96
	# C# uses shader-based water materials (highResWater/lowResWater) with wave animation
	# GDScript was using StandardMaterial3D with flat vertex colors
	if not GENERATE_WATER:
		return
	if _water_chunk_meshes.is_empty():
		return
	var material := ShaderMaterial.new()
	material.shader = PLANET_WATER_SHADER
	material.set_shader_parameter("water_color", Color(0.04, 0.35, 0.72))
	material.set_shader_parameter("rim_color", Color(0.40, 0.82, 1.0))
	material.set_shader_parameter("alpha", 0.16)

	for water_chunk in _water_chunk_meshes:
		var mesh := ArrayMesh.new()
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, water_chunk["arrays"])
		var visual := MeshInstance3D.new()
		visual.name = water_chunk["name"]
		visual.mesh = mesh
		visual.material_override = material
		root.add_child(visual)
		water_visuals.append(visual)


func _generate_water_face_mesh(face_idx: int) -> Dictionary:
	var dim = CHUNK_DIMENSIONS
	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var colors := PackedColorArray()
	var indices := PackedInt32Array()
	var up: Vector3 = FACE_UPS[face_idx]
	var x_vec: Vector3 = FACE_XS[face_idx]
	var y_vec: Vector3 = FACE_YS[face_idx]
	var face_center = up * SPHERE_RADIUS
	var spacing = 2.0 * SPHERE_RADIUS / float(dim - 1)
	var half = float(dim - 1) * 0.5

	for i in dim:
		var u = (float(i) - half) * spacing
		for j in dim:
			var v = (float(j) - half) * spacing
			var idx = i * dim + j
			var sphere_pos = (face_center + x_vec * u + y_vec * v).normalized() * SPHERE_RADIUS
			vertices.append(sphere_pos * WORLD_SCALE + PLANET_CENTER)
			normals.append(sphere_pos.normalized())
			colors.append(Color(0.075, 0.27, 0.58, 0.46))
			if i < dim - 1 and j < dim - 1:
				indices.append(idx)
				indices.append(idx + dim + 1)
				indices.append(idx + dim)
				indices.append(idx + dim + 1)
				indices.append(idx)
				indices.append(idx + 1)

	var arrays = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_INDEX] = indices
	return {"arrays": arrays}


func _build_atmosphere() -> void:
	if FLAT_WORLD:
		return
	# sources: C# DayNightCycle.UpdateAtmosphereData, line 106-111
	# C# uses shader material with _SunDir, _MoonDir, _DayLengthInSeconds
	# GDScript was using StandardMaterial3D with fixed emission
	var atmosphere := MeshInstance3D.new()
	atmosphere.name = "PlanetArchitectAtmosphere"
	var mesh := SphereMesh.new()
	mesh.radius = SPHERE_RADIUS * WORLD_SCALE * 1.018
	mesh.height = mesh.radius * 2.0
	mesh.radial_segments = 96
	mesh.rings = 48
	atmosphere.mesh = mesh
	atmosphere.position = PLANET_CENTER
	var mat := ShaderMaterial.new()
	mat.shader = PLANET_ATMOSPHERE_SHADER
	mat.set_shader_parameter("sun_dir", Vector3(0.0, 1.0, 0.0))
	mat.set_shader_parameter("moon_dir", Vector3(0.0, 0.3, -0.9))
	mat.set_shader_parameter("day_length_in_seconds", 120.0)
	mat.set_shader_parameter("alpha", 0.18)
	atmosphere.material_override = mat
	root.add_child(atmosphere)


func _add_spawn_platform(collision_layer: int) -> void:
	if FLAT_WORLD:
		# On the flat world the terrain mesh itself is the floor; the old
		# boundary plane sits 2 cm below it and wedges the capsule in a
		# crack between the two surfaces, blocking all movement.
		return
	var spawn_y = (_pole_ground_height if _pole_height_cached else get_ground_height(0.0, 0.0)) - 0.02
	_spawn_platform = StaticBody3D.new()
	_spawn_platform.name = "SpawnPlatform"
	_spawn_platform.collision_layer = collision_layer
	_spawn_platform.collision_mask = 0
	root.add_child(_spawn_platform)
	var shape := CollisionShape3D.new()
	var boundary := WorldBoundaryShape3D.new()
	boundary.plane = Plane(Vector3.UP, spawn_y)
	shape.shape = boundary
	_spawn_platform.add_child(shape)


func _generate_tectonic_plates() -> void:
	_points.clear()
	_point_positions.clear()
	_edge_point_positions.clear()
	_edge_point_indices.clear()
	_plates.clear()
	_point_kd_tree = null
	_edge_kd_tree = null

	_random = DotNetRandom.new(seed)
	for i in MINOR_PLATE_COUNT + MAJOR_PLATE_COUNT:
		_plates.append({})

	var max_plate_size = roundi(float(PLATE_POINT_COUNT) / 150.0)
	_generate_tectonic_points(SPHERE_RADIUS, PLATE_POINT_COUNT)
	_random_move_points()
	for p in _points:
		_point_positions.append(p["world_pos"])
	_point_kd_tree = KD_TREE_SCRIPT.new(_point_positions)
	_generate_major_plates()
	for i in MOVEMENT_ITERATIONS:
		_randomize_shape()
	_clear_plate_artifacts()
	_choose_edge(3)
	_generate_minor_plates(max_plate_size)
	_choose_edge(9)
	_construct_edge_search_tree()
	_pick_oceanic_plates(OCEANIC_PLATE_RATIO)


func _generate_tectonic_points(radius: float, count: int) -> void:
	var positions = _generate_fibonacci_sphere(radius, count)
	for i in count:
		_points.append({
			"id": i,
			"world_pos": positions[i],
			"edge_point": false,
			"tectonic_plate": -1,
			"center_distance": INF,
		})


func _generate_plate(id: int, plate_type: int) -> Dictionary:
	var rng := DotNetRandom.new(seed + id)
	var color = Color.from_hsv(float(rng.next_max(10)) / 10.0, 0.6, 0.88)
	color *= float(rng.next_range(750, 1150)) / 1000.0
	color.r = clampf(color.r, 0.0, 1.0)
	color.g = clampf(color.g, 0.0, 1.0)
	color.b = clampf(color.b, 0.0, 1.0)
	return {
		"id": id,
		"plate_type": plate_type,
		"target_point_count": 1,
		"color": color,
		"self_points": [],
		"movement_direction": Vector3.ZERO,
		"is_oceanic": false,
		"rng": rng,
	}


func _generate_movement_dir(plate_id: int) -> void:
	var rng: DotNetRandom = _plates[plate_id]["rng"]
	var dir = Vector3(
		rng.next_range(-1000, 1001),
		rng.next_range(-1000, 1001),
		rng.next_range(-100, 1001)
	)
	_plates[plate_id]["movement_direction"] = dir.normalized()


func _generate_major_plates() -> void:
	var major_count = MAJOR_PLATE_COUNT
	var candidates = _generate_fibonacci_sphere(SPHERE_RADIUS, MAJOR_PLATE_COUNT + major_count)
	for i in major_count:
		candidates.remove_at(_random.next_range(0, candidates.size()))

	for j in MAJOR_PLATE_COUNT:
		var plate_id = j + MINOR_PLATE_COUNT
		_plates[plate_id] = _generate_plate(plate_id, 1)
		var closest_idx = _closest_point_index(candidates[j])
		_add_self_point(plate_id, closest_idx)
		_points[closest_idx]["tectonic_plate"] = plate_id
		_generate_movement_dir(plate_id)

	for plate_id in range(MINOR_PLATE_COUNT, MINOR_PLATE_COUNT + MAJOR_PLATE_COUNT):
		_populate_major_plate(plate_id)

	for p in _points:
		var plate_id: int = p["tectonic_plate"]
		if plate_id >= MINOR_PLATE_COUNT and not _plates[plate_id]["self_points"].has(p["id"]):
			_add_self_point(plate_id, p["id"])


func _populate_major_plate(plate_id: int) -> void:
	var center_id: int = _plates[plate_id]["self_points"][0]
	var center_pos: Vector3 = _points[center_id]["world_pos"]
	for i in _points.size():
		var dist = _points[i]["world_pos"].distance_squared_to(center_pos)
		if _points[i]["tectonic_plate"] == -1:
			_points[i]["tectonic_plate"] = plate_id
			_points[i]["center_distance"] = dist
		elif dist < _points[i]["center_distance"] and _points[i]["tectonic_plate"] >= MINOR_PLATE_COUNT:
			_points[i]["tectonic_plate"] = plate_id
			_points[i]["center_distance"] = dist


func _generate_minor_plates(max_size: int) -> void:
	var edge_points: Array[int] = []
	for i in _points.size():
		if _points[i]["edge_point"]:
			edge_points.append(i)

	for j in MINOR_PLATE_COUNT:
		_plates[j] = _generate_plate(j, 0)
		if edge_points.is_empty():
			continue
		var edge_list_index = _random.next_range(0, edge_points.size())
		var point_id = edge_points[edge_list_index]
		_add_self_point(j, point_id)
		_plates[j]["target_point_count"] = _random.next_range(3, max_size + 1)
		_remove_self_point(_points[point_id]["tectonic_plate"], point_id)
		_points[point_id]["tectonic_plate"] = j
		edge_points.remove_at(edge_list_index)

	for plate in _plates:
		_populate_minor_plate(plate["id"])


func _populate_minor_plate(plate_id: int) -> void:
	_generate_movement_dir(plate_id)
	while _plates[plate_id]["self_points"].size() < _plates[plate_id]["target_point_count"]:
		var centroid = Vector3.ZERO
		for point_id in _plates[plate_id]["self_points"]:
			centroid += _points[point_id]["world_pos"]
		centroid /= float(maxi(_plates[plate_id]["self_points"].size(), 1))

		var best_dist = INF
		var best_id = -1
		for i in _points.size():
			if _points[i]["tectonic_plate"] >= MINOR_PLATE_COUNT:
				var dist = centroid.distance_squared_to(_points[i]["world_pos"])
				if dist < best_dist:
					best_dist = dist
					best_id = i
		if best_id == -1:
			return
		_add_self_point(plate_id, best_id)
		_remove_self_point(_points[best_id]["tectonic_plate"], best_id)
		_points[best_id]["tectonic_plate"] = plate_id


func _randomize_shape() -> void:
	_choose_edge(5)
	for plate_id in range(MINOR_PLATE_COUNT, MINOR_PLATE_COUNT + MAJOR_PLATE_COUNT):
		var self_points: Array = _plates[plate_id]["self_points"]
		if self_points.is_empty():
			continue
		var tries = 0
		var list_index = 0
		while true:
			list_index = _random.next_range(0, self_points.size())
			tries += 1
			if tries > 20 or not _points[self_points[list_index]]["edge_point"]:
				break
		if tries > 20:
			continue

		var point_id: int = self_points[list_index]
		var distance_to_next = _get_distance_to_next_plate(plate_id, _points[point_id]["world_pos"])
		var amount = floori(sqrt(distance_to_next))
		if amount <= 0:
			continue
		var move = Vector3(
			_random.next_range(-amount, amount),
			_random.next_range(-amount, amount),
			_random.next_range(-amount, amount)
		)
		if move.length() < float(amount) * 0.5 and move.length_squared() > 0.0:
			move = move.normalized() * float(amount) * 0.5
		var target = (_points[point_id]["world_pos"] + move).normalized() * SPHERE_RADIUS
		for i in _points.size():
			if _points[i]["tectonic_plate"] != plate_id and _points[i]["world_pos"].distance_squared_to(target) < distance_to_next:
				_remove_self_point(_points[i]["tectonic_plate"], i)
				_add_self_point(plate_id, i)
				_points[i]["tectonic_plate"] = plate_id


func _clear_plate_artifacts() -> void:
	for i in _points.size():
		var counts := {}
		var strongest_count = 0
		var strongest_plate = -1
		var same_count = 5
		var neighbors = _k_nearest_point_indices(_points[i]["world_pos"], 5)
		for neighbor_id in neighbors:
			var other_plate: int = _points[neighbor_id]["tectonic_plate"]
			if other_plate != _points[i]["tectonic_plate"]:
				same_count -= 1
				counts[other_plate] = int(counts.get(other_plate, 0)) + 1
				if counts[other_plate] > strongest_count:
					strongest_plate = other_plate
					strongest_count = counts[other_plate]
		if same_count < 3 and strongest_plate >= 0:
			_remove_self_point(_points[i]["tectonic_plate"], i)
			_add_self_point(strongest_plate, i)
			_points[i]["tectonic_plate"] = strongest_plate


func _choose_edge(k: int) -> void:
	for i in _points.size():
		var current_plate: int = _points[i]["tectonic_plate"]
		var neighbors = _k_nearest_point_indices(_points[i]["world_pos"], k)
		_points[i]["edge_point"] = false
		for neighbor_id in neighbors:
			if _points[neighbor_id]["tectonic_plate"] != current_plate:
				_points[i]["edge_point"] = true
				break


func _construct_edge_search_tree() -> void:
	_edge_point_indices.clear()
	_edge_point_positions.clear()
	for i in _points.size():
		if _points[i]["edge_point"]:
			_edge_point_indices.append(i)
			_edge_point_positions.append(_points[i]["world_pos"])
	_edge_kd_tree = KD_TREE_SCRIPT.new(_edge_point_positions) if not _edge_point_positions.is_empty() else null


func _pick_oceanic_plates(ratio: float) -> void:
	var minor_oceanic = floori(ratio * float(MINOR_PLATE_COUNT))
	var major_oceanic = floori(ratio * float(MAJOR_PLATE_COUNT))
	var picked: Array[int] = []
	for i in minor_oceanic:
		var attempts = 0
		var plate_id = 0
		while true:
			plate_id = _random.next_range(0, MINOR_PLATE_COUNT)
			attempts += 1
			if not picked.has(plate_id) or attempts >= 30:
				break
		picked.append(plate_id)
		_plates[plate_id]["is_oceanic"] = true
	picked.clear()
	for i in major_oceanic:
		var attempts = 0
		var plate_id = MINOR_PLATE_COUNT
		while true:
			plate_id = _random.next_range(MINOR_PLATE_COUNT, MINOR_PLATE_COUNT + MAJOR_PLATE_COUNT)
			attempts += 1
			if not picked.has(plate_id) or attempts >= 30:
				break
		picked.append(plate_id)
		_plates[plate_id]["is_oceanic"] = true


func _random_move_points() -> void:
	var min_dist = INF
	for i in range(1, _points.size() - 1):
		min_dist = minf(min_dist, _points[i]["world_pos"].distance_squared_to(_points[0]["world_pos"]))
		min_dist = minf(min_dist, _points[i]["world_pos"].distance_squared_to(_points[_points.size() - 1]["world_pos"]))
	var amount = ceili(sqrt(min_dist) * 0.8)
	for i in _points.size():
		var pos: Vector3 = _points[i]["world_pos"]
		pos = (pos + Vector3(_random.next_range(0, amount), _random.next_range(0, amount), _random.next_range(0, amount))).normalized()
		_points[i]["world_pos"] = pos * SPHERE_RADIUS


func _create_terrain_outline_offsets() -> void:
	var random := DotNetRandom.new(seed)
	var plate_count = MINOR_PLATE_COUNT + MAJOR_PLATE_COUNT
	var octave_count = NOISE_OCTAVES + MOUNTAIN_NOISE_OCTAVES
	_terrain_offsets.clear()
	_oceanic_values.clear()
	_oceanic_values.resize(plate_count + 1)
	_ridge_plate_index = plate_count

	for i in plate_count + 1:
		var offsets: Array[Vector3] = []
		for j in octave_count:
			offsets.append(Vector3(random.next_range(1000, 100000), random.next_range(1000, 100000), random.next_range(1000, 100000)))
		_terrain_offsets.append(offsets)
		if i < plate_count:
			_oceanic_values[i] = float(random.next_range(700, 1300)) / 1000.0 * OCEANIC_PLATE_WATER_AMOUNT if _plates[i]["is_oceanic"] else 0.0

	_terrain_amplitudes.resize(octave_count)
	_terrain_scales.resize(octave_count)
	var amp = 1.0
	var freq = 1.0
	for k in octave_count:
		_terrain_amplitudes[k] = amp
		_terrain_scales[k] = NOISE_SCALE * freq * SPHERE_RADIUS
		amp *= OCTAVE_PERSISTENCE
		freq *= OCTAVE_LACUNARITY

	_mountain_amplitudes.resize(MOUNTAIN_NOISE_OCTAVES)
	_mountain_scales.resize(MOUNTAIN_NOISE_OCTAVES)
	amp = 1.0
	freq = 1.0
	for k in MOUNTAIN_NOISE_OCTAVES:
		_mountain_amplitudes[k] = amp
		_mountain_scales[k] = MOUNTAIN_NOISE_SCALE * freq * SPHERE_RADIUS
		amp *= MOUNTAIN_NOISE_PERSISTENCE
		freq *= MOUNTAIN_NOISE_LACUNARITY


func _initialize_climate_values() -> void:
	var random := DotNetRandom.new(seed)
	_temperature_noise_offset = Vector3(random.next_range(5555, 9999), 19999.0, 4444.0)
	_precipitation_noise_offset = Vector3(random.next_range(5555, 9999), 5555.0, 6666.0)
	var star = pow(STAR_STRENGTH, 0.25)
	# FLAT_WORLD: the playable map is the top cap of the sphere, which on a
	# real planet would be frozen polar climate. Tilt the climate axis 60 deg
	# away from the geometric pole so the map center sits at ~30N (warm
	# forests) and snow only appears at the far edge of the map.
	if FLAT_WORLD:
		_north_pole = Vector3(0.0, cos(deg_to_rad(60.0)), -sin(deg_to_rad(60.0)))
	else:
		_north_pole = Vector3(0.0, cos(deg_to_rad(PLANET_TILT)), sin(deg_to_rad(PLANET_TILT)))
	_inv_sphere_radius = 1.0 / SPHERE_RADIUS
	_minimum_precipitation_latitude = deg_to_rad(MINIMUM_PRECIPITATION_LATITUDE)
	_equator_temperature = 303.0 * star
	_latitude_temperature_drop = 40.0 * star
	_temperature_noise_amplitudes.resize(TEMPERATURE_NOISE_OCTAVES + 2)
	_temperature_noise_frequencies.resize(TEMPERATURE_NOISE_OCTAVES + 2)
	var amp = 1.0
	var freq = 1.0
	for i in _temperature_noise_amplitudes.size():
		_temperature_noise_amplitudes[i] = amp
		_temperature_noise_frequencies[i] = freq
		amp *= 0.5
		freq *= 0.4
	_initialize_biome_voronoi()


func _sample_point(pos: Vector3, qbuf: Dictionary = {}) -> Dictionary:
	if qbuf.is_empty():
		if _main_qbuf.is_empty():
			_main_qbuf = _new_qbuf()
		qbuf = _main_qbuf
	var point = _populate_point(pos, qbuf)
	point["terrain_outline_noise_value"] = _generate_terrain_outline(point)
	var height: float = (point["terrain_outline_noise_value"] - _water_cutoff_normalized) * TERRAIN_HEIGHT_MULTIPLIER
	var curve_val := HEIGHT_CURVE_AMPLITUDE * pow(maxf(absf(height), 0.0), HEIGHT_CURVE_POWER)
	height *= absf(curve_val)
	var final_pos = pos * (1.0 + height) if DEBUG_DISPLACE else pos
	point["final_pos"] = final_pos
	_generate_climate(point)
	point["is_underwater"] = point["terrain_outline_noise_value"] < _water_cutoff_normalized
	_apply_biome(point, null, qbuf)
	return point


func _populate_point(pos: Vector3, qbuf: Dictionary = {}) -> Dictionary:
	var point = {
		"pos": pos,
		"tectonic_plate": 0,
		"closest_distance": 0.0,
		"closest_point_id": -1,
		"plate_distances": {},
		"is_edge": false,
		"stress_value": 0.0,
		"polar_value": 0.0,
	}
	if _edge_point_positions.is_empty():
		return point

	var search_index = _closest_edge_search_index(pos, qbuf)
	var point_id = _edge_point_indices[search_index]
	point["tectonic_plate"] = _points[point_id]["tectonic_plate"]
	point["closest_distance"] = pos.distance_squared_to(_points[point_id]["world_pos"])
	point["closest_point_id"] = point_id

	var closest_points: Array[Dictionary] = []
	if point["closest_distance"] <= _edge_width_cartesian * _edge_width_cartesian:
		for edge_search_index in _radius_edge_search_indices(pos, _edge_width_cartesian):
			var other_id = _edge_point_indices[edge_search_index]
			if other_id != point_id:
				closest_points.append({
					"world_pos": _points[other_id]["world_pos"],
					"region_id": _points[other_id]["tectonic_plate"],
				})
	point["plate_distances"] = _compute_region_distances(
		pos,
		_points[point_id]["world_pos"],
		point["tectonic_plate"],
		closest_points,
		SPHERE_RADIUS,
		TECTONIC_EDGE_WIDTH
	)
	point["is_edge"] = point["plate_distances"].size() > 0
	if point["is_edge"]:
		_populate_edge_point(point)
	return point


func _populate_edge_point(point: Dictionary) -> void:
	var tangential = _get_tangential_movement(point["pos"], point["tectonic_plate"])
	var total = 0.0
	var strongest = -1.0
	var strongest_plate = point["tectonic_plate"]
	for plate_id in point["plate_distances"].keys():
		var t = 1.0 - float(point["plate_distances"][plate_id]) / TECTONIC_EDGE_WIDTH
		t = _smooth_zero_to_one_to_zero(t)
		total += t
		if t > strongest:
			strongest = t
			strongest_plate = int(plate_id)
	if total <= 0.0:
		return
	var dominance = (strongest / total - 0.5) / 0.5
	dominance = _smooth_zero_to_one_to_zero((dominance + 1.0) * 0.5)
	dominance = dominance * 2.0 - 1.0
	var other_tangential = _get_tangential_movement(point["pos"], strongest_plate)
	var dot_value = tangential.dot(other_tangential)
	var stress = dot_value * dot_value * -signf(dot_value) * strongest * dominance
	var owner_oceanic: bool = _plates[point["tectonic_plate"]]["is_oceanic"]
	var other_oceanic: bool = _plates[strongest_plate]["is_oceanic"]
	if not (owner_oceanic and other_oceanic):
		if not owner_oceanic and not other_oceanic:
			stress = stress * 0.5 if stress <= 0.0 else stress * 1.3
		else:
			stress = stress * -0.7 if stress <= 0.0 else stress * -1.0
	elif stress < 0.0:
		stress *= -0.7
	var boundary_noise = _noise3(point["pos"], _tectonic_noise_offset, BOUNDARY_NOISE_SCALE)
	boundary_noise = (boundary_noise - 0.5) * BOUNDARY_NOISE_AMPLITUDE + 0.5
	point["stress_value"] = stress * boundary_noise


func _generate_terrain_outline(point: Dictionary) -> float:
	var normalizer = _water_cutoff_normalized / WATER_CUTOFF
	var normalized_stress = TECTONIC_MOUNTAINS_MAGNITUDE / normalizer
	var terrain = _get_noise_for_point(point, 0, NOISE_OCTAVES, normalized_stress)
	if not DEBUG_MOUNTAINS:
		return terrain
	var ridge_influence = _unity_lerp(0.0, MAX_RIDGE_INFLUENCE, (terrain - _water_cutoff_normalized - MIN_MOUNTAIN_CUTOFF) / (MAX_MOUNTAIN_CUTOFF - MIN_MOUNTAIN_CUTOFF))
	var trench_influence = _unity_lerp(0.0, MAX_RIDGE_INFLUENCE, (_water_cutoff_normalized - 0.05 - terrain) / 0.35)
	if ridge_influence > 0.0:
		var noise_for_point = _get_noise_for_point(point, MOUNTAIN_NOISE_OCTAVES - 1, NOISE_OCTAVES + MOUNTAIN_NOISE_OCTAVES - 1, normalized_stress)
		var ridge = _generate_ridge_noise(point["pos"], 1.0)
		var target = _smooth_lerp(terrain, noise_for_point + ridge, ridge_influence)
		return terrain + (target - terrain) * RIDGE_HEIGHT_MULTIPLIER
	elif trench_influence > 0.0:
		var noise_for_point = _get_noise_for_point(point, NOISE_OCTAVES, NOISE_OCTAVES + MOUNTAIN_NOISE_OCTAVES - 1, normalized_stress)
		var ridge = _generate_ridge_noise(point["pos"], 2.0)
		return _smooth_lerp(terrain, terrain - noise_for_point - ridge, trench_influence * 0.4)
	return terrain


func _get_noise_for_point(point: Dictionary, start_octave: int, end_octave: int, normalized_stress_multiplier: float) -> float:
	var stress = point["stress_value"] * normalized_stress_multiplier
	if point["is_edge"]:
		return _generate_edge_noise(point, start_octave, end_octave, stress)
	return _generate_noise(point["pos"], point["tectonic_plate"], start_octave, end_octave, stress)


func _generate_noise(pos: Vector3, plate_id: int, first_octave: int, end_octave: int, stress: float) -> float:
	var value = 0.0
	for i in range(first_octave, end_octave):
		value += _noise3(pos, _terrain_offsets[plate_id][i], _terrain_scales[i]) * _terrain_amplitudes[i]
		if i == 0 and value > 0.5:
			value = -pow(value - 1.0, 2.0) + 0.75
		value += stress * _terrain_amplitudes[i]
	return value - _oceanic_values[plate_id]


func _generate_edge_noise(point: Dictionary, first_octave: int, end_octave: int, normalized_stress_value: float) -> float:
	var value = 0.0
	var weight = 1.0
	for plate_id in point["plate_distances"].keys():
		var t = 1.0 - float(point["plate_distances"][plate_id]) / TECTONIC_EDGE_WIDTH
		weight += t
		value += t * _generate_noise(point["pos"], int(plate_id), first_octave, end_octave, normalized_stress_value)
	value += _generate_noise(point["pos"], point["tectonic_plate"], first_octave, end_octave, normalized_stress_value)
	return value / weight


func _generate_ridge_noise(pos: Vector3, scale_multiplier: float) -> float:
	var value = 0.0
	for i in MOUNTAIN_NOISE_OCTAVES:
		var n = _noise3(pos, _terrain_offsets[_ridge_plate_index][i], _mountain_scales[i] * scale_multiplier) * _mountain_amplitudes[i]
		n = 1.0 - absf(2.0 * (n - 0.5))
		n = pow(n, MOUNTAIN_RIDGE_SLOPE) * (MOUNTAIN_RIDGE_SLOPE / 2.0 + 0.5)
		value += n
	return value


func _generate_climate(point: Dictionary) -> void:
	point["is_underwater"] = point["terrain_outline_noise_value"] < _water_cutoff_normalized
	var latitude = asin(point["pos"].dot(_north_pole) * _inv_sphere_radius)
	var temperature = _get_temperature(latitude, point["pos"], TEMPERATURE_NOISE_SCALE, TEMPERATURE_NOISE_STRENGTH, TEMPERATURE_NOISE_OCTAVES)
	var altitude = maxf(0.0, point["terrain_outline_noise_value"] - _water_cutoff_normalized - MIN_MOUNTAIN_CUTOFF - 0.01)
	altitude = pow(altitude, 1.5)
	var precipitation = _get_precipitation(latitude, point["pos"], _minimum_precipitation_latitude, 5.0, PRECIPITATION_NOISE_SCALE, PRECIPITATION_NOISE_STRENGTH, temperature)
	point["biome_precipitation"] = precipitation
	point["biome_temp"] = temperature
	temperature -= ALTITUDE_TEMPERATURE_DROP_CONSTANT * altitude
	temperature += _get_temperature_noise(point["pos"], TEMPERATURE_NOISE_SCALE / 2.0, TEMPERATURE_NOISE_STRENGTH * 3.0, TEMPERATURE_NOISE_OCTAVES + 2)
	point["temperature"] = temperature
	point["precipitation"] = precipitation


func _get_temperature(latitude: float, world_pos: Vector3, noise_scale: float, noise_strength: float, octaves: int) -> float:
	var s = sin(latitude)
	s *= s
	return _equator_temperature - _latitude_temperature_drop * s + _get_temperature_noise(world_pos, noise_scale, noise_strength, octaves) - 273.0


func _get_temperature_noise(world_pos: Vector3, noise_scale: float, noise_strength: float, octaves: int) -> float:
	var value = 0.0
	for i in octaves:
		var scale = noise_scale * _temperature_noise_frequencies[i] * SPHERE_RADIUS
		value += (_noise3(world_pos, _temperature_noise_offset, scale) - 0.5) * _temperature_noise_amplitudes[i]
	return value * noise_strength


func _get_precipitation(latitude: float, world_pos: Vector3, a: float, b: float, noise_scale: float, noise_strength: float, temp: float) -> float:
	var abs_lat = absf(latitude)
	var lat_ratio = abs_lat / a
	var value: float
	if abs_lat <= a:
		value = 1.0 - (3.0 * lat_ratio * lat_ratio - 2.0 * lat_ratio * lat_ratio * lat_ratio)
	else:
		var polar_ratio = (PI - 2.0 * abs_lat) / (PI - 2.0 * a)
		value = 1.0 - (3.0 * pow(polar_ratio, 2.0 * b) - 2.0 * pow(polar_ratio, 3.0 * b))
	value += (_noise3(world_pos, _precipitation_noise_offset, noise_scale * SPHERE_RADIUS) - 0.5) * 3.0 * noise_strength
	if temp < -10.0:
		value *= maxf(0.0, (temp + 10.0) / 10.0 + 0.8)
	elif temp < 50.0:
		value *= (temp + 10.0) / 150.0 + 0.8
	else:
		value *= maxf(0.0, (-temp + 60.0) / 10.0 + 0.2)
	return inverse_lerp(-0.4, 1.2, value)


func _apply_biome(point: Dictionary, copy_point = null, qbuf: Dictionary = {}) -> void:
	# sources: C# BiomeManager.PopulateBiomePoint, line 594-604
	# C# underwater points get biome from copyPoint (last non-underwater point processed in ring order)
	# GDScript was always assigning biome 0 (Ocean) for underwater points
	if point["is_underwater"]:
		if copy_point != null and not copy_point["is_underwater"]:
			_apply_biome_index(point, copy_point["biomes"][0] if copy_point["biomes"].size() > 0 else 0)
		else:
			_apply_biome_index(point, 0)
		return
	_populate_biome_point(point, qbuf)


func _closest_biome(temperature: float, precipitation: float) -> int:
	# sources: C# BiomeManager.GetClosestBiomeIndex, line 221-241
	# C# always multiplies temperature diff by biomeTemperatureScale
	# GDScript was conditionally using / 55.0 instead of the computed scale
	var best = 0
	var best_dist = INF
	for i in range(0, _biomes.size()):
		var biome = _biomes[i]
		for target in biome["targets"]:
			var dt = (temperature - target.x) * _biome_temperature_scale
			var dp = precipitation - target.y
			var dist = dt * dt + dp * dp
			if dist < best_dist:
				best_dist = dist
				best = i
	return best


func _initialize_biome_voronoi() -> void:
	_biome_points = _generate_fibonacci_sphere(SPHERE_RADIUS, BIOME_VORONOI_POINT_COUNT)
	_biome_point_biome_indices.clear()
	_biome_edge_point_indices.clear()
	_biome_edge_positions.clear()
	_biome_tree = null
	_biome_edge_tree = null
	_build_biome_warp_octaves()
	_biome_voronoi_random_move()

	var min_temp := INF
	var max_temp := -INF
	var temperatures: Array[float] = []
	var precipitations: Array[float] = []
	temperatures.resize(_biome_points.size())
	precipitations.resize(_biome_points.size())
	for i in _biome_points.size():
		var climate := _sample_biome_climate(_biome_points[i])
		var temp: float = climate.x
		var precipitation: float = climate.y
		temperatures[i] = temp
		precipitations[i] = precipitation
		min_temp = minf(min_temp, temp)
		max_temp = maxf(max_temp, temp)

	_biome_temperature_scale = BIOME_TEMPERATURE_WEIGHT / maxf(0.0001, max_temp - min_temp)
	_biome_point_biome_indices.resize(_biome_points.size())
	for i in _biome_points.size():
		_biome_point_biome_indices[i] = _closest_biome(temperatures[i], precipitations[i])

	_biome_tree = KD_TREE_SCRIPT.new(_biome_points)
	for i in BIOME_CLEAR_ARTIFACT_ITERATIONS:
		_clear_biome_artifacts()
	_construct_biome_edge_search_tree()
	_biome_edge_search_radius = 5.0 * SPHERE_RADIUS * sin(BIOME_EDGE_WIDTH / 2.0) if BIOME_EDGE_WIDTH > 0.0 else 0.0


func _build_biome_warp_octaves() -> void:
	var random := DotNetRandom.new(seed + 18273)
	_biome_warp_offset_x = Vector3(random.next_range(1000, 9999), random.next_range(1000, 9999), random.next_range(1000, 9999))
	_biome_warp_offset_y = Vector3(random.next_range(1000, 9999), random.next_range(1000, 9999), random.next_range(1000, 9999))
	_biome_warp_offset_z = Vector3(random.next_range(1000, 9999), random.next_range(1000, 9999), random.next_range(1000, 9999))
	_biome_warp_amplitudes.resize(BIOME_DOMAIN_WARP_OCTAVES)
	_biome_warp_scales.resize(BIOME_DOMAIN_WARP_OCTAVES)
	_biome_warp_amplitude_sum = 0.0
	var amp := 1.0
	var freq := 1.0
	for i in BIOME_DOMAIN_WARP_OCTAVES:
		_biome_warp_amplitudes[i] = amp
		_biome_warp_scales[i] = BIOME_DOMAIN_WARP_SCALE / freq * SPHERE_RADIUS
		_biome_warp_amplitude_sum += amp
		amp *= BIOME_DOMAIN_WARP_PERSISTENCE
		freq *= BIOME_DOMAIN_WARP_LACUNARITY


func _biome_voronoi_random_move() -> void:
	var random := DotNetRandom.new(seed)
	var amount := roundi(lerpf(0.0, 2.0 * SPHERE_RADIUS / sqrt(float(BIOME_VORONOI_POINT_COUNT)), RANDOMIZE_BIOME_VORONOI_AMOUNT))
	if amount <= 0:
		return
	for i in _biome_points.size():
		var pos = _biome_points[i] + Vector3(
			random.next_range(-amount, amount),
			random.next_range(-amount, amount),
			random.next_range(-amount, amount)
		)
		_biome_points[i] = pos.normalized() * SPHERE_RADIUS


func _sample_biome_climate(world_pos: Vector3) -> Vector2:
	var latitude = asin(world_pos.dot(_north_pole) * _inv_sphere_radius)
	var temperature = _get_temperature(latitude, world_pos, TEMPERATURE_NOISE_SCALE, TEMPERATURE_NOISE_STRENGTH, TEMPERATURE_NOISE_OCTAVES)
	var precipitation = _get_precipitation(latitude, world_pos, _minimum_precipitation_latitude, 5.0, PRECIPITATION_NOISE_SCALE, PRECIPITATION_NOISE_STRENGTH, temperature)
	return Vector2(temperature, precipitation)


func _clear_biome_artifacts() -> void:
	# sources: C# BiomeManager.ClearArtifacts, line 285-341
	# C# uses threshold 3 for normal biomes, 2 for rareBiome biomes
	# GDScript was always using threshold 3, missing rareBiome support
	if _biome_points.is_empty():
		return
	var next_indices: Array[int] = []
	for biome_index in _biome_point_biome_indices:
		next_indices.append(biome_index)
	var search_count = mini(8, _biome_points.size())
	for i in _biome_points.size():
		var owner_biome: int = _biome_point_biome_indices[i]
		var same_count := 0
		var strongest_biome := -1
		var strongest_count := 0
		var counts := {}
		var neighbors = _k_nearest_biome_indices(_biome_points[i], search_count)
		for neighbor_id in neighbors:
			if neighbor_id == i:
				continue
			var other_biome: int = _biome_point_biome_indices[neighbor_id]
			if other_biome == owner_biome:
				same_count += 1
			else:
				counts[other_biome] = int(counts.get(other_biome, 0)) + 1
				if counts[other_biome] > strongest_count:
					strongest_count = counts[other_biome]
					strongest_biome = other_biome
		var threshold := 3
		if owner_biome >= 0 and owner_biome < _biomes.size() and _biomes[owner_biome]["rareBiome"]:
			threshold = 2
		if same_count < threshold and strongest_biome != -1:
			next_indices[i] = strongest_biome
	_biome_point_biome_indices = next_indices


func _construct_biome_edge_search_tree() -> void:
	_biome_edge_point_indices.clear()
	_biome_edge_positions.clear()
	var search_count = mini(9, _biome_points.size())
	for i in _biome_points.size():
		if _is_biome_edge_point(i, search_count):
			_biome_edge_point_indices.append(i)
			_biome_edge_positions.append(_biome_points[i])
	_biome_edge_tree = KD_TREE_SCRIPT.new(_biome_edge_positions) if not _biome_edge_positions.is_empty() else null


func _is_biome_edge_point(point_index: int, search_count: int) -> bool:
	var owner_biome: int = _biome_point_biome_indices[point_index]
	var neighbors = _k_nearest_biome_indices(_biome_points[point_index], search_count)
	for neighbor_id in neighbors:
		if neighbor_id != point_index and _biome_point_biome_indices[neighbor_id] != owner_biome:
			return true
	return false


func _populate_biome_point(point: Dictionary, qbuf: Dictionary = {}) -> void:
	if _biome_edge_tree == null or _biome_edge_point_indices.is_empty():
		_apply_biome_index(point, _biome_point_biome_indices[0] if not _biome_point_biome_indices.is_empty() else 0)
		return

	var warped_pos = _get_warped_biome_pos(point["pos"])
	var edge_search_index: int = _biome_edge_tree.closest_point(warped_pos, qbuf)
	var owner_point_id: int = _biome_edge_point_indices[edge_search_index]
	var owner_biome: int = _biome_point_biome_indices[owner_point_id]
	var owner_pos: Vector3 = _biome_points[owner_point_id]
	if _biome_edge_search_radius <= 0.0:
		_apply_biome_index(point, owner_biome)
		return

	var search_radius = sqrt(warped_pos.distance_squared_to(owner_pos)) + _biome_edge_search_radius
	var edge_indices: Array[int] = _biome_edge_tree.radius(warped_pos, search_radius)
	var closest_points: Array[Dictionary] = []
	var has_different_biome := false
	for edge_index in edge_indices:
		var point_id: int = _biome_edge_point_indices[edge_index]
		if point_id == owner_point_id:
			continue
		var biome_index: int = _biome_point_biome_indices[point_id]
		if biome_index != owner_biome:
			has_different_biome = true
		closest_points.append({
			"world_pos": _biome_points[point_id],
			"region_id": biome_index,
		})
	if not has_different_biome:
		_apply_biome_index(point, owner_biome)
		return

	var distances = _compute_region_distances(warped_pos, owner_pos, owner_biome, closest_points, SPHERE_RADIUS, BIOME_EDGE_WIDTH)
	_apply_biome_blend(point, owner_biome, distances)


func _apply_biome_index(point: Dictionary, biome_index: int) -> void:
	point["biomes"] = [clampi(biome_index, 0, _biomes.size() - 1)]
	point["biome_distances"] = [1.0]
	point["biome_edge_distance"] = INF
	point["is_biome_edge"] = false
	point["polar_value"] = 0.0


func _apply_biome_blend(point: Dictionary, owner_biome: int, biome_distances: Dictionary) -> void:
	_apply_biome_index(point, owner_biome)
	var total := 1.0
	var closest_edge := INF
	var is_edge := false
	for biome_index in biome_distances.keys():
		if BIOME_EDGE_WIDTH <= 0.0:
			continue
		var distance: float = biome_distances[biome_index]
		closest_edge = minf(closest_edge, distance)
		is_edge = true
		var smoothed = _smooth_zero_to_one_to_zero(0.5 + 0.5 * distance / BIOME_EDGE_WIDTH)
		if smoothed <= 0.00001:
			continue
		var weight = (1.0 - smoothed) / smoothed
		if weight <= 0.0:
			continue
		point["biomes"].append(clampi(int(biome_index), 0, _biomes.size() - 1))
		point["biome_distances"].append(weight)
		total += weight
	for i in point["biome_distances"].size():
		point["biome_distances"][i] = float(point["biome_distances"][i]) / total
	point["biome_edge_distance"] = closest_edge
	point["is_biome_edge"] = is_edge


func _get_warped_biome_pos(pos: Vector3) -> Vector3:
	if BIOME_DOMAIN_WARP_STRENGTH <= 0.0 or BIOME_DOMAIN_WARP_OCTAVES <= 0:
		return pos
	var amount = BIOME_DOMAIN_WARP_STRENGTH * SPHERE_RADIUS
	var x = _get_biome_warp_noise(pos, _biome_warp_offset_x)
	var y = _get_biome_warp_noise(pos, _biome_warp_offset_y)
	var z = _get_biome_warp_noise(pos, _biome_warp_offset_z)
	return (pos + Vector3(x, y, z) * amount).normalized() * SPHERE_RADIUS


func _get_biome_warp_noise(pos: Vector3, offset: Vector3) -> float:
	var value := 0.0
	for i in _biome_warp_amplitudes.size():
		var n = (_noise3(pos, offset, _biome_warp_scales[i]) - 0.5) * 2.0
		value += n * _biome_warp_amplitudes[i]
	if _biome_warp_amplitude_sum > 0.0:
		value /= _biome_warp_amplitude_sum
	return value


func _terrain_outline_color(points: Array[Dictionary], width: int, x: int, y: int) -> Color:
	var point = points[x * width + y]
	if not DEBUG_BIOME_COLORS:
		var h: float = point["terrain_outline_noise_value"] - _water_cutoff_normalized
		if h < 0.0:
			return Color(0.10, 0.35, 0.75).lerp(Color(0.01, 0.05, 0.1), clampf(-h * 2.0, 0.0, 1.0))
		return Color(0.30, 0.45, 0.22).lerp(Color(0.72, 0.68, 0.62), clampf(h * 2.0, 0.0, 1.0))
	var sand = Color(0.9339, 0.8044, 0.3656)
	var shallow = Color(0.2, 0.5, 0.75)
	var ocean = Color(0.1, 0.35, 0.75)
	var deep = Color(0.01, 0.05, 0.1)
	var rock = Color(0.43, 0.38, 0.36)
	var snow = Color(0.933, 0.933, 0.933)
	var shallow_width = 0.07
	var derivative_snow_cutoff = 1.3
	var snow_temp = -8.5
	var terrain = point["terrain_outline_noise_value"] + point["polar_value"]
	if terrain < _water_cutoff_normalized:
		var depth = _water_cutoff_normalized - terrain
		var water_color: Color
		if depth < 0.02:
			water_color = sand.lerp(shallow, depth * 50.0)
		elif depth < shallow_width:
			water_color = shallow.lerp(ocean, (depth - 0.02) / (shallow_width - 0.02))
		else:
			water_color = ocean.lerp(deep, (depth - shallow_width) * 1.3)
		return sand.lerp(water_color, 0.3)
	var height = terrain - _water_cutoff_normalized
	var biome_color = _get_biome_color(point)
	if height < MIN_MOUNTAIN_CUTOFF:
		if height < 0.015:
			biome_color = sand.lerp(biome_color, (height - 0.01) * 200.0)
		return biome_color
	var derivative = _calculate_derivative(points, width, x, y)
	var mountain_color = biome_color.lerp(rock, height / MOUNTAIN_SMOOTHING_WIDTH)
	var snow_color = biome_color.lerp(snow, (snow_temp - point["temperature"]) / 2.0)
	return snow_color.lerp(mountain_color, (derivative - derivative_snow_cutoff) * 3.0)


func _calculate_derivative(points: Array[Dictionary], width: int, x: int, y: int) -> float:
	var idx = x * width + y
	var point = points[idx]
	var x_idx = (x - 1) * width + y if x > 0 else (x + 1) * width + y
	var y_idx = x * width + (y - 1) if y > 0 else x * width + (y + 1)
	var p0: Vector3 = point["final_pos"]
	var px: Vector3 = points[x_idx]["final_pos"]
	var py: Vector3 = points[y_idx]["final_pos"]
	var dx_den = (px.normalized() * p0.length()).distance_to(p0)
	var dy_den = (py.normalized() * p0.length()).distance_to(p0)
	var dx = 0.0 if dx_den <= 0.00001 else (px.length() - p0.length()) / dx_den
	var dy = 0.0 if dy_den <= 0.00001 else (py.length() - p0.length()) / dy_den
	return sqrt(dx * dx + dy * dy)


func _get_biome_color(point: Dictionary) -> Color:
	if point["is_underwater"]:
		return _biomes[0]["color"]
	var color = Color.BLACK
	var weight = 0.0
	for i in point["biomes"].size():
		var biome_index: int = point["biomes"][i]
		var w: float = point["biome_distances"][i]
		color += _biomes[biome_index]["color"] * w
		weight += w
	if weight > 0.0:
		return color / weight
	return _biomes[0]["color"]


func _init_biomes() -> void:
	_biomes = [
		{"id": 0, "name": "Ocean", "color": Color(0.10, 0.35, 0.75), "targets": [Vector2(0.0, 0.0)], "rareBiome": false},
		{"id": 1, "name": "TropicalRainforest", "color": Color(0.03, 0.42, 0.12), "targets": [Vector2(28.0, 0.92)], "rareBiome": false},
		{"id": 2, "name": "Savanna", "color": Color(0.58, 0.55, 0.22), "targets": [Vector2(27.0, 0.34)], "rareBiome": false},
		{"id": 3, "name": "Desert", "color": Color(0.78, 0.61, 0.32), "targets": [Vector2(31.0, 0.08)], "rareBiome": false},
		{"id": 4, "name": "Steppe", "color": Color(0.45, 0.53, 0.24), "targets": [Vector2(16.0, 0.26)], "rareBiome": false},
		{"id": 5, "name": "Continental", "color": Color(0.18, 0.43, 0.18), "targets": [Vector2(14.0, 0.55)], "rareBiome": false},
		{"id": 6, "name": "TemperateRainforest", "color": Color(0.07, 0.35, 0.20), "targets": [Vector2(12.0, 0.86)], "rareBiome": false},
		{"id": 7, "name": "Tundra", "color": Color(0.48, 0.52, 0.46), "targets": [Vector2(-8.0, 0.40)], "rareBiome": false},
		{"id": 8, "name": "Swamp", "color": Color(0.10, 0.28, 0.15), "targets": [Vector2(22.0, 0.72)], "rareBiome": false},
	]


func _compute_region_distances(pos: Vector3, owner_point: Vector3, owner_region: int, nearby_points: Array[Dictionary], sphere_radius: float, edge_width: float) -> Dictionary:
	var region_distances := {}
	if nearby_points.is_empty() or edge_width <= 0.0:
		return region_distances
	var sin_edge_width = sin(edge_width)
	for nearby in nearby_points:
		var region_id: int = nearby["region_id"]
		if region_id == owner_region:
			continue
		var distance = _get_distance_from_edge(pos, owner_point, nearby["world_pos"], region_id, nearby_points, sphere_radius, sin_edge_width)
		if distance < edge_width and (not region_distances.has(region_id) or region_distances[region_id] > distance):
			region_distances[region_id] = distance
	return region_distances


func _get_distance_from_edge(pos: Vector3, same_region_point: Vector3, other_point: Vector3, other_region: int, nearby_points: Array[Dictionary], sphere_radius: float, sin_edge_width: float) -> float:
	var edge_mid = (same_region_point + other_point).normalized() * sphere_radius
	var normal = same_region_point.cross(other_point).normalized()
	var projected = pos - normal.dot(pos) * normal
	var mag = projected.length()
	if mag == 0.0:
		return INF
	var sin_distance = edge_mid.cross(projected).length() / (sphere_radius * mag)
	if sin_distance > sin_edge_width:
		return INF
	var result = asin(clampf(sin_distance, -1.0, 1.0))
	var edge_point = edge_mid + (pos - projected)
	var blocked = false
	var other_sqr = edge_point.distance_squared_to(other_point)
	var limit = other_sqr * 2.0
	var all_diff: Array[Vector3] = []
	for nearby in nearby_points:
		if nearby["region_id"] != other_region:
			var world_pos: Vector3 = nearby["world_pos"]
			var dist = edge_point.distance_squared_to(world_pos)
			if dist < other_sqr:
				blocked = true
			if dist < limit:
				all_diff.append(world_pos)
	if not blocked:
		return result
	all_diff.append(same_region_point)
	var corners: Array[Vector3] = []
	var corner_a: Array[int] = []
	var corner_b: Array[int] = []
	_get_corners(other_point, all_diff, corners, corner_a, corner_b, sphere_radius)
	var best_corner = Vector3.ZERO
	var best_dist = INF
	var best_index = -1
	for i in corners.size():
		var dist = corners[i].distance_squared_to(pos)
		if dist < best_dist:
			best_dist = dist
			best_corner = corners[i]
			best_index = i
	if best_corner == Vector3.ZERO:
		return INF
	var corner_distance = asin(clampf(pos.cross(best_corner).length() / (sphere_radius * best_corner.length()), -1.0, 1.0))
	var same_index = all_diff.size() - 1
	var ca = corner_a[best_index]
	var cb = corner_b[best_index]
	if ca == same_index or cb == same_index:
		var check_index = cb if ca == same_index else ca
		var special = _get_non_degenerate_distance_special_case(pos, all_diff[check_index], other_point, all_diff, check_index, sphere_radius, sin_edge_width)
		if special != INF:
			return special
	return corner_distance


func _get_non_degenerate_distance_special_case(pos: Vector3, same_region_point: Vector3, other_point: Vector3, different_region_points: Array[Vector3], ignore_index: int, sphere_radius: float, sin_edge_width: float) -> float:
	var edge_mid = (same_region_point + other_point).normalized() * sphere_radius
	var normal = same_region_point.cross(other_point).normalized()
	var projected = pos - normal.dot(pos) * normal
	var mag = projected.length()
	if mag == 0.0:
		return INF
	var sin_distance = edge_mid.cross(projected).length() / (sphere_radius * mag)
	if sin_distance > sin_edge_width:
		return INF
	var edge_point = edge_mid + (pos - projected)
	var other_sqr = edge_point.distance_squared_to(other_point)
	for i in different_region_points.size():
		if i != ignore_index and edge_point.distance_squared_to(different_region_points[i]) < other_sqr:
			return INF
	return asin(clampf(sin_distance, -1.0, 1.0))


func _get_corners(other_point: Vector3, different_region_points: Array[Vector3], corners: Array[Vector3], corner_a: Array[int], corner_b: Array[int], sphere_radius: float) -> void:
	corners.clear()
	corner_a.clear()
	corner_b.clear()
	for i in range(0, different_region_points.size() - 1):
		for j in range(i + 1, different_region_points.size()):
			var corner = _get_equidistant_point_on_sphere(other_point, different_region_points[i], different_region_points[j], sphere_radius)
			var other_sqr = corner.distance_squared_to(other_point)
			var blocked = false
			for k in different_region_points.size():
				if k != i and k != j and different_region_points[k].distance_squared_to(corner) < other_sqr:
					blocked = true
					break
			if not blocked:
				corners.append(corner)
				corner_a.append(i)
				corner_b.append(j)


func _get_equidistant_point_on_sphere(p1: Vector3, p2: Vector3, p3: Vector3, sphere_radius: float) -> Vector3:
	var v = (p2 - p1).cross(p3 - p1).normalized()
	if v.dot(p1 + p2 + p3) < 0.0:
		v = -v
	return v * sphere_radius


func _generate_fibonacci_sphere(radius: float, count: int) -> Array[Vector3]:
	var result: Array[Vector3] = []
	var golden = PI * (sqrt(5.0) - 1.0)
	for i in count:
		var y = 1.0 - float(i) / float(count - 1) * 2.0
		var r = sqrt(maxf(0.0, 1.0 - y * y))
		var theta = float(i) * golden
		result.append(Vector3(cos(theta) * r, y, sin(theta) * r) * radius)
	return result


func _add_self_point(plate_id: int, point_id: int) -> void:
	if plate_id < 0 or plate_id >= _plates.size() or _plates[plate_id].is_empty():
		return
	var points: Array = _plates[plate_id]["self_points"]
	if not points.has(point_id):
		points.append(point_id)


func _remove_self_point(plate_id: int, point_id: int) -> void:
	if plate_id < 0 or plate_id >= _plates.size() or _plates[plate_id].is_empty():
		return
	var points: Array = _plates[plate_id]["self_points"]
	var index = points.find(point_id)
	if index >= 0:
		points.remove_at(index)


func _closest_point_index(pos: Vector3) -> int:
	if _point_kd_tree != null:
		return _point_kd_tree.closest_point(pos)
	var best = 0
	var best_dist = INF
	for i in _point_positions.size():
		var dist = pos.distance_squared_to(_point_positions[i])
		if dist < best_dist:
			best_dist = dist
			best = i
	return best


func _closest_edge_search_index(pos: Vector3, qbuf: Dictionary = {}) -> int:
	if _edge_kd_tree != null:
		return _edge_kd_tree.closest_point(pos, qbuf)
	var best = 0
	var best_dist = INF
	for i in _edge_point_positions.size():
		var dist = pos.distance_squared_to(_edge_point_positions[i])
		if dist < best_dist:
			best_dist = dist
			best = i
	return best


func _radius_edge_search_indices(pos: Vector3, radius: float) -> Array[int]:
	if _edge_kd_tree != null:
		return _edge_kd_tree.radius(pos, radius)
	var result: Array[int] = []
	var r2 = radius * radius
	for i in _edge_point_positions.size():
		if pos.distance_squared_to(_edge_point_positions[i]) <= r2:
			result.append(i)
	return result


func _k_nearest_point_indices(pos: Vector3, k: int) -> Array[int]:
	if _point_kd_tree != null:
		return _point_kd_tree.k_nearest(pos, k)
	var best_indices: Array[int] = []
	var best_distances: Array[float] = []
	for i in _points.size():
		var dist = pos.distance_squared_to(_points[i]["world_pos"])
		var insert_at = -1
		for j in best_distances.size():
			if dist < best_distances[j]:
				insert_at = j
				break
		if insert_at == -1 and best_indices.size() < k:
			insert_at = best_indices.size()
		if insert_at != -1:
			best_indices.insert(insert_at, i)
			best_distances.insert(insert_at, dist)
			if best_indices.size() > k:
				best_indices.pop_back()
				best_distances.pop_back()
	return best_indices


func _k_nearest_biome_indices(pos: Vector3, k: int) -> Array[int]:
	if _biome_tree != null:
		return _biome_tree.k_nearest(pos, k)
	var best_indices: Array[int] = []
	var best_distances: Array[float] = []
	for i in _biome_points.size():
		var dist = pos.distance_squared_to(_biome_points[i])
		var insert_at = -1
		for j in best_distances.size():
			if dist < best_distances[j]:
				insert_at = j
				break
		if insert_at == -1 and best_indices.size() < k:
			insert_at = best_indices.size()
		if insert_at != -1:
			best_indices.insert(insert_at, i)
			best_distances.insert(insert_at, dist)
			if best_indices.size() > k:
				best_indices.pop_back()
				best_distances.pop_back()
	return best_indices


func _get_distance_to_next_plate(plate_id: int, pos: Vector3) -> float:
	var best = INF
	for p in _points:
		if p["tectonic_plate"] != plate_id:
			best = minf(best, pos.distance_squared_to(p["world_pos"]))
	return best


func _get_tangential_movement(pos: Vector3, plate_id: int) -> Vector3:
	var move: Vector3 = _plates[plate_id]["movement_direction"]
	var normal = pos.normalized()
	return (move - normal * move.dot(normal)).normalized()


func _noise3(pos: Vector3, offset: Vector3, scale: float) -> float:
	var p = (pos + offset) / scale
	return float(_simplex.evaluate(p.x, p.y, p.z)) / 2.4 + 0.5


func _unity_lerp(a: float, b: float, t: float) -> float:
	return lerpf(a, b, clampf(t, 0.0, 1.0))


func _smooth_lerp(a: float, b: float, t: float) -> float:
	t = clampf(t, 0.0, 1.0)
	t = t * t * (3.0 - 2.0 * t)
	return lerpf(a, b, t)


func _smooth_zero_to_one_to_zero(t: float) -> float:
	if t < 0.0:
		return 0.0
	if t > 1.0:
		return 1.0
	return t * t * t * (t * (t * 6.0 - 15.0) + 10.0)
