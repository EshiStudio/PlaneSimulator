# Port of Planet Architect's KDTree (ViliWonka)
class_name KDTree
extends RefCounted

class KDBounds:
	var min = Vector3(INF, INF, INF)
	var max = Vector3(-INF, -INF, -INF)
	
	func size() -> Vector3:
		return max - min
	
	func closest_point(point: Vector3) -> Vector3:
		var p = point
		if p.x < min.x: p.x = min.x
		elif p.x > max.x: p.x = max.x
		if p.y < min.y: p.y = min.y
		elif p.y > max.y: p.y = max.y
		if p.z < min.z: p.z = min.z
		elif p.z > max.z: p.z = max.z
		return p

class KDNode:
	var partition_axis = -1
	var partition_coordinate = 0.0
	var negative_child: KDNode
	var positive_child: KDNode
	var start = 0
	var end = 0
	var bounds = KDBounds.new()
	
	var count: int:
		get: return end - start
	var is_leaf: bool:
		get: return partition_axis == -1

var points: Array[Vector3] = []
var permutation: Array[int] = []
var _count = 0
var _max_per_leaf = 32
var _root: KDNode
var _node_stack: Array[KDNode] = []
var _q_cap := 128
var _q_nodes: Array[KDNode] = []
var _q_tp := PackedVector3Array()
var _q_dist := PackedFloat64Array()
var _best_idx := PackedInt32Array()
var _best_dist := PackedFloat64Array()

func _q_reset() -> void:
	if _q_nodes.size() < _q_cap:
		_q_nodes.resize(_q_cap)
	if _q_tp.size() < _q_cap:
		_q_tp.resize(_q_cap)
	if _q_dist.size() < _q_cap:
		_q_dist.resize(_q_cap)

func _q_grow() -> void:
	_q_cap *= 2
	_q_nodes.resize(_q_cap)
	_q_tp.resize(_q_cap)
	_q_dist.resize(_q_cap)

func _init(source_points: Array[Vector3], max_per_leaf := 32):
	_max_per_leaf = max_per_leaf
	points = source_points
	_count = points.size()
	permutation.resize(_count)
	for i in _count:
		permutation[i] = i
	rebuild()

func rebuild(max_per_leaf := -1):
	if max_per_leaf > 0:
		_max_per_leaf = max_per_leaf
	_node_stack.clear()
	_root = _get_node()
	_root.bounds = _make_bounds()
	_root.start = 0
	_root.end = _count
	_split_node(_root)

func _get_node() -> KDNode:
	var n = KDNode.new()
	_node_stack.append(n)
	return n

func _make_bounds() -> KDBounds:
	var b = KDBounds.new()
	var n = _count & -2
	for i in range(0, n, 2):
		var j = i + 1
		for axis in 3:
			var a = points[permutation[i]][axis]
			var b2 = points[permutation[j]][axis]
			if a > b2:
				if b2 < b.min[axis]: b.min[axis] = b2
				if a > b.max[axis]: b.max[axis] = a
			else:
				if a < b.min[axis]: b.min[axis] = a
				if b2 > b.max[axis]: b.max[axis] = b2
	if n != _count:
		var p = points[permutation[n]]
		for axis in 3:
			if p[axis] < b.min[axis]: b.min[axis] = p[axis]
			if p[axis] > b.max[axis]: b.max[axis] = p[axis]
	return b

func _split_node(parent: KDNode):
	var b = parent.bounds
	var sz = b.size()
	var axis = 0
	if sz.y > sz.x: axis = 1
	if sz.z > sz[axis]: axis = 2
	var pivot = (b.min[axis] + b.max[axis]) * 0.5
	
	var has_less = false
	var has_more = false
	for i in range(parent.start, parent.end):
		if points[permutation[i]][axis] < pivot:
			has_less = true
		else:
			has_more = true
		if has_less and has_more:
			break
	
	if not has_less or not has_more:
		pivot = b.min[axis]
		for i in range(parent.start, parent.end):
			var v = points[permutation[i]][axis]
			if v > pivot:
				pivot = v
		if not has_less:
			pivot = b.max[axis]
			for i in range(parent.start, parent.end):
				var v = points[permutation[i]][axis]
				if v < pivot:
					pivot = v
	
	parent.partition_axis = axis
	parent.partition_coordinate = pivot
	
	var split = _partition(parent.start, parent.end, pivot, axis)
	
	var neg = _get_node()
	neg.bounds = KDBounds.new()
	neg.bounds.min = b.min
	neg.bounds.max = b.max
	neg.bounds.max[axis] = pivot
	neg.start = parent.start
	neg.end = split
	parent.negative_child = neg
	
	var pos = _get_node()
	pos.bounds = KDBounds.new()
	pos.bounds.min = b.min
	pos.bounds.max = b.max
	pos.bounds.min[axis] = pivot
	pos.start = split
	pos.end = parent.end
	parent.positive_child = pos
	
	if neg.count > _max_per_leaf and pos.count > 0:
		_split_node(neg)
	if pos.count > _max_per_leaf and pos.count > 0:
		_split_node(pos)

func _partition(start: int, end: int, pivot: float, axis: int) -> int:
	var i = start - 1
	var j = end
	while true:
		i += 1
		while i < j and points[permutation[i]][axis] < pivot:
			i += 1
		j -= 1
		while i < j and points[permutation[j]][axis] >= pivot:
			j -= 1
		if i >= j:
			break
		var tmp = permutation[i]
		permutation[i] = permutation[j]
		permutation[j] = tmp
	return i

func closest_point(query: Vector3, q: Dictionary = {}) -> int:
	if _count == 0:
		return -1
	var qn: Array = q.get("n", [])
	var qtp: PackedVector3Array = q.get("tp", PackedVector3Array())
	var qd: PackedFloat64Array = q.get("d", PackedFloat64Array())
	if qn.is_empty():
		qn.resize(128)
	if qtp.is_empty():
		qtp.resize(128)
	if qd.is_empty():
		qd.resize(128)
	var cap: int = qn.size()
	var best_idx = 0
	var best_dist = INF
	var top := 1
	var node = _root
	var tp: Vector3 = node.bounds.closest_point(query)
	qn[0] = node
	qtp[0] = tp
	qd[0] = tp.distance_squared_to(query)
	while top > 0:
		top -= 1
		var n: KDNode = qn[top]
		if qd[top] > best_dist:
			continue
		if n.is_leaf:
			for i in range(n.start, n.end):
				var idx = permutation[i]
				var d = points[idx].distance_squared_to(query)
				if d < best_dist:
					best_dist = d
					best_idx = idx
		else:
			var axis = n.partition_axis
			var coord = n.partition_coordinate
			var tp2 := qtp[top]
			if tp2[axis] - coord < 0:
				qn[top] = n.negative_child
				qtp[top] = tp2
				qd[top] = tp2.distance_squared_to(query)
				top += 1
				tp2[axis] = coord
				if n.positive_child.count > 0:
					if top >= cap:
						cap *= 2
						qn.resize(cap)
						qtp.resize(cap)
						qd.resize(cap)
					qn[top] = n.positive_child
					qtp[top] = tp2
					qd[top] = tp2.distance_squared_to(query)
					top += 1
			else:
				qn[top] = n.positive_child
				qtp[top] = tp2
				qd[top] = tp2.distance_squared_to(query)
				top += 1
				tp2[axis] = coord
				if n.negative_child.count > 0:
					if top >= cap:
						cap *= 2
						qn.resize(cap)
						qtp.resize(cap)
						qd.resize(cap)
					qn[top] = n.negative_child
					qtp[top] = tp2
					qd[top] = tp2.distance_squared_to(query)
					top += 1
	return best_idx

func k_nearest(query: Vector3, k: int) -> Array[int]:
	var result: Array[int] = []
	if _count == 0 or k <= 0:
		return result
	_best_idx.resize(k)
	_best_dist.resize(k)
	var best_size := 0
	var worst := INF
	_q_reset()
	var top := 1
	var node = _root
	var tp: Vector3 = node.bounds.closest_point(query)
	_q_nodes[0] = node
	_q_tp[0] = tp
	_q_dist[0] = tp.distance_squared_to(query)
	while top > 0:
		top -= 1
		var n: KDNode = _q_nodes[top]
		if _q_dist[top] > worst:
			continue
		if n.is_leaf:
			for i in range(n.start, n.end):
				var idx = permutation[i]
				var d = points[idx].distance_squared_to(query)
				if d > worst:
					continue
				var insert_at := best_size
				for j in best_size:
					if d < _best_dist[j]:
						insert_at = j
						break
				if insert_at >= k:
					continue
				var j2 := mini(best_size, k - 1)
				while j2 > insert_at:
					_best_idx[j2] = _best_idx[j2 - 1]
					_best_dist[j2] = _best_dist[j2 - 1]
					j2 -= 1
				_best_idx[insert_at] = idx
				_best_dist[insert_at] = d
				best_size = mini(best_size + 1, k)
				if best_size == k:
					worst = _best_dist[k - 1]
		else:
			var axis = n.partition_axis
			var coord = n.partition_coordinate
			var tp2 := _q_tp[top]
			if tp2[axis] - coord < 0:
				_q_nodes[top] = n.negative_child
				_q_tp[top] = tp2
				_q_dist[top] = tp2.distance_squared_to(query)
				top += 1
				tp2[axis] = coord
				if n.positive_child.count > 0:
					if top >= _q_cap:
						_q_grow()
					_q_nodes[top] = n.positive_child
					_q_tp[top] = tp2
					_q_dist[top] = tp2.distance_squared_to(query)
					top += 1
			else:
				_q_nodes[top] = n.positive_child
				_q_tp[top] = tp2
				_q_dist[top] = tp2.distance_squared_to(query)
				top += 1
				tp2[axis] = coord
				if n.negative_child.count > 0:
					if top >= _q_cap:
						_q_grow()
					_q_nodes[top] = n.negative_child
					_q_tp[top] = tp2
					_q_dist[top] = tp2.distance_squared_to(query)
					top += 1
	for i in best_size:
		result.append(_best_idx[i])
	return result

func radius(query: Vector3, radius: float) -> Array[int]:
	var result: Array[int] = []
	var r2 = radius * radius
	var stack: Array[KDNode] = [_root]
	while stack.size() > 0:
		var n: KDNode = stack.pop_back()
		if n.is_leaf:
			for i in range(n.start, n.end):
				var idx = permutation[i]
				if points[idx].distance_squared_to(query) <= r2:
					result.append(idx)
		else:
			var axis = n.partition_axis
			var coord = n.partition_coordinate
			var tp = query
			if tp[axis] - coord < 0:
				stack.append(n.negative_child)
				tp[axis] = coord
				if n.positive_child.count > 0 and tp.distance_squared_to(query) <= r2:
					stack.append(n.positive_child)
			else:
				stack.append(n.positive_child)
				tp[axis] = coord
				if n.negative_child.count > 0 and tp.distance_squared_to(query) <= r2:
					stack.append(n.negative_child)
	return result
