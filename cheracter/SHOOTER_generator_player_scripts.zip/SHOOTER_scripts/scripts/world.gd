class_name PaniniWorld
extends Node3D

const PLAYER_SCRIPT := preload("res://scripts/player.gd")
const TEST_CHARACTER_SCRIPT := preload("res://scripts/test_character.gd")
const PLANET_ARCHITECT_GENERATOR_SCRIPT := preload("res://scripts/planet_architect_generator.gd")
const ISLAND_SCENE := preload("res://assets/maps/ostrov1.glb")
const ISLAND_WATER_SHADER := preload("res://shaders/island_water.gdshader")
const PLANET_SURFACE_SHADER := preload("res://shaders/planet_surface.gdshader")
const PLANET_WATER_SHADER := preload("res://shaders/planet_water.gdshader")
const LAYER_WORLD := 1
const LAYER_PLAYER := 2
const FLOOR_VISUAL_SIZE := 8192.0
const SEA_FLOOR_Y := -1.25
const SEA_FLOOR_ALPHA := 1.0
const PLANET_RADIUS := 38.0
const PLANET_CENTER := Vector3(0.0, -38.0, 0.0)
const PLANET_SPAWN_POSITION := Vector3(0.0, 1.35, 0.0)
const FOREST_SIZE := 260.0
const TREE_COUNT := 150
const GRASS_PATCH_COUNT := 420
const MULTIPLAYER_PORT := 32145
const MULTIPLAYER_MAX_CLIENTS := 8
const MULTIPLAYER_ADDRESS := "127.0.0.1"
const MULTIPLAYER_LOCK_PATH := "user://panini_multiplayer.lock"
const NETWORK_SEND_RATE := 20.0
const REMOTE_POSITION_RESPONSE := 18.0
const REMOTE_ROTATION_RESPONSE := 20.0
const PLAYER_LOOK_RADIUS := 7.0
const CLIENT_SPAWN_POSITION := Vector3(0.0, 0.0, -4.0)
const CLIENT_SPAWN_YAW := PI

var player
var test_character
var floor_visual: MeshInstance3D
var multiplayer_peer: ENetMultiplayerPeer
var multiplayer_ready := false
var multiplayer_lock_claimed := false
var network_send_timer := 0.0
var broadcast_debug_sent_once := false
var broadcast_debug_received_once := false
var connected_peer_ids := []
var remote_players := {}
var remote_states := {}
var sun_direction := Vector3.ZERO
var island_root: Node3D
var water_visual: MeshInstance3D
var sea_floor_visual: MeshInstance3D
var planet_root: Node3D
var planet_surface_visual: MeshInstance3D
var planet_water_visual: MeshInstance3D
var forest_grass_root: Node3D
var forest_tree_root: Node3D
var planet_architect_generator


func _ready() -> void:
	_build_blue_sky()
	_build_infinite_floor()
	_spawn_player()
	_spawn_test_character()
	_start_multiplayer()


func _process(delta: float) -> void:
	_debug_track_player(delta)
	_sync_local_player_avatar()
	_update_remote_players(delta)
	_update_avatar_eye_targets()
	_sync_floor_visual_to_player()
	_send_network_state(delta)


func _sync_floor_visual_to_player() -> void:
	if player == null:
		return
	if floor_visual != null and floor_visual != planet_surface_visual:
		floor_visual.position.x = player.global_position.x
		floor_visual.position.z = player.global_position.z
	if sea_floor_visual != null:
		sea_floor_visual.position.x = player.global_position.x
		sea_floor_visual.position.z = player.global_position.z


func _build_blue_sky() -> void:
	var environment_node := WorldEnvironment.new()
	environment_node.name = "WorldEnvironment"
	var environment := Environment.new()
	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()

	sky_material.sky_top_color = Color(0.18, 0.42, 0.95)
	sky_material.sky_horizon_color = Color(0.54, 0.76, 1.0)
	sky_material.sky_curve = 0.08
	sky_material.sky_energy_multiplier = 1.15
	sky_material.ground_bottom_color = Color(0.62, 0.66, 0.70)
	sky_material.ground_horizon_color = Color(0.54, 0.76, 1.0)
	sky_material.ground_curve = 0.02

	sky.sky_material = sky_material
	environment.background_mode = Environment.BG_SKY
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	environment.ambient_light_energy = 0.85
	environment.tonemap_mode = Environment.TONE_MAPPER_AGX
	environment.glow_enabled = false
	environment_node.environment = environment
	add_child(environment_node)

	var sun := DirectionalLight3D.new()
	sun.name = "Sun"
	sun.rotation_degrees = Vector3(-42.0, -36.0, 0.0)
	sun.light_energy = 2.2
	sun.shadow_enabled = false
	add_child(sun)
	# Directional lights emit along local -Z, so local +Z points back toward the sun.
	sun_direction = sun.global_transform.basis.z.normalized()


func _build_infinite_floor() -> void:
	_build_planet_world()


func _build_planet_world() -> void:
	planet_architect_generator = PLANET_ARCHITECT_GENERATOR_SCRIPT.new()
	var generated = planet_architect_generator.generate(self, LAYER_WORLD)
	planet_root = generated["root"] as Node3D
	planet_surface_visual = generated["ground"] as MeshInstance3D
	planet_water_visual = generated["water"] as MeshInstance3D
	forest_tree_root = generated["trees"] as Node3D
	forest_grass_root = generated["grass"] as Node3D
	floor_visual = planet_surface_visual


func _build_forest_ground() -> void:
	var ground_body := StaticBody3D.new()
	ground_body.name = "PlanetGroundCollision"
	ground_body.collision_layer = LAYER_WORLD
	ground_body.collision_mask = 0
	planet_root.add_child(ground_body)

	var ground_shape := CollisionShape3D.new()
	var boundary := WorldBoundaryShape3D.new()
	boundary.plane = Plane(Vector3.UP, 0.0)
	ground_shape.shape = boundary
	ground_body.add_child(ground_shape)

	planet_surface_visual = MeshInstance3D.new()
	planet_surface_visual.name = "PlanetForestGround"
	var surface_mesh := PlaneMesh.new()
	surface_mesh.size = Vector2(FOREST_SIZE, FOREST_SIZE)
	surface_mesh.subdivide_width = 80
	surface_mesh.subdivide_depth = 80
	planet_surface_visual.mesh = surface_mesh
	planet_surface_visual.material_override = _forest_ground_material()
	planet_root.add_child(planet_surface_visual)

	planet_water_visual = null


func _build_forest_trees() -> void:
	forest_tree_root = Node3D.new()
	forest_tree_root.name = "PlanetForestTrees"
	planet_root.add_child(forest_tree_root)

	var trunk_material := _forest_trunk_material()
	var leaf_materials := [_forest_leaf_material(Color(0.05, 0.24, 0.06)), _forest_leaf_material(Color(0.09, 0.34, 0.10)), _forest_leaf_material(Color(0.13, 0.42, 0.13))]
	for i in TREE_COUNT:
		var position := _forest_scatter_position(i, 9.0, FOREST_SIZE * 0.47)
		var height := 7.5 + _hash_float(i * 19 + 3) * 8.5
		var trunk_radius := 0.17 + _hash_float(i * 23 + 7) * 0.22
		var tree := Node3D.new()
		tree.name = "ForestTree%d" % i
		tree.position = position
		tree.rotation.y = _hash_float(i * 11 + 5) * TAU
		forest_tree_root.add_child(tree)

		var trunk := MeshInstance3D.new()
		trunk.name = "Trunk"
		var trunk_mesh := CylinderMesh.new()
		trunk_mesh.top_radius = trunk_radius * 0.72
		trunk_mesh.bottom_radius = trunk_radius
		trunk_mesh.height = height
		trunk_mesh.radial_segments = 7
		trunk.mesh = trunk_mesh
		trunk.position.y = height * 0.5
		trunk.material_override = trunk_material
		tree.add_child(trunk)

		var trunk_body := StaticBody3D.new()
		trunk_body.name = "TrunkCollision"
		trunk_body.collision_layer = LAYER_WORLD
		trunk_body.collision_mask = 0
		tree.add_child(trunk_body)
		var trunk_shape := CollisionShape3D.new()
		var capsule := CapsuleShape3D.new()
		capsule.radius = trunk_radius * 1.18
		capsule.height = height
		trunk_shape.shape = capsule
		trunk_shape.position.y = height * 0.5
		trunk_body.add_child(trunk_shape)

		for layer in 3:
			var leaves := MeshInstance3D.new()
			leaves.name = "LeafCanopy%d" % layer
			var leaf_mesh := CylinderMesh.new()
			var layer_scale := 1.0 - float(layer) * 0.22
			leaf_mesh.top_radius = 0.0
			leaf_mesh.bottom_radius = (1.9 + _hash_float(i * 31 + layer) * 1.0) * layer_scale
			leaf_mesh.height = (3.0 + _hash_float(i * 37 + layer) * 1.2) * layer_scale
			leaf_mesh.radial_segments = 8
			leaves.mesh = leaf_mesh
			leaves.position.y = height * (0.58 + float(layer) * 0.14)
			leaves.rotation.y = float(layer) * 0.44
			leaves.material_override = leaf_materials[(i + layer) % leaf_materials.size()]
			tree.add_child(leaves)


func _build_forest_grass() -> void:
	forest_grass_root = Node3D.new()
	forest_grass_root.name = "PlanetForestGrass"
	planet_root.add_child(forest_grass_root)
	var grass_material := _forest_grass_material()
	for i in GRASS_PATCH_COUNT:
		var patch := MeshInstance3D.new()
		patch.name = "GrassPatch%d" % i
		var mesh := QuadMesh.new()
		mesh.size = Vector2(0.35 + _hash_float(i * 17) * 0.35, 0.55 + _hash_float(i * 29) * 0.65)
		patch.mesh = mesh
		patch.position = _forest_scatter_position(i + 900, 1.2, FOREST_SIZE * 0.49) + Vector3(0.0, mesh.size.y * 0.5, 0.0)
		patch.rotation.y = _hash_float(i * 41) * TAU
		patch.material_override = grass_material
		forest_grass_root.add_child(patch)


func _build_distant_hills() -> void:
	var hill_material := _forest_hill_material()
	for i in 18:
		var hill := MeshInstance3D.new()
		hill.name = "DistantHill%d" % i
		var mesh := SphereMesh.new()
		mesh.radius = 9.0 + _hash_float(i * 13) * 8.0
		mesh.height = mesh.radius * (0.42 + _hash_float(i * 7) * 0.20)
		mesh.radial_segments = 16
		mesh.rings = 8
		hill.mesh = mesh
		var angle := float(i) / 18.0 * TAU
		hill.position = Vector3(cos(angle), -mesh.height * 0.25, sin(angle)) * (FOREST_SIZE * 0.45)
		hill.scale.z = 0.45 + _hash_float(i * 5) * 0.65
		hill.rotation.y = angle
		hill.material_override = hill_material
		planet_root.add_child(hill)


func _forest_scatter_position(index: int, clear_radius: float, max_radius: float) -> Vector3:
	var angle := _hash_float(index * 101 + 17) * TAU
	var distance := clear_radius + pow(_hash_float(index * 73 + 29), 0.62) * maxf(max_radius - clear_radius, 0.0)
	return Vector3(cos(angle) * distance, 0.0, sin(angle) * distance)


func _hash_float(value: int) -> float:
	var x := sin(float(value) * 12.9898) * 43758.5453
	return x - floorf(x)


func _forest_ground_material() -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.16, 0.30, 0.12)
	material.roughness = 0.94
	return material


func _forest_trunk_material() -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.13, 0.075, 0.045)
	material.roughness = 0.88
	return material


func _forest_leaf_material(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.96
	return material


func _forest_grass_material() -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.38, 0.58, 0.20)
	material.roughness = 0.98
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	return material


func _forest_hill_material() -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.10, 0.22, 0.10)
	material.roughness = 0.98
	return material
func _build_island_map() -> void:
	island_root = ISLAND_SCENE.instantiate() as Node3D
	if island_root == null:
		push_error("Ostrov1 map could not be instantiated")
		return
	island_root.name = "Ostrov1Map"
	island_root.position = Vector3.ZERO
	add_child(island_root)
	_build_island_collision(island_root)


func _build_island_collision(root_node: Node3D) -> void:
	var collision_body := StaticBody3D.new()
	collision_body.name = "Ostrov1Collision"
	collision_body.collision_layer = LAYER_WORLD
	collision_body.collision_mask = 0
	add_child(collision_body)
	_add_collision_from_node(root_node, collision_body, root_node.transform)


func _add_collision_from_node(node: Node, collision_body: StaticBody3D, accumulated_transform: Transform3D) -> void:
	if node is MeshInstance3D and _is_island_collision_mesh(node.name):
		var mesh_instance := node as MeshInstance3D
		if mesh_instance.mesh != null:
			var faces := _mesh_faces_in_space(mesh_instance.mesh, accumulated_transform)
			if faces.size() >= 3:
				var shape := ConcavePolygonShape3D.new()
				shape.set_faces(faces)
				var collision_shape := CollisionShape3D.new()
				collision_shape.name = "%sCollision" % mesh_instance.name
				collision_shape.shape = shape
				collision_body.add_child(collision_shape)

	for child in node.get_children():
		if child is Node3D:
			var child_node := child as Node3D
			_add_collision_from_node(child_node, collision_body, accumulated_transform * child_node.transform)


func _is_island_collision_mesh(node_name: String) -> bool:
	var lowered := node_name.to_lower()
	if lowered.contains("leaf") or lowered.contains("coco") or lowered.contains("shovel"):
		return false
	return true


func _mesh_faces_in_space(mesh: Mesh, target_transform: Transform3D) -> PackedVector3Array:
	var faces := PackedVector3Array()
	for surface_index in mesh.get_surface_count():
		var arrays := mesh.surface_get_arrays(surface_index)
		if arrays.is_empty():
			continue
		var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
		var indices: PackedInt32Array = arrays[Mesh.ARRAY_INDEX]
		if indices.is_empty():
			var triangle_count := vertices.size() / 3
			for triangle_index in triangle_count:
				var start := triangle_index * 3
				faces.append(target_transform * vertices[start])
				faces.append(target_transform * vertices[start + 1])
				faces.append(target_transform * vertices[start + 2])
		else:
			var triangle_count := indices.size() / 3
			for triangle_index in triangle_count:
				var start := triangle_index * 3
				faces.append(target_transform * vertices[indices[start]])
				faces.append(target_transform * vertices[indices[start + 1]])
				faces.append(target_transform * vertices[indices[start + 2]])
	return faces


func _build_ocean() -> void:
	var sea_floor_body := StaticBody3D.new()
	sea_floor_body.name = "SeaFloorCollision"
	sea_floor_body.collision_layer = LAYER_WORLD
	sea_floor_body.collision_mask = 0
	add_child(sea_floor_body)

	var floor_shape := CollisionShape3D.new()
	var boundary := WorldBoundaryShape3D.new()
	boundary.plane = Plane(Vector3.UP, SEA_FLOOR_Y)
	floor_shape.shape = boundary
	sea_floor_body.add_child(floor_shape)

	sea_floor_visual = MeshInstance3D.new()
	sea_floor_visual.name = "SeaFloorVisual"
	var sea_floor_mesh := PlaneMesh.new()
	sea_floor_mesh.size = Vector2(FLOOR_VISUAL_SIZE, FLOOR_VISUAL_SIZE)
	sea_floor_mesh.subdivide_width = 32
	sea_floor_mesh.subdivide_depth = 32
	sea_floor_visual.mesh = sea_floor_mesh
	sea_floor_visual.position.y = SEA_FLOOR_Y - 0.015
	sea_floor_visual.material_override = _sea_floor_material()
	add_child(sea_floor_visual)

	water_visual = MeshInstance3D.new()
	water_visual.name = "AnimatedWater"
	var water_mesh := PlaneMesh.new()
	water_mesh.size = Vector2(FLOOR_VISUAL_SIZE, FLOOR_VISUAL_SIZE)
	water_mesh.subdivide_width = 128
	water_mesh.subdivide_depth = 128
	water_visual.mesh = water_mesh
	water_visual.position.y = 0.0
	water_visual.material_override = _water_material()
	add_child(water_visual)
	floor_visual = water_visual


func _spawn_player() -> void:
	player = PLAYER_SCRIPT.new()
	player.name = "Player"
	player.collision_layer = LAYER_PLAYER
	player.collision_mask = LAYER_WORLD | LAYER_PLAYER
	player.sun_direction = sun_direction
	add_child(player)
	if planet_architect_generator != null:
		player.position = planet_architect_generator.get_spawn_position()
		print("[debug] player spawned at ", player.position)
	else:
		player.position = PLANET_SPAWN_POSITION
		print("[debug] player spawned at fallback ", player.position)


var _debug_timer := 0.0
var _debug_seconds := 0

func _debug_track_player(delta: float) -> void:
	if player == null or _debug_seconds >= 60:
		return
	_debug_timer += delta
	if _debug_timer < 1.0:
		return
	_debug_timer -= 1.0
	_debug_seconds += 1
	print(
		"[debug] t=", _debug_seconds,
		" pos=", player.global_position,
		" on_floor=", player.is_on_floor(),
		" vel=", player.velocity.length()
	)


func _spawn_test_character() -> void:
	test_character = TEST_CHARACTER_SCRIPT.new()
	test_character.name = "TestCharacter"
	test_character.scale = Vector3.ONE * 1.18
	test_character.face_target_enabled = false
	test_character.sun_direction = sun_direction
	test_character.visible = false
	add_child(test_character)
	test_character.set_head_visible_for_owner(false)
	_sync_local_player_avatar()


func _sync_local_player_avatar() -> void:
	if player == null or test_character == null:
		return
	test_character.global_position = player.global_position
	test_character.rotation.y = player.global_rotation.y
	test_character.external_velocity = player.velocity
	test_character.external_move_speed = Vector2(player.velocity.x, player.velocity.z).length()
	test_character.external_stance_amount = player.stance_amount
	test_character.external_pitch = player.pitch
	test_character.external_on_floor = player.is_on_floor()


func _start_multiplayer() -> void:
	if "--no-multiplayer" in OS.get_cmdline_user_args():
		print("MULTIPLAYER: disabled by --no-multiplayer")
		return

	_connect_multiplayer_signals()
	var port := _multiplayer_port_from_args()
	var address := _multiplayer_address_from_args()
	var force_client := "--multiplayer-client" in OS.get_cmdline_user_args()
	var force_host := "--multiplayer-host" in OS.get_cmdline_user_args()

	if force_client:
		_join_multiplayer(address, port)
		return
	if force_host:
		_claim_multiplayer_lock(port, address)
		if _host_multiplayer(port):
			return
		_clear_multiplayer_lock()
		return
	if _multiplayer_lock_matches(port, address):
		if _join_multiplayer(address, port):
			return
		_clear_multiplayer_lock()
	_claim_multiplayer_lock(port, address)
	if _host_multiplayer(port):
		return
	_clear_multiplayer_lock()
	_join_multiplayer(address, port)


func _connect_multiplayer_signals() -> void:
	if not multiplayer.peer_connected.is_connected(_on_peer_connected):
		multiplayer.peer_connected.connect(_on_peer_connected)
	if not multiplayer.peer_disconnected.is_connected(_on_peer_disconnected):
		multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	if not multiplayer.connected_to_server.is_connected(_on_connected_to_server):
		multiplayer.connected_to_server.connect(_on_connected_to_server)
	if not multiplayer.connection_failed.is_connected(_on_connection_failed):
		multiplayer.connection_failed.connect(_on_connection_failed)
	if not multiplayer.server_disconnected.is_connected(_on_server_disconnected):
		multiplayer.server_disconnected.connect(_on_server_disconnected)


func _host_multiplayer(port: int) -> bool:
	var peer := ENetMultiplayerPeer.new()
	var error := peer.create_server(port, MULTIPLAYER_MAX_CLIENTS)
	if error != OK:
		peer.close()
		return false

	multiplayer_peer = peer
	multiplayer.multiplayer_peer = multiplayer_peer
	multiplayer_ready = true
	print("MULTIPLAYER: hosting on UDP port %d" % port)
	return true


func _join_multiplayer(address: String, port: int) -> bool:
	var peer := ENetMultiplayerPeer.new()
	var error := peer.create_client(address, port)
	if error != OK:
		peer.close()
		printerr("MULTIPLAYER: failed to connect to %s:%d, error %d" % [address, port, error])
		return false

	multiplayer_peer = peer
	multiplayer.multiplayer_peer = multiplayer_peer
	multiplayer_ready = false
	print("MULTIPLAYER: connecting to %s:%d" % [address, port])
	return true


func _claim_multiplayer_lock(port: int, address: String) -> void:
	var lock_data := {
		"port": port,
		"address": address,
		"pid": OS.get_process_id(),
	}
	var file := FileAccess.open(MULTIPLAYER_LOCK_PATH, FileAccess.WRITE)
	if file == null:
		return
	file.store_string(JSON.stringify(lock_data))
	multiplayer_lock_claimed = true


func _clear_multiplayer_lock() -> void:
	if not multiplayer_lock_claimed:
		return
	multiplayer_lock_claimed = false
	var absolute_path := ProjectSettings.globalize_path(MULTIPLAYER_LOCK_PATH)
	if DirAccess.remove_absolute(absolute_path) != OK:
		pass


func _multiplayer_lock_matches(port: int, address: String) -> bool:
	if not FileAccess.file_exists(MULTIPLAYER_LOCK_PATH):
		return false
	var lock_text := FileAccess.get_file_as_string(MULTIPLAYER_LOCK_PATH)
	if lock_text.is_empty():
		return false
	var parsed: Variant = JSON.parse_string(lock_text)
	if parsed is not Dictionary:
		return false
	var lock_data: Dictionary = parsed
	return int(lock_data.get("port", -1)) == port and String(lock_data.get("address", "")) == address


func _multiplayer_port_from_args() -> int:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--multiplayer-port="):
			var value := arg.get_slice("=", 1)
			if value.is_valid_int():
				return int(value)
	return MULTIPLAYER_PORT


func _multiplayer_address_from_args() -> String:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--multiplayer-address="):
			var value := arg.get_slice("=", 1).strip_edges()
			if not value.is_empty():
				return value
		if arg.begins_with("--connect="):
			var value := arg.get_slice("=", 1).strip_edges()
			if not value.is_empty():
				return value
	return MULTIPLAYER_ADDRESS


func _send_network_state(delta: float) -> void:
	if not multiplayer_ready or player == null:
		return
	network_send_timer += delta
	var send_interval := 1.0 / NETWORK_SEND_RATE
	if network_send_timer < send_interval:
		return
	network_send_timer = fmod(network_send_timer, send_interval)

	var local_peer_id := multiplayer.get_unique_id()
	var remote_position: Vector3 = player.global_position
	var yaw: float = player.global_rotation.y
	var pitch: float = player.pitch
	var horizontal_speed: float = Vector2(player.velocity.x, player.velocity.z).length()
	var stance_amount: float = player.stance_amount
	var remote_velocity: Vector3 = player.velocity
	var on_floor: bool = player.is_on_floor()

	if multiplayer.is_server():
		_broadcast_player_state_to_peers(local_peer_id, remote_position, yaw, pitch, horizontal_speed, stance_amount, remote_velocity, on_floor)
	else:
		_submit_player_state.rpc_id(1, local_peer_id, remote_position, yaw, pitch, horizontal_speed, stance_amount, remote_velocity, on_floor)


@rpc("any_peer", "call_remote", "unreliable")
func _submit_player_state(peer_id: int, remote_position: Vector3, yaw: float, pitch: float, horizontal_speed: float, stance_amount: float, remote_velocity: Vector3, on_floor: bool) -> void:
	var sender_id := multiplayer.get_remote_sender_id()
	if sender_id != peer_id:
		return
	_apply_remote_player_state(peer_id, remote_position, yaw, pitch, horizontal_speed, stance_amount, remote_velocity, on_floor)
	if multiplayer.is_server():
		_broadcast_player_state_to_peers(peer_id, remote_position, yaw, pitch, horizontal_speed, stance_amount, remote_velocity, on_floor)


func _broadcast_player_state_to_peers(peer_id: int, remote_position: Vector3, yaw: float, pitch: float, horizontal_speed: float, stance_amount: float, remote_velocity: Vector3, on_floor: bool) -> void:
	if _debug_mp_broadcast_enabled() and not broadcast_debug_sent_once:
		print("MULTIPLAYER_DEBUG: broadcast peers=%s state_peer=%d speed=%.3f" % [str(connected_peer_ids), peer_id, horizontal_speed])
		broadcast_debug_sent_once = true
	for target_peer_id in connected_peer_ids:
		_broadcast_player_state.rpc_id(target_peer_id, peer_id, remote_position, yaw, pitch, horizontal_speed, stance_amount, remote_velocity, on_floor)


@rpc("any_peer", "call_remote", "unreliable")
func _broadcast_player_state(peer_id: int, remote_position: Vector3, yaw: float, pitch: float, horizontal_speed: float, stance_amount: float, remote_velocity: Vector3, on_floor: bool) -> void:
	if _debug_mp_broadcast_enabled() and not broadcast_debug_received_once:
		print("MULTIPLAYER_DEBUG: received broadcast sender=%d state_peer=%d speed=%.3f server=%s" % [multiplayer.get_remote_sender_id(), peer_id, horizontal_speed, str(multiplayer.is_server())])
		broadcast_debug_received_once = true
	if multiplayer.is_server() or multiplayer.get_remote_sender_id() != 1:
		return
	if peer_id == multiplayer.get_unique_id():
		return
	_apply_remote_player_state(peer_id, remote_position, yaw, pitch, horizontal_speed, stance_amount, remote_velocity, on_floor)


func _apply_remote_player_state(peer_id: int, remote_position: Vector3, yaw: float, pitch: float, horizontal_speed: float, stance_amount: float, remote_velocity: Vector3, on_floor: bool) -> void:
	if peer_id <= 0 or peer_id == multiplayer.get_unique_id():
		return
	var avatar: TestCharacter = _ensure_remote_player(peer_id)
	if avatar == null:
		return
	remote_states[peer_id] = {
		"position": remote_position,
		"yaw": yaw,
		"pitch": pitch,
		"horizontal_speed": horizontal_speed,
		"stance_amount": stance_amount,
		"velocity": remote_velocity,
		"on_floor": on_floor,
	}


func _ensure_remote_player(peer_id: int) -> TestCharacter:
	if peer_id <= 0 or peer_id == multiplayer.get_unique_id():
		return null
	if remote_players.has(peer_id):
		return remote_players[peer_id] as TestCharacter

	var avatar: TestCharacter = TEST_CHARACTER_SCRIPT.new()
	avatar.name = "RemotePlayer%d" % peer_id
	avatar.scale = Vector3.ONE * 1.18
	avatar.face_target_enabled = false
	avatar.blocks_players = true
	avatar.blocker_collision_layer = LAYER_PLAYER
	avatar.blocker_collision_mask = LAYER_PLAYER
	avatar.sun_direction = sun_direction
	avatar.target = player
	add_child(avatar)
	avatar.global_position = player.global_position + Vector3(0.0, 0.0, -4.0)
	remote_players[peer_id] = avatar
	remote_states[peer_id] = {
		"position": avatar.global_position,
		"yaw": avatar.rotation.y,
		"pitch": 0.0,
		"horizontal_speed": 0.0,
		"stance_amount": 0.0,
		"velocity": Vector3.ZERO,
		"on_floor": true,
	}
	print("MULTIPLAYER: remote player %d joined" % peer_id)
	return avatar


func _update_remote_players(delta: float) -> void:
	for peer_id in remote_players.keys():
		var avatar: TestCharacter = remote_players[peer_id] as TestCharacter
		if avatar == null or not remote_states.has(peer_id):
			continue
		var state: Dictionary = remote_states[peer_id]
		var target_position: Vector3 = state["position"]
		var target_yaw: float = state["yaw"]
		var position_blend := 1.0 - exp(-REMOTE_POSITION_RESPONSE * delta)
		var rotation_blend := 1.0 - exp(-REMOTE_ROTATION_RESPONSE * delta)
		avatar.global_position = avatar.global_position.lerp(target_position, position_blend)
		avatar.rotation.y = lerp_angle(avatar.rotation.y, target_yaw, rotation_blend)
		avatar.external_pitch = state["pitch"]
		avatar.external_move_speed = state["horizontal_speed"]
		avatar.external_stance_amount = state["stance_amount"]
		avatar.external_velocity = state["velocity"]
		avatar.external_on_floor = state["on_floor"]


func _update_avatar_eye_targets() -> void:
	if player == null:
		return

	if test_character != null:
		test_character.set_eye_target(_nearest_eye_target(test_character, [test_character, player]))

	for peer_id in remote_players.keys():
		var avatar: TestCharacter = remote_players[peer_id] as TestCharacter
		if avatar == null:
			continue
		avatar.set_eye_target(_nearest_eye_target(avatar, [avatar]))


func _nearest_eye_target(source: TestCharacter, excluded_nodes: Array) -> Node3D:
	var best_target: Node3D = null
	var best_distance_squared := PLAYER_LOOK_RADIUS * PLAYER_LOOK_RADIUS
	var source_position := source.get_look_target_position()

	for candidate in _eye_target_candidates():
		if candidate == null or candidate in excluded_nodes:
			continue
		var candidate_position := _node_look_position(candidate)
		var distance_squared := source_position.distance_squared_to(candidate_position)
		if distance_squared < best_distance_squared:
			best_distance_squared = distance_squared
			best_target = candidate

	return best_target


func _eye_target_candidates() -> Array:
	var candidates: Array = []
	if player != null:
		candidates.append(player)
	for peer_id in remote_players.keys():
		var avatar: TestCharacter = remote_players[peer_id] as TestCharacter
		if avatar != null:
			candidates.append(avatar)
	return candidates


func _node_look_position(node: Node3D) -> Vector3:
	if node.has_method("get_look_target_position"):
		return node.get_look_target_position()
	var head_node := node.get_node_or_null("Head")
	if head_node is Node3D:
		return head_node.global_position
	return node.global_position + Vector3.UP * 1.55


func _debug_mp_broadcast_enabled() -> bool:
	return "--debug-mp-broadcast" in OS.get_cmdline_user_args()


func _on_peer_connected(peer_id: int) -> void:
	if not connected_peer_ids.has(peer_id):
		connected_peer_ids.append(peer_id)
	_ensure_remote_player(peer_id)


func _on_peer_disconnected(peer_id: int) -> void:
	connected_peer_ids.erase(peer_id)
	if remote_players.has(peer_id):
		var avatar: TestCharacter = remote_players[peer_id] as TestCharacter
		if avatar != null:
			avatar.queue_free()
	remote_players.erase(peer_id)
	remote_states.erase(peer_id)
	print("MULTIPLAYER: remote player %d left" % peer_id)


func _on_connected_to_server() -> void:
	multiplayer_ready = true
	_apply_client_spawn_offset()
	_ensure_remote_player(1)
	print("MULTIPLAYER: connected as peer %d" % multiplayer.get_unique_id())


func _on_connection_failed() -> void:
	multiplayer_ready = false
	printerr("MULTIPLAYER: connection failed")


func _apply_client_spawn_offset() -> void:
	if player == null or "--keep-spawn" in OS.get_cmdline_user_args():
		return
	player.global_position = CLIENT_SPAWN_POSITION
	player.rotation.y = CLIENT_SPAWN_YAW
	player.velocity = Vector3.ZERO


func _on_server_disconnected() -> void:
	multiplayer_ready = false
	for peer_id in remote_players.keys():
		var avatar: TestCharacter = remote_players[peer_id] as TestCharacter
		if avatar != null:
			avatar.queue_free()
	connected_peer_ids.clear()
	remote_players.clear()
	remote_states.clear()
	_clear_multiplayer_lock()
	print("MULTIPLAYER: server disconnected")


func shutdown_multiplayer() -> void:
	multiplayer_ready = false
	if multiplayer_peer != null:
		multiplayer_peer.close()
		multiplayer_peer = null
	multiplayer.multiplayer_peer = null
	connected_peer_ids.clear()
	_clear_multiplayer_lock()


func _exit_tree() -> void:
	_clear_multiplayer_lock()


func _water_material() -> ShaderMaterial:
	var material := ShaderMaterial.new()
	material.shader = ISLAND_WATER_SHADER
	material.set_shader_parameter("alpha", 0.56)
	material.set_shader_parameter("wave_height", 0.050)
	material.set_shader_parameter("wave_scale", 0.22)
	material.set_shader_parameter("wave_speed", 0.50)
	return material


func _planet_surface_material() -> ShaderMaterial:
	var material := ShaderMaterial.new()
	material.shader = PLANET_SURFACE_SHADER
	return material


func _planet_water_material() -> ShaderMaterial:
	var material := ShaderMaterial.new()
	material.shader = PLANET_WATER_SHADER
	material.set_shader_parameter("alpha", 0.16)
	return material


func _planet_atmosphere_material() -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.albedo_color = Color(0.34, 0.74, 1.0, 0.10)
	material.emission_enabled = true
	material.emission = Color(0.20, 0.55, 1.0)
	material.emission_energy_multiplier = 0.10
	material.roughness = 1.0
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	return material


func _sea_floor_material() -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.83, 0.72, 0.46, SEA_FLOOR_ALPHA)
	material.roughness = 0.92
	material.metallic = 0.0
	return material
