class_name StylizedHands
extends Control

const FILL := Color(0.82, 0.87, 0.96)
const HIGHLIGHT := Color(0.95, 0.97, 1.0)
const SHADOW := Color(0.50, 0.57, 0.68)
const OUTLINE := Color(0.012, 0.014, 0.018)
const ATTACK_STREAK := Color(0.90, 0.95, 1.0, 0.32)

var world
var player
var render_scale := 1.0
var debug_slide_preview := false
var animation_time := 0.0
var slide_amount := 0.0
var landing_pulse := 0.0
var was_on_floor := true
var look_sway := Vector2.ZERO
var smoothed_input := Vector2.ZERO
var smoothed_speed := 0.0
var stride_phase := 0.0
var slide_phase := 0.0
var slide_direction := Vector2(0.0, 1.0)
var last_yaw := 0.0
var last_pitch := 0.0
var has_last_look := false


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _process(delta: float) -> void:
	animation_time += delta
	if player == null and world != null:
		player = world.player

	var target_slide := 0.0
	if debug_slide_preview or (player != null and player.is_sliding):
		target_slide = 1.0
	slide_amount = lerpf(slide_amount, target_slide, 1.0 - exp(-13.0 * delta))

	_update_motion_smoothing(delta)
	_update_look_sway(delta)
	_update_landing_pulse(delta)
	queue_redraw()


func _update_motion_smoothing(delta: float) -> void:
	var target_input := Vector2.ZERO
	var target_speed := 0.0
	if debug_slide_preview:
		target_input = Vector2(0.0, -0.65)
		target_speed = 13.5
		smoothed_input = smoothed_input.lerp(target_input, 1.0 - exp(-16.0 * delta))
		smoothed_speed = lerpf(smoothed_speed, target_speed, 1.0 - exp(-12.0 * delta))
		slide_direction = slide_direction.lerp(Vector2(0.0, 1.0), 1.0 - exp(-12.0 * delta))
		var debug_speed_factor := clampf(smoothed_speed / 10.0, 0.0, 1.25)
		stride_phase += delta * (3.6 + debug_speed_factor * 6.8)
		if slide_amount > 0.05:
			slide_phase += delta * (2.2 + debug_speed_factor * 1.4)
		return
	if player != null:
		target_input = player.filtered_input
		target_speed = player.filtered_speed
		var target_slide_direction: Vector2 = player.slide_direction_local
		if target_slide_direction.length_squared() < 0.0001:
			target_slide_direction = Vector2(0.0, 1.0)
		slide_direction = slide_direction.lerp(target_slide_direction, 1.0 - exp(-18.0 * delta))

	smoothed_input = smoothed_input.lerp(target_input, 1.0 - exp(-16.0 * delta))
	smoothed_speed = lerpf(smoothed_speed, target_speed, 1.0 - exp(-12.0 * delta))
	var speed_factor := clampf(smoothed_speed / 10.0, 0.0, 1.25)
	stride_phase += delta * (3.6 + speed_factor * 6.8)
	if slide_amount > 0.05:
		slide_phase += delta * (2.2 + speed_factor * 1.4)


func _update_look_sway(delta: float) -> void:
	if player == null:
		look_sway = look_sway.lerp(Vector2.ZERO, 1.0 - exp(-12.0 * delta))
		return

	var yaw: float = player.global_rotation.y
	var pitch: float = player.pitch
	if not has_last_look:
		last_yaw = yaw
		last_pitch = pitch
		has_last_look = true
		return

	var yaw_delta := wrapf(yaw - last_yaw, -PI, PI)
	var pitch_delta := pitch - last_pitch
	last_yaw = yaw
	last_pitch = pitch

	var target := Vector2(
		clampf(-yaw_delta * 760.0, -34.0, 34.0),
		clampf(pitch_delta * 620.0, -28.0, 28.0)
	)
	look_sway = look_sway.lerp(target, 1.0 - exp(-20.0 * delta))


func _update_landing_pulse(delta: float) -> void:
	if player != null:
		var on_floor: bool = player.is_on_floor()
		if on_floor and not was_on_floor:
			landing_pulse = 1.0
		was_on_floor = on_floor
	landing_pulse = maxf(landing_pulse - delta * 4.8, 0.0)


func _draw() -> void:
	var viewport_size := get_viewport_rect().size
	var display_size := viewport_size / maxf(render_scale, 0.001)
	var base_scale := minf(display_size.x / 1280.0, display_size.y / 720.0) * render_scale
	var speed_factor := clampf(smoothed_speed / 10.0, 0.0, 1.25)
	var input_dir := smoothed_input
	var step := sin(stride_phase)
	var breathe := sin(animation_time * 1.25)
	var slide_ease := slide_amount * slide_amount * (3.0 - 2.0 * slide_amount)
	var slide_phase_wave := sin(slide_phase) * slide_ease * 0.45
	var slide_drop := slide_ease * 18.0 * base_scale
	var landing_drop := landing_pulse * 10.0 * base_scale
	var slide_side := clampf(slide_direction.x, -1.0, 1.0)
	var slide_forward := clampf(slide_direction.y, -1.0, 1.0)
	var left_attack := _get_attack_amount(1.0)
	var right_attack := _get_attack_amount(-1.0)
	var left_impact := _get_attack_impact(1.0)
	var right_impact := _get_attack_impact(-1.0)
	var left_attack_age := _get_attack_age(1.0)
	var right_attack_age := _get_attack_age(-1.0)

	var left_origin := Vector2(viewport_size.x * 0.17, viewport_size.y - 92.0 * base_scale)
	var right_origin := Vector2(viewport_size.x * 0.83, viewport_size.y - 92.0 * base_scale)
	var move_sway := Vector2(input_dir.x * 14.0, -input_dir.y * 8.0) * base_scale
	var bob_strength := 1.0 - slide_ease * 0.82
	var bob_left := Vector2(step * 4.0, absf(step) * 8.0 + breathe * 3.0) * speed_factor * base_scale * bob_strength
	var bob_right := Vector2(step * 4.0, -absf(step) * 6.0 - breathe * 3.0) * speed_factor * base_scale * bob_strength
	var look_offset := look_sway * base_scale

	left_origin += Vector2(-move_sway.x, move_sway.y + landing_drop + slide_drop) + bob_left + look_offset * 0.55
	right_origin += Vector2(-move_sway.x, move_sway.y + landing_drop + slide_drop) + bob_right + look_offset * 0.55
	left_origin += Vector2((-46.0 + slide_side * 18.0 + slide_phase_wave * 6.0) * base_scale, (-slide_forward * 16.0 - slide_ease * 8.0) * base_scale)
	right_origin += Vector2((46.0 + slide_side * 10.0 + slide_phase_wave * 6.0) * base_scale, (-slide_forward * 16.0 - slide_ease * 8.0) * base_scale)
	left_origin += _attack_offset(1.0, left_attack, left_impact, base_scale)
	right_origin += _attack_offset(-1.0, right_attack, right_impact, base_scale)

	var left_rotation := deg_to_rad(-12.0 + step * 1.2 * bob_strength - slide_ease * 15.0 - slide_side * 10.0 + slide_forward * 4.0) + look_sway.x * 0.0014
	var right_rotation := deg_to_rad(12.0 + step * 1.2 * bob_strength + slide_ease * 15.0 + slide_side * 10.0 + slide_forward * 4.0) + look_sway.x * 0.0014
	left_rotation += _attack_rotation(1.0, left_attack, left_impact)
	right_rotation += _attack_rotation(-1.0, right_attack, right_impact)
	var hand_scale := base_scale * lerpf(0.72, 0.65, slide_ease)
	var left_hand_scale := hand_scale * _attack_scale(left_attack, left_impact)
	var right_hand_scale := hand_scale * _attack_scale(right_attack, right_impact)
	var left_punch_pose := _attack_pose(left_attack, left_impact)
	var right_punch_pose := _attack_pose(right_attack, right_impact)
	if slide_ease > 0.05:
		_draw_slide_brace_marks(left_origin, right_origin, base_scale, slide_ease * 0.45)
	if left_punch_pose > 0.04:
		_draw_attack_trails(left_origin, left_hand_scale, 1.0, left_rotation, left_attack, left_impact, left_attack_age)
		_draw_punch_hand(left_origin, left_hand_scale, 1.0, left_rotation, left_attack, left_impact)
	else:
		_draw_hand(left_origin, left_hand_scale, 1.0, left_rotation)
	if right_punch_pose > 0.04:
		_draw_attack_trails(right_origin, right_hand_scale, -1.0, right_rotation, right_attack, right_impact, right_attack_age)
		_draw_punch_hand(right_origin, right_hand_scale, -1.0, right_rotation, right_attack, right_impact)
	else:
		_draw_hand(right_origin, right_hand_scale, -1.0, right_rotation)


func _get_attack_amount(side: float) -> float:
	if player == null:
		return 0.0
	if side > 0.0:
		return player.left_attack_amount
	return player.right_attack_amount


func _get_attack_impact(side: float) -> float:
	if player == null:
		return 0.0
	if side > 0.0:
		return player.left_attack_impact
	return player.right_attack_impact


func _get_attack_age(side: float) -> float:
	if player == null:
		return 99.0
	if side > 0.0:
		return player.left_attack_age
	return player.right_attack_age


func _attack_offset(side: float, amount: float, impact: float, base_scale: float) -> Vector2:
	var forward := maxf(amount, 0.0)
	forward = forward * forward * (3.0 - 2.0 * forward)
	var windup := maxf(-amount, 0.0)
	windup = windup * windup
	return Vector2(
		side * (forward * 104.0 - windup * 28.0),
		-forward * 64.0 + windup * 22.0 - forward * forward * 12.0 + impact * 4.0
	) * base_scale


func _attack_rotation(side: float, amount: float, impact: float) -> float:
	var forward := maxf(amount, 0.0)
	forward = forward * forward * (3.0 - 2.0 * forward)
	var windup := maxf(-amount, 0.0)
	windup = windup * windup
	return side * deg_to_rad(forward * 12.0 - windup * 9.0 - forward * forward * 3.5 - impact * 1.8)


func _attack_scale(amount: float, impact: float) -> float:
	var forward := maxf(amount, 0.0)
	forward = forward * forward * (3.0 - 2.0 * forward)
	var windup := maxf(-amount, 0.0)
	windup = windup * windup
	return 1.0 + forward * 0.02 + impact * 0.014 - windup * 0.012


func _attack_pose(amount: float, impact: float) -> float:
	return clampf(absf(amount) * 1.9 + impact * 0.45, 0.0, 1.0)


func _player_horizontal_speed() -> float:
	if player == null:
		return 0.0
	return Vector2(player.velocity.x, player.velocity.z).length()


func _draw_slide_brace_marks(left_origin: Vector2, right_origin: Vector2, base_scale: float, amount: float) -> void:
	var alpha := 0.05 + amount * 0.16
	var line_color := Color(0.015, 0.02, 0.026, alpha)
	for i in 2:
		var y_offset := (92.0 + float(i) * 9.0) * base_scale
		var left_start := left_origin + Vector2((-40.0 - float(i) * 14.0) * base_scale, y_offset)
		var left_end := left_origin + Vector2((10.0 + float(i) * 6.0) * base_scale, y_offset + 8.0 * base_scale)
		var right_start := right_origin + Vector2((40.0 + float(i) * 14.0) * base_scale, y_offset)
		var right_end := right_origin + Vector2((-10.0 - float(i) * 6.0) * base_scale, y_offset + 8.0 * base_scale)
		draw_line(left_start, left_end, line_color, 2.0 * base_scale, true)
		draw_line(right_start, right_end, line_color, 2.0 * base_scale, true)


func _draw_attack_trails(origin: Vector2, scale_value: float, side: float, rotation: float, amount: float, impact: float, age: float) -> void:
	var forward := maxf(amount, 0.0)
	var strength := clampf(forward * 0.70 + impact * 0.90, 0.0, 1.0)
	if strength < 0.025:
		return

	for i in 4:
		var offset := float(i) * 22.0
		var alpha := (0.10 + strength * 0.20) * (1.0 - float(i) * 0.15)
		var streak_width := (3.0 + strength * 3.2) * scale_value * (1.0 - float(i) * 0.12)
		var from_point := Vector2(-88.0 - offset, 158.0 + offset * 0.18)
		var to_point := Vector2(-18.0 - offset * 0.18, 100.0 - strength * 12.0 + offset * 0.04)
		draw_line(
			_transform_point(from_point, origin, scale_value, side, rotation, 0.0),
			_transform_point(to_point, origin, scale_value, side, rotation, 0.0),
			Color(ATTACK_STREAK, alpha),
			streak_width,
			true
		)

func _draw_punch_hand(origin: Vector2, scale_value: float, side: float, rotation: float, amount: float, impact: float) -> void:
	var forward := maxf(amount, 0.0)
	forward = forward * forward * (3.0 - 2.0 * forward)
	var windup := maxf(-amount, 0.0)
	windup = windup * windup
	var strike_rotation := rotation + side * deg_to_rad(forward * 4.0 - windup * 3.0 - impact * 1.4)
	var strike_scale := scale_value * (1.0 - windup * 0.02 + forward * 0.018)
	_draw_hand(origin, strike_scale, side, strike_rotation)


func _draw_hand(origin: Vector2, scale_value: float, side: float, rotation: float, clench: float = 0.0) -> void:
	var outline_width := 5.0 * scale_value
	var detail_width := 2.5 * scale_value

	_draw_shape([
		Vector2(-54.0, 220.0),
		Vector2(-82.0, 130.0),
		Vector2(-70.0, 56.0),
		Vector2(-23.0, 58.0),
		Vector2(39.0, 205.0),
		Vector2(4.0, 224.0),
	], origin, scale_value, side, rotation, Color(FILL, 0.94), outline_width, clench)

	_draw_shape([
		Vector2(-41.0, 11.0),
		Vector2(-42.0, -42.0),
		Vector2(-28.0, -92.0),
		Vector2(-5.0, -107.0),
		Vector2(13.0, -91.0),
		Vector2(3.0, -34.0),
		Vector2(-9.0, 8.0),
	], origin, scale_value, side, rotation, FILL, outline_width, clench)

	_draw_shape([
		Vector2(-6.0, -6.0),
		Vector2(4.0, -64.0),
		Vector2(28.0, -126.0),
		Vector2(53.0, -134.0),
		Vector2(67.0, -111.0),
		Vector2(49.0, -54.0),
		Vector2(31.0, 2.0),
	], origin, scale_value, side, rotation, FILL, outline_width, clench)

	_draw_shape([
		Vector2(30.0, 6.0),
		Vector2(54.0, -43.0),
		Vector2(83.0, -80.0),
		Vector2(106.0, -75.0),
		Vector2(117.0, -54.0),
		Vector2(88.0, -14.0),
		Vector2(63.0, 23.0),
	], origin, scale_value, side, rotation, FILL, outline_width, clench)

	_draw_shape([
		Vector2(50.0, 54.0),
		Vector2(82.0, 15.0),
		Vector2(126.0, 3.0),
		Vector2(145.0, 25.0),
		Vector2(134.0, 53.0),
		Vector2(93.0, 70.0),
		Vector2(66.0, 78.0),
	], origin, scale_value, side, rotation, Color(FILL, 0.98), outline_width, clench)

	var palm := [
		Vector2(-60.0, 130.0),
		Vector2(-62.0, 67.0),
		Vector2(-45.0, 18.0),
		Vector2(-10.0, -11.0),
		Vector2(34.0, -5.0),
		Vector2(69.0, 42.0),
		Vector2(65.0, 108.0),
		Vector2(33.0, 145.0),
		Vector2(-17.0, 151.0),
	]
	var palm_points := _transform_points(palm, origin, scale_value, side, rotation, clench)
	draw_colored_polygon(palm_points, FILL)
	draw_polyline(_closed(palm_points), OUTLINE, outline_width, true)

	draw_colored_polygon(_transform_points([
		Vector2(-49.0, 35.0),
		Vector2(-13.0, -2.0),
		Vector2(28.0, 3.0),
		Vector2(52.0, 40.0),
		Vector2(18.0, 73.0),
		Vector2(-26.0, 69.0),
	], origin, scale_value, side, rotation, clench), Color(HIGHLIGHT, 0.55))

	draw_colored_polygon(_transform_points([
		Vector2(-57.0, 82.0),
		Vector2(-28.0, 138.0),
		Vector2(30.0, 146.0),
		Vector2(2.0, 205.0),
		Vector2(-54.0, 220.0),
		Vector2(-80.0, 132.0),
	], origin, scale_value, side, rotation, clench), Color(SHADOW, 0.46))

	_draw_detail_line([Vector2(-34.0, 16.0), Vector2(-8.0, -11.0), Vector2(27.0, -8.0)], origin, scale_value, side, rotation, detail_width, clench)
	_draw_detail_line([Vector2(37.0, 8.0), Vector2(58.0, 39.0), Vector2(60.0, 74.0)], origin, scale_value, side, rotation, detail_width, clench)
	_draw_detail_line([Vector2(60.0, 55.0), Vector2(88.0, 65.0), Vector2(123.0, 50.0)], origin, scale_value, side, rotation, detail_width, clench)
	_draw_detail_line([Vector2(-44.0, 86.0), Vector2(-15.0, 101.0), Vector2(7.0, 126.0)], origin, scale_value, side, rotation, detail_width, clench)
	_draw_scratch(Vector2(-27.0, 43.0), Vector2(-18.0, 49.0), origin, scale_value, side, rotation, detail_width * 0.8, clench)
	_draw_scratch(Vector2(13.0, 53.0), Vector2(22.0, 60.0), origin, scale_value, side, rotation, detail_width * 0.75, clench)
	_draw_scratch(Vector2(81.0, -50.0), Vector2(89.0, -43.0), origin, scale_value, side, rotation, detail_width * 0.75, clench)


func _transform_points(points: Array, origin: Vector2, scale_value: float, side: float, rotation: float, clench: float = 0.0) -> PackedVector2Array:
	var result := PackedVector2Array()
	for point in points:
		result.append(_transform_point(point, origin, scale_value, side, rotation, clench))
	return result


func _draw_shape(points: Array, origin: Vector2, scale_value: float, side: float, rotation: float, color: Color, outline_width: float, clench: float = 0.0) -> void:
	var transformed := _transform_points(points, origin, scale_value, side, rotation, clench)
	draw_colored_polygon(transformed, color)
	draw_polyline(_closed(transformed), OUTLINE, outline_width, true)


func _transform_point(point: Vector2, origin: Vector2, scale_value: float, side: float, rotation: float, clench: float = 0.0) -> Vector2:
	var posed := point
	if clench > 0.001 and point.y < 90.0:
		var finger_fold := clampf((90.0 - point.y) / 220.0, 0.0, 1.0) * clench
		posed.y += finger_fold * 18.0
		posed.x *= lerpf(1.0, 0.90, finger_fold)
	var mirrored := Vector2(posed.x * side, posed.y)
	return origin + mirrored.rotated(rotation * side) * scale_value


func _closed(points: PackedVector2Array) -> PackedVector2Array:
	var closed := PackedVector2Array(points)
	if points.size() > 0:
		closed.append(points[0])
	return closed


func _draw_detail_line(points: Array, origin: Vector2, scale_value: float, side: float, rotation: float, width: float, clench: float = 0.0) -> void:
	draw_polyline(_transform_points(points, origin, scale_value, side, rotation, clench), OUTLINE, width, true)


func _draw_scratch(from_point: Vector2, to_point: Vector2, origin: Vector2, scale_value: float, side: float, rotation: float, width: float, clench: float = 0.0) -> void:
	draw_line(
		_transform_point(from_point, origin, scale_value, side, rotation, clench),
		_transform_point(to_point, origin, scale_value, side, rotation, clench),
		OUTLINE,
		width,
		true
	)
