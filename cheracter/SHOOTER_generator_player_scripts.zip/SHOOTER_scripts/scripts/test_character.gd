class_name TestCharacter
extends Node3D

const PLAYER_SHADOW_SCRIPT := preload("res://scripts/player_shadow.gd")

const WHITE := Color(0.92, 0.95, 1.0)
const EYE_WHITE := Color(0.96, 0.98, 1.0)
const SHADOW_BLUE := Color(0.50, 0.60, 0.72)
const OUTLINE := Color(0.01, 0.012, 0.016)
const EYE_COLOR := Color(0.0, 0.0, 0.0)
const SHIRT_ORANGE := Color(1.0, 0.60, 0.02)
const SHIRT_DARK_ORANGE := Color(0.90, 0.36, 0.02)
const SHIRT_PATTERN := Color(0.98, 0.98, 0.88)
const PLANT_STEM := Color(0.24, 0.32, 0.08)
const PLANT_LEAF := Color(0.42, 0.63, 0.16)
const PLANT_LEAF_DARK := Color(0.20, 0.38, 0.08)
const PLANT_LEAF_LIGHT := Color(0.66, 0.80, 0.26)
const LEFT_LEG_BASE := Vector3(-0.125, 0.58, 0.02)
const RIGHT_LEG_BASE := Vector3(0.125, 0.58, 0.02)
const LOWER_LEG_BASE := Vector3(0.0, -0.300, 0.012)
const SHIN_LOCAL_BASE := Vector3(0.0, -0.150, 0.0)
const FOOT_LOCAL_BASE := Vector3(0.0, -0.225, -0.075)
const LEFT_EYE_BASE := Vector3(-0.17, -0.035, -0.370)
const RIGHT_EYE_BASE := Vector3(0.17, -0.035, -0.370)
const WALK_FULL_SPEED := 4.4
const CROUCH_HEIGHT_SCALE := 1.18 / 2.35
const EYE_LOOK_RADIUS := 7.0
const BASE_BLINK_MIN := 14.0
const BASE_BLINK_VARIATION := 8.0
const SUN_BLINK_MIN := 0.65
const SUN_BLINK_VARIATION := 0.55
const SUN_LOOK_DOT_START := 0.84
const SUN_GAZE_CHARGE_SECONDS := 2.8
const SUN_GAZE_DECAY_SECONDS := 1.4
const BLINK_CLOSE_SPEED := 12.5
const SUN_BLINK_CLOSE_SPEED := 14.0
const BLINK_OPEN_SPEED := 8.0
const SUN_BLINK_OPEN_SPEED := 9.0
const BLINK_HOLD_SECONDS := 0.020
const SUN_BLINK_HOLD_SECONDS := 0.035
const PLAYER_BLOCKER_HEIGHT := 2.00
const PLAYER_BLOCKER_CROUCH_HEIGHT := 1.03
const PLAYER_BLOCKER_RADIUS := 0.28

var target: Node3D
var face_target_enabled := true
var blocks_players := false
var hide_head_for_owner := false
var blocker_collision_layer := 2
var blocker_collision_mask := 2
var sun_direction := Vector3.ZERO
var sun_gaze_charge := 0.0
var external_velocity := Vector3.ZERO
var external_move_speed := 0.0
var external_stance_amount := 0.0
var external_pitch := 0.0
var external_on_floor := true
var animation_time := 0.0
var blink_amount := 0.0
var blink_timer := 1.4
var blink_closing := false
var blink_hold_timer := 0.0
var body_root: Node3D
var head_root: Node3D
var left_eye_white: Node3D
var right_eye_white: Node3D
var left_eye: MeshInstance3D
var right_eye: MeshInstance3D
var left_eye_glint: MeshInstance3D
var right_eye_glint: MeshInstance3D
var sprout_root: Node3D
var sprout_stem: Node3D
var left_sprout_leaf: Node3D
var right_sprout_leaf: Node3D
var player_blocker: StaticBody3D
var player_blocker_shape: CapsuleShape3D
var player_blocker_collision: CollisionShape3D
var player_shadow
var left_arm: Node3D
var right_arm: Node3D
var left_leg: Node3D
var right_leg: Node3D
var left_lower_leg: Node3D
var right_lower_leg: Node3D
var left_foot: Node3D
var right_foot: Node3D
var turn_intensity := 0.0
var turn_activity := 0.0
var turn_phase := 0.0
var turn_yaw_error := 0.0
var turn_speed := 0.0
var previous_yaw := 0.0
var walk_direction_local := Vector2(0.0, 1.0)
var walk_activity := 0.0
var visual_stance_amount := 0.0
var previous_external_on_floor := true
var jump_amount := 0.0
var jump_air_time := 0.0
var takeoff_amount := 0.0
var landing_amount := 0.0
var landing_settle_amount := 0.0
var gaze_activity := 0.0
var eye_focus := Vector2.ZERO
var eye_dart := Vector2.ZERO
var eye_dart_timer := 0.0
var locked_eye_target: Node3D
var eye_target_lock_time := 0.0


func _ready() -> void:
	_build_character()
	_build_player_shadow()
	if blocks_players:
		_build_player_blocker()
	_apply_owner_visibility()
	blink_timer = _next_blink_interval()
	if target != null and face_target_enabled:
		rotation.y = _target_yaw()
	previous_yaw = rotation.y


func _process(delta: float) -> void:
	animation_time += delta
	eye_target_lock_time = maxf(eye_target_lock_time - delta, 0.0)
	if face_target_enabled:
		_face_target(delta)
	else:
		_update_external_motion(delta)
	_animate_body(delta)
	_animate_eyes(delta)


func force_blink() -> void:
	_start_blink()


func get_blink_amount() -> float:
	return blink_amount


func get_sun_blink_intensity() -> float:
	return _sun_blink_intensity()


func set_head_visible_for_owner(visible_for_owner: bool) -> void:
	hide_head_for_owner = not visible_for_owner
	_apply_owner_visibility()


func set_eye_target(new_target: Node3D) -> void:
	if new_target == target:
		locked_eye_target = new_target
		return
	if new_target == null:
		target = null
		locked_eye_target = null
		eye_target_lock_time = 0.0
		return
	if target != null and eye_target_lock_time > 0.0:
		var current_distance := get_look_target_position().distance_to(_look_position_for_node(target))
		var new_distance := get_look_target_position().distance_to(_look_position_for_node(new_target))
		if new_distance >= current_distance * 0.65:
			return
	target = new_target
	locked_eye_target = new_target
	eye_target_lock_time = 0.65


func _build_character() -> void:
	body_root = Node3D.new()
	body_root.name = "BodyRoot"
	add_child(body_root)

	var body := _box_mesh(Vector3(0.34, 0.88, 0.25))
	_add_outlined_part(body_root, "Body", body, Vector3(0.0, 0.94, 0.0), Vector3.ZERO, Vector3.ONE, WHITE, 1.055)
	_add_hawaiian_shirt_torso(body_root)
	left_leg = _make_part_root(body_root, "LeftLeg", LEFT_LEG_BASE)
	right_leg = _make_part_root(body_root, "RightLeg", RIGHT_LEG_BASE)
	_add_outlined_part(left_leg, "LeftThigh", _capsule_mesh(0.066, 0.35), Vector3(0.0, -0.16, 0.0), Vector3.ZERO, Vector3.ONE, WHITE, 1.08)
	left_lower_leg = _make_part_root(left_leg, "LeftLowerLeg", LOWER_LEG_BASE)
	_add_outlined_part(left_lower_leg, "LeftShin", _capsule_mesh(0.058, 0.38), SHIN_LOCAL_BASE, Vector3.ZERO, Vector3.ONE, WHITE, 1.08)
	_add_outlined_part(right_leg, "RightThigh", _capsule_mesh(0.066, 0.35), Vector3(0.0, -0.16, 0.0), Vector3.ZERO, Vector3.ONE, WHITE, 1.08)
	right_lower_leg = _make_part_root(right_leg, "RightLowerLeg", LOWER_LEG_BASE)
	_add_outlined_part(right_lower_leg, "RightShin", _capsule_mesh(0.058, 0.38), SHIN_LOCAL_BASE, Vector3.ZERO, Vector3.ONE, WHITE, 1.08)
	left_foot = _add_outlined_part(left_lower_leg, "LeftFoot", _box_mesh(Vector3(0.16, 0.09, 0.27)), FOOT_LOCAL_BASE, Vector3.ZERO, Vector3.ONE, WHITE, 1.08)
	right_foot = _add_outlined_part(right_lower_leg, "RightFoot", _box_mesh(Vector3(0.16, 0.09, 0.27)), FOOT_LOCAL_BASE, Vector3.ZERO, Vector3.ONE, WHITE, 1.08)

	left_arm = _add_outlined_part(body_root, "LeftArm", _capsule_mesh(0.066, 0.74), Vector3(-0.285, 0.96, 0.0), Vector3(0.0, 0.0, deg_to_rad(-10.0)), Vector3.ONE, WHITE, 1.08)
	right_arm = _add_outlined_part(body_root, "RightArm", _capsule_mesh(0.066, 0.74), Vector3(0.285, 0.96, 0.0), Vector3(0.0, 0.0, deg_to_rad(10.0)), Vector3.ONE, WHITE, 1.08)
	_add_hawaiian_sleeves()

	head_root = Node3D.new()
	head_root.name = "HeadRoot"
	head_root.position = Vector3(0.0, 1.60, 0.0)
	body_root.add_child(head_root)
	_add_outlined_part(head_root, "CubeHead", _box_mesh(Vector3(0.68, 0.64, 0.64)), Vector3.ZERO, Vector3.ZERO, Vector3.ONE, WHITE, 1.045)
	_add_part(head_root, "MouthLine", _box_mesh(Vector3(0.42, 0.030, 0.022)), Vector3(0.0, -0.16, -0.342), Vector3.ZERO, Vector3.ONE, OUTLINE)

	left_eye_white = _add_outlined_part(head_root, "LeftEyeWhite", _sphere_mesh(0.082), LEFT_EYE_BASE + Vector3(0.0, 0.0, 0.004), Vector3.ZERO, Vector3(1.46, 1.02, 0.10), EYE_WHITE, 1.18)
	right_eye_white = _add_outlined_part(head_root, "RightEyeWhite", _sphere_mesh(0.082), RIGHT_EYE_BASE + Vector3(0.0, 0.0, 0.004), Vector3.ZERO, Vector3(1.46, 1.02, 0.10), EYE_WHITE, 1.18)
	left_eye = _add_part(head_root, "LeftPupil", _sphere_mesh(0.046), LEFT_EYE_BASE + Vector3(0.0, 0.0, -0.030), Vector3.ZERO, Vector3(1.0, 1.0, 0.12), EYE_COLOR)
	right_eye = _add_part(head_root, "RightPupil", _sphere_mesh(0.046), RIGHT_EYE_BASE + Vector3(0.0, 0.0, -0.030), Vector3.ZERO, Vector3(1.0, 1.0, 0.12), EYE_COLOR)
	left_eye_glint = _add_part(head_root, "LeftEyeGlint", _sphere_mesh(0.014), LEFT_EYE_BASE + Vector3(-0.014, 0.014, -0.044), Vector3.ZERO, Vector3(1.0, 1.0, 0.10), WHITE)
	right_eye_glint = _add_part(head_root, "RightEyeGlint", _sphere_mesh(0.014), RIGHT_EYE_BASE + Vector3(-0.014, 0.014, -0.044), Vector3.ZERO, Vector3(1.0, 1.0, 0.10), WHITE)
	_add_head_sprout()


func _build_player_shadow() -> void:
	player_shadow = PLAYER_SHADOW_SCRIPT.new()
	player_shadow.name = "PlayerShadow"
	add_child(player_shadow)
	_update_player_shadow(0.0, 0.0)


func _apply_owner_visibility() -> void:
	if head_root != null:
		head_root.visible = not hide_head_for_owner


func _add_hawaiian_shirt_torso(parent: Node) -> void:
	_add_part(parent, "ShirtShell", _box_mesh(Vector3(0.370, 0.805, 0.282)), Vector3(0.0, 0.925, 0.000), Vector3.ZERO, Vector3.ONE, SHIRT_ORANGE)
	_add_part(parent, "ShirtBack", _box_mesh(Vector3(0.310, 0.770, 0.006)), Vector3(0.0, 0.925, 0.146), Vector3.ZERO, Vector3.ONE, SHIRT_ORANGE)
	_add_part(parent, "LeftShirtSide", _box_mesh(Vector3(0.006, 0.760, 0.190)), Vector3(-0.188, 0.925, 0.000), Vector3.ZERO, Vector3.ONE, SHIRT_ORANGE)
	_add_part(parent, "RightShirtSide", _box_mesh(Vector3(0.006, 0.760, 0.190)), Vector3(0.188, 0.925, 0.000), Vector3.ZERO, Vector3.ONE, SHIRT_ORANGE)
	_add_part(parent, "LeftShirtPanel", _box_mesh(Vector3(0.128, 0.780, 0.006)), Vector3(-0.084, 0.925, -0.146), Vector3.ZERO, Vector3.ONE, SHIRT_ORANGE)
	_add_part(parent, "RightShirtPanel", _box_mesh(Vector3(0.128, 0.780, 0.006)), Vector3(0.084, 0.925, -0.146), Vector3.ZERO, Vector3.ONE, SHIRT_ORANGE)
	_add_part(parent, "ShirtFrontHem", _box_mesh(Vector3(0.304, 0.032, 0.008)), Vector3(0.0, 0.532, -0.148), Vector3.ZERO, Vector3.ONE, SHIRT_DARK_ORANGE)
	_add_part(parent, "ShirtBackHem", _box_mesh(Vector3(0.304, 0.032, 0.008)), Vector3(0.0, 0.532, 0.148), Vector3.ZERO, Vector3.ONE, SHIRT_DARK_ORANGE)
	_add_part(parent, "LeftShirtSideHem", _box_mesh(Vector3(0.008, 0.032, 0.170)), Vector3(-0.190, 0.532, 0.000), Vector3.ZERO, Vector3.ONE, SHIRT_DARK_ORANGE)
	_add_part(parent, "RightShirtSideHem", _box_mesh(Vector3(0.008, 0.032, 0.170)), Vector3(0.190, 0.532, 0.000), Vector3.ZERO, Vector3.ONE, SHIRT_DARK_ORANGE)
	_add_part(parent, "LeftShirtOpening", _box_mesh(Vector3(0.012, 0.720, 0.008)), Vector3(-0.023, 0.905, -0.153), Vector3.ZERO, Vector3.ONE, SHIRT_DARK_ORANGE)
	_add_part(parent, "RightShirtOpening", _box_mesh(Vector3(0.012, 0.720, 0.008)), Vector3(0.023, 0.905, -0.153), Vector3.ZERO, Vector3.ONE, SHIRT_DARK_ORANGE)
	_add_part(parent, "LeftCollar", _box_mesh(Vector3(0.106, 0.182, 0.020)), Vector3(-0.068, 1.336, -0.152), Vector3(0.0, 0.0, deg_to_rad(-27.0)), Vector3.ONE, SHIRT_ORANGE)
	_add_part(parent, "RightCollar", _box_mesh(Vector3(0.106, 0.182, 0.020)), Vector3(0.068, 1.336, -0.152), Vector3(0.0, 0.0, deg_to_rad(27.0)), Vector3.ONE, SHIRT_ORANGE)
	_add_part(parent, "BackCollar", _box_mesh(Vector3(0.220, 0.068, 0.026)), Vector3(0.0, 1.342, 0.136), Vector3.ZERO, Vector3.ONE, SHIRT_ORANGE)

	for index in 5:
		_add_part(parent, "ShirtButton%d" % index, _sphere_mesh(0.011), Vector3(0.024, 1.200 - float(index) * 0.128, -0.160), Vector3.ZERO, Vector3(1.0, 1.0, 0.16), SHIRT_PATTERN)

	_add_floral_cluster(parent, "LeftChestFlower", Vector3(-0.106, 1.165, -0.162), 0.026, deg_to_rad(-18.0))
	_add_floral_cluster(parent, "RightChestFlower", Vector3(0.106, 1.088, -0.162), 0.025, deg_to_rad(25.0))
	_add_floral_cluster(parent, "LeftLowerFlower", Vector3(-0.104, 0.755, -0.162), 0.023, deg_to_rad(10.0))
	_add_floral_cluster(parent, "RightLowerFlower", Vector3(0.104, 0.700, -0.162), 0.026, deg_to_rad(-30.0))
	_add_leaf_pair(parent, "LeftTorsoLeaves", Vector3(-0.096, 0.980, -0.164), 0.036, deg_to_rad(36.0))
	_add_leaf_pair(parent, "RightTorsoLeaves", Vector3(0.104, 0.880, -0.164), 0.038, deg_to_rad(-42.0))
	_add_leaf_pair(parent, "LeftHemLeaves", Vector3(-0.064, 0.585, -0.164), 0.030, deg_to_rad(-18.0))
	_add_leaf_pair(parent, "RightHemLeaves", Vector3(0.064, 0.585, -0.164), 0.030, deg_to_rad(18.0))
	_add_floral_cluster_on_z(parent, "BackShoulderFlower", Vector3(-0.104, 1.145, 0.162), 0.024, deg_to_rad(18.0), 1.0)
	_add_floral_cluster_on_z(parent, "BackLowerFlower", Vector3(0.098, 0.760, 0.162), 0.026, deg_to_rad(-24.0), 1.0)
	_add_leaf_pair_on_z(parent, "BackTorsoLeaves", Vector3(0.090, 1.000, 0.164), 0.036, deg_to_rad(-32.0), 1.0)
	_add_leaf_pair_on_z(parent, "BackHemLeaves", Vector3(-0.082, 0.604, 0.164), 0.030, deg_to_rad(28.0), 1.0)
	_add_side_leaf_pair(parent, "LeftSideLeaves", Vector3(-0.190, 0.970, -0.028), 0.030, deg_to_rad(14.0), -1.0)
	_add_side_leaf_pair(parent, "RightSideLeaves", Vector3(0.190, 0.805, 0.034), 0.032, deg_to_rad(-18.0), 1.0)


func _add_hawaiian_sleeves() -> void:
	_add_outlined_part(left_arm, "LeftHawaiianSleeve", _capsule_mesh(0.086, 0.340), Vector3(0.0, 0.185, 0.0), Vector3.ZERO, Vector3.ONE, SHIRT_ORANGE, 1.05)
	_add_outlined_part(right_arm, "RightHawaiianSleeve", _capsule_mesh(0.086, 0.340), Vector3(0.0, 0.185, 0.0), Vector3.ZERO, Vector3.ONE, SHIRT_ORANGE, 1.05)
	_add_floral_cluster(left_arm, "LeftSleeveFlower", Vector3(0.000, 0.225, -0.090), 0.017, deg_to_rad(12.0))
	_add_floral_cluster(right_arm, "RightSleeveFlower", Vector3(0.000, 0.225, -0.090), 0.017, deg_to_rad(-12.0))
	_add_floral_cluster_on_z(left_arm, "LeftSleeveBackFlower", Vector3(0.000, 0.125, 0.090), 0.015, deg_to_rad(-18.0), 1.0)
	_add_floral_cluster_on_z(right_arm, "RightSleeveBackFlower", Vector3(0.000, 0.125, 0.090), 0.015, deg_to_rad(18.0), 1.0)


func _add_head_sprout() -> void:
	sprout_root = Node3D.new()
	sprout_root.name = "HeadSprout"
	sprout_root.position = Vector3(0.0, 0.348, -0.010)
	head_root.add_child(sprout_root)

	sprout_stem = _add_outlined_part(sprout_root, "SproutStem", _capsule_mesh(0.012, 0.300), Vector3(0.0, 0.140, 0.0), Vector3(0.0, 0.0, deg_to_rad(1.0)), Vector3.ONE, PLANT_STEM, 1.10)
	_add_part(sprout_root, "SproutBase", _sphere_mesh(0.024), Vector3(0.0, 0.000, 0.0), Vector3.ZERO, Vector3(1.1, 0.42, 0.68), PLANT_LEAF_DARK)

	left_sprout_leaf = _add_sprout_leaf(
		sprout_root,
		"LeftSproutLeaf",
		Vector3(-0.074, 0.274, -0.012),
		Vector3(0.0, deg_to_rad(-6.0), deg_to_rad(-39.0)),
		Vector3(1.78, 0.52, 0.060),
		0.052
	)
	right_sprout_leaf = _add_sprout_leaf(
		sprout_root,
		"RightSproutLeaf",
		Vector3(0.074, 0.274, -0.012),
		Vector3(0.0, deg_to_rad(6.0), deg_to_rad(39.0)),
		Vector3(1.78, 0.52, 0.060),
		0.052
	)


func _add_sprout_leaf(parent: Node, leaf_name: String, leaf_position: Vector3, leaf_rotation: Vector3, leaf_scale: Vector3, radius: float) -> Node3D:
	var leaf := _add_outlined_part(parent, leaf_name, _sphere_mesh(radius), leaf_position, leaf_rotation, leaf_scale, PLANT_LEAF, 1.06)
	_add_part(leaf, "MidVein", _box_mesh(Vector3(radius * 3.25, radius * 0.060, radius * 0.035)), Vector3(0.0, 0.0, -radius * 0.055), Vector3.ZERO, Vector3.ONE, PLANT_LEAF_LIGHT)
	for vein_index in 4:
		var x := -radius * 0.80 + float(vein_index) * radius * 0.52
		var side := 1.0 if vein_index % 2 == 0 else -1.0
		_add_part(
			leaf,
			"SideVein%d" % vein_index,
			_box_mesh(Vector3(radius * 0.78, radius * 0.040, radius * 0.028)),
			Vector3(x, side * radius * 0.15, -radius * 0.070),
			Vector3(0.0, 0.0, side * deg_to_rad(24.0)),
			Vector3.ONE,
			PLANT_LEAF_LIGHT
		)
	return leaf


func _build_player_blocker() -> void:
	player_blocker = StaticBody3D.new()
	player_blocker.name = "PlayerBlocker"
	player_blocker.collision_layer = blocker_collision_layer
	player_blocker.collision_mask = blocker_collision_mask
	add_child(player_blocker)

	player_blocker_shape = CapsuleShape3D.new()
	player_blocker_shape.radius = PLAYER_BLOCKER_RADIUS
	player_blocker_shape.height = PLAYER_BLOCKER_HEIGHT

	player_blocker_collision = CollisionShape3D.new()
	player_blocker_collision.name = "PlayerBlockerShape"
	player_blocker_collision.shape = player_blocker_shape
	player_blocker_collision.position = Vector3(0.0, PLAYER_BLOCKER_HEIGHT * 0.5, 0.0)
	player_blocker.add_child(player_blocker_collision)


func _update_player_blocker(crouch: float) -> void:
	if player_blocker_shape == null or player_blocker_collision == null:
		return
	var blocker_height := lerpf(PLAYER_BLOCKER_HEIGHT, PLAYER_BLOCKER_CROUCH_HEIGHT, clampf(crouch, 0.0, 1.0))
	player_blocker_shape.height = blocker_height
	player_blocker_collision.position.y = blocker_height * 0.5


func _add_floral_cluster(parent: Node, base_name: String, center: Vector3, radius: float, rotation_offset: float) -> void:
	_add_floral_cluster_on_z(parent, base_name, center, radius, rotation_offset, -1.0)


func _add_floral_cluster_on_z(parent: Node, base_name: String, center: Vector3, radius: float, rotation_offset: float, normal_z: float) -> void:
	_add_part(parent, base_name + "Center", _sphere_mesh(radius * 0.34), center + Vector3(0.0, 0.0, normal_z * 0.004), Vector3.ZERO, Vector3(1.0, 1.0, 0.12), SHIRT_PATTERN)
	for petal_index in 5:
		var angle := rotation_offset + float(petal_index) / 5.0 * TAU
		var petal_position := center + Vector3(cos(angle) * radius * 0.82, sin(angle) * radius * 0.82, normal_z * 0.006)
		_add_part(parent, "%sPetal%d" % [base_name, petal_index], _sphere_mesh(radius * 0.47), petal_position, Vector3(0.0, 0.0, angle), Vector3(1.45, 0.45, 0.10), SHIRT_PATTERN)


func _add_leaf_pair(parent: Node, base_name: String, center: Vector3, radius: float, rotation_offset: float) -> void:
	_add_leaf_pair_on_z(parent, base_name, center, radius, rotation_offset, -1.0)


func _add_leaf_pair_on_z(parent: Node, base_name: String, center: Vector3, radius: float, rotation_offset: float, normal_z: float) -> void:
	for leaf_index in 4:
		var angle := rotation_offset + float(leaf_index) * deg_to_rad(54.0)
		var leaf_position := center + Vector3(cos(angle) * radius * 0.42, sin(angle) * radius * 0.42, normal_z * 0.006)
		_add_part(parent, "%sLeaf%d" % [base_name, leaf_index], _sphere_mesh(radius * 0.34), leaf_position, Vector3(0.0, 0.0, angle), Vector3(1.80, 0.34, 0.08), SHIRT_PATTERN)


func _add_side_leaf_pair(parent: Node, base_name: String, center: Vector3, radius: float, rotation_offset: float, side_sign: float) -> void:
	for leaf_index in 4:
		var angle := rotation_offset + float(leaf_index) * deg_to_rad(54.0)
		var leaf_position := center + Vector3(side_sign * 0.006, sin(angle) * radius * 0.42, cos(angle) * radius * 0.42)
		_add_part(parent, "%sLeaf%d" % [base_name, leaf_index], _sphere_mesh(radius * 0.34), leaf_position, Vector3(angle, 0.0, 0.0), Vector3(0.08, 1.80, 0.34), SHIRT_PATTERN)


func _face_target(delta: float) -> void:
	if target == null:
		return
	var to_target := _target_look_position() - global_position
	to_target.y = 0.0
	if to_target.length_squared() < 0.001:
		return
	gaze_activity = lerpf(gaze_activity, _target_presence(), 1.0 - exp(-8.5 * delta))
	var target_yaw := _target_yaw()
	var yaw_error := wrapf(target_yaw - rotation.y, -PI, PI)
	rotation.y = lerp_angle(rotation.y, target_yaw, 1.0 - exp(-5.5 * delta))

	var yaw_step := wrapf(rotation.y - previous_yaw, -PI, PI)
	previous_yaw = rotation.y
	var turn_from_step := yaw_step / maxf(delta * 4.6, 0.001)
	turn_yaw_error = yaw_error
	turn_speed = lerpf(turn_speed, yaw_step / maxf(delta, 0.001), 1.0 - exp(-12.0 * delta))
	var target_turn := clampf(yaw_error * 1.35 + turn_from_step * 0.42, -1.0, 1.0)
	var target_activity := clampf(absf(yaw_error) * 1.9 + absf(turn_speed) * 0.16, 0.0, 1.0)
	turn_intensity = lerpf(turn_intensity, target_turn, 1.0 - exp(-11.0 * delta))
	turn_activity = lerpf(turn_activity, target_activity, 1.0 - exp(-9.0 * delta))


func _update_external_motion(delta: float) -> void:
	var yaw_step := wrapf(rotation.y - previous_yaw, -PI, PI)
	previous_yaw = rotation.y
	turn_yaw_error = 0.0
	turn_speed = lerpf(turn_speed, yaw_step / maxf(delta, 0.001), 1.0 - exp(-12.0 * delta))
	gaze_activity = lerpf(gaze_activity, _target_presence(), 1.0 - exp(-8.5 * delta))

	var horizontal_velocity := Vector3(external_velocity.x, 0.0, external_velocity.z)
	var measured_speed := horizontal_velocity.length()
	if not external_on_floor:
		measured_speed *= 0.45
	var move_speed := maxf(external_move_speed, measured_speed)
	var speed_activity := clampf(move_speed / WALK_FULL_SPEED, 0.0, 1.0)
	var target_walk_direction := walk_direction_local
	if measured_speed > 0.04:
		var local_velocity: Vector3 = global_transform.basis.inverse() * horizontal_velocity
		target_walk_direction = Vector2(local_velocity.x, -local_velocity.z)
		if target_walk_direction.length_squared() > 0.0001:
			target_walk_direction = target_walk_direction.normalized()
	elif speed_activity > 0.05:
		target_walk_direction = Vector2(0.0, 1.0)

	var walk_blend := 1.0 - exp(-14.0 * delta)
	walk_direction_local = walk_direction_local.lerp(target_walk_direction, walk_blend)
	if walk_direction_local.length_squared() > 1.0:
		walk_direction_local = walk_direction_local.normalized()
	walk_activity = lerpf(walk_activity, speed_activity, 1.0 - exp(-12.0 * delta))
	visual_stance_amount = lerpf(visual_stance_amount, clampf(external_stance_amount, 0.0, 1.0), 1.0 - exp(-16.0 * delta))
	_update_jump_state(delta)

	var stance_activity := visual_stance_amount * 0.40
	var turn_activity_target := clampf(absf(turn_speed) * 0.16, 0.0, 1.0)
	var target_turn := clampf(turn_speed * 0.18, -1.0, 1.0)
	var target_activity := maxf(maxf(maxf(walk_activity, stance_activity), jump_amount * 0.55), turn_activity_target)

	turn_intensity = lerpf(turn_intensity, target_turn, 1.0 - exp(-11.0 * delta))
	turn_activity = lerpf(turn_activity, target_activity, 1.0 - exp(-9.0 * delta))


func _update_jump_state(delta: float) -> void:
	if previous_external_on_floor and not external_on_floor:
		jump_amount = maxf(jump_amount, 0.75)
		takeoff_amount = 1.0
		landing_amount = 0.0
		landing_settle_amount = 0.0
		jump_air_time = 0.0
	if not previous_external_on_floor and external_on_floor:
		landing_amount = 1.0
		landing_settle_amount = 1.0
		takeoff_amount = 0.0
	previous_external_on_floor = external_on_floor

	var target_jump := 0.0 if external_on_floor else 1.0
	if external_on_floor:
		jump_air_time = 0.0
	else:
		jump_air_time += delta
	jump_amount = lerpf(jump_amount, target_jump, 1.0 - exp(-12.0 * delta))
	takeoff_amount = maxf(takeoff_amount - delta * 4.2, 0.0)
	landing_amount = maxf(landing_amount - delta * 4.6, 0.0)
	landing_settle_amount = maxf(landing_settle_amount - delta * 2.05, 0.0)


func _target_yaw() -> float:
	var to_target := _target_look_position() - global_position
	to_target.y = 0.0
	if to_target.length_squared() < 0.001:
		return rotation.y
	return atan2(-to_target.x, -to_target.z)


func _animate_body(delta: float) -> void:
	if turn_activity > 0.015:
		var phase_direction := signf(walk_direction_local.y)
		if absf(phase_direction) < 0.001:
			phase_direction = signf(turn_intensity)
		if absf(phase_direction) < 0.001:
			phase_direction = 1.0
		turn_phase += delta * (4.4 + turn_activity * 6.0 + walk_activity * external_move_speed * 0.42) * phase_direction

	var idle := sin(animation_time * 1.55)
	var activity := turn_activity
	var turn := turn_intensity
	var step_left := sin(turn_phase)
	var step_right := sin(turn_phase + PI)
	var walk_forward := walk_direction_local.y * walk_activity
	var walk_side := walk_direction_local.x * walk_activity
	var stride_scale := 0.35 + absf(walk_forward) * 0.85 + absf(walk_side) * 0.55
	var lift_left := pow(maxf(0.0, step_left), 0.75) * activity * (0.65 + walk_activity * 0.55)
	var lift_right := pow(maxf(0.0, step_right), 0.75) * activity * (0.65 + walk_activity * 0.55)
	var planted_left := 1.0 - lift_left
	var planted_right := 1.0 - lift_right
	var side_left := -0.010 * activity + lift_left * 0.018 + step_left * walk_side * 0.035
	var side_right := 0.010 * activity - lift_right * 0.018 + step_right * walk_side * 0.035
	var stride_left := clampf(step_left, -0.65, 0.65) * activity * stride_scale
	var stride_right := clampf(step_right, -0.65, 0.65) * activity * stride_scale
	var crouch := visual_stance_amount
	_update_player_blocker(crouch)
	var rising := clampf(external_velocity.y / 7.0, 0.0, 1.0) * jump_amount
	var falling := clampf(-external_velocity.y / 9.0, 0.0, 1.0) * jump_amount
	var air_phase := clampf(jump_air_time / 0.70, 0.0, 1.0)
	var apex := jump_amount * clampf(1.0 - absf(air_phase - 0.50) * 2.0, 0.0, 1.0)
	var launch_stretch := clampf(takeoff_amount * 0.85 + rising * 0.55, 0.0, 1.0)
	var landing_impact := pow(clampf(landing_amount, 0.0, 1.0), 1.28)
	var landing_settle := pow(clampf(landing_settle_amount, 0.0, 1.0), 1.55)
	var landing_rebound := clampf((landing_settle - landing_impact) * 0.50, 0.0, 0.26)
	var landing_squash := clampf(landing_impact * 0.82 + landing_settle * 0.18, 0.0, 1.0)
	var landing_tail := clampf(landing_settle * 0.42 + landing_rebound * 0.30, 0.0, 1.0)
	var tuck := clampf(apex * 0.92 + rising * 0.18 - falling * 0.18, 0.0, 1.0)
	var extend_for_landing := clampf(falling * 0.90 + landing_squash * 0.10 + landing_rebound * 0.18, 0.0, 1.0)
	var landing_brace := clampf(falling * 0.42 + landing_squash * 0.78 + landing_tail * 0.34, 0.0, 1.0)
	var arm_lift := clampf(launch_stretch * 0.74 + apex * 0.28, 0.0, 1.0)
	var arm_spread := clampf(jump_amount * 0.72 + landing_brace * 0.26, 0.0, 1.0)
	var knee_fold := clampf(tuck * 1.18 + landing_squash * 0.58 + landing_tail * 0.18 + falling * 0.12 - launch_stretch * 0.20, 0.0, 1.0)
	var knee_straighten := clampf(launch_stretch * 0.55 + extend_for_landing * 0.46 + landing_rebound * 0.30 + landing_tail * 0.14 - landing_squash * 0.20, 0.0, 1.0)
	var leg_air_spread := jump_amount * 0.028 + knee_fold * 0.030 + landing_brace * 0.020
	var body_bob := sin(animation_time * 1.8) * 0.008 + (lift_left + lift_right) * 0.018 + walk_activity * absf(sin(turn_phase * 2.0)) * 0.018 + activity * 0.006
	var jump_lift := launch_stretch * 0.090 + apex * 0.140 + rising * 0.030 - landing_squash * 0.060 - landing_tail * 0.018 + landing_rebound * 0.042

	body_root.position.y = body_bob - crouch * 0.015 + jump_lift
	body_root.scale = Vector3(
		lerpf(1.0, 1.08, crouch) - launch_stretch * 0.045 + landing_squash * 0.105 + landing_tail * 0.028 - landing_rebound * 0.024,
		lerpf(1.0, CROUCH_HEIGHT_SCALE, crouch) + launch_stretch * 0.135 - landing_squash * 0.190 - landing_tail * 0.045 + landing_rebound * 0.060,
		lerpf(1.0, 1.08, crouch) - launch_stretch * 0.030 + landing_squash * 0.095 + landing_tail * 0.024 - landing_rebound * 0.020
	)
	body_root.rotation.x = -absf(turn) * deg_to_rad(1.5) - walk_forward * deg_to_rad(1.4) + launch_stretch * deg_to_rad(4.0) - falling * deg_to_rad(6.0) + landing_squash * deg_to_rad(6.2) + landing_tail * deg_to_rad(2.2) - landing_rebound * deg_to_rad(2.4)
	body_root.rotation.y = -turn * deg_to_rad(3.8) + walk_side * deg_to_rad(2.5)
	body_root.rotation.z = idle * deg_to_rad(0.5) - turn * deg_to_rad(4.2) - walk_side * deg_to_rad(3.0)

	head_root.rotation.x = sin(animation_time * 1.6) * deg_to_rad(0.6) + absf(turn) * deg_to_rad(0.8) + external_pitch * 0.22 - crouch * deg_to_rad(4.0) - tuck * deg_to_rad(4.0) + landing_squash * deg_to_rad(5.2) + landing_tail * deg_to_rad(1.8) - landing_rebound * deg_to_rad(1.8)
	head_root.rotation.y = turn * deg_to_rad(8.0) + clampf(turn_yaw_error, -0.45, 0.45) * 0.10 + walk_side * deg_to_rad(3.5)
	head_root.rotation.z = -turn * deg_to_rad(1.6)

	left_arm.position = Vector3(-0.285 - arm_spread * 0.100 - landing_brace * 0.024, 0.96 + arm_lift * 0.120 - landing_brace * 0.030, -0.025 * activity - launch_stretch * 0.020 + landing_brace * 0.045)
	right_arm.position = Vector3(0.285 + arm_spread * 0.100 + landing_brace * 0.024, 0.96 + arm_lift * 0.120 - landing_brace * 0.030, -0.025 * activity - launch_stretch * 0.020 + landing_brace * 0.045)
	left_arm.rotation.x = -turn * deg_to_rad(15.0) + step_right * activity * deg_to_rad(8.0) + step_right * walk_activity * deg_to_rad(18.0) + crouch * deg_to_rad(8.0) - launch_stretch * deg_to_rad(10.0) + landing_brace * deg_to_rad(14.0)
	right_arm.rotation.x = turn * deg_to_rad(15.0) + step_left * activity * deg_to_rad(8.0) + step_left * walk_activity * deg_to_rad(18.0) + crouch * deg_to_rad(8.0) - launch_stretch * deg_to_rad(10.0) + landing_brace * deg_to_rad(14.0)
	left_arm.rotation.y = turn * deg_to_rad(4.5) - arm_spread * deg_to_rad(9.0) - landing_squash * deg_to_rad(3.8) - landing_tail * deg_to_rad(1.4) + landing_rebound * deg_to_rad(1.5)
	right_arm.rotation.y = turn * deg_to_rad(4.5) + arm_spread * deg_to_rad(9.0) + landing_squash * deg_to_rad(3.8) + landing_tail * deg_to_rad(1.4) - landing_rebound * deg_to_rad(1.5)
	left_arm.rotation.z = deg_to_rad(-10.0) - activity * deg_to_rad(2.0) + idle * deg_to_rad(0.9) - arm_lift * deg_to_rad(39.0) - arm_spread * deg_to_rad(12.0) + landing_squash * deg_to_rad(10.5) + landing_tail * deg_to_rad(4.0) - landing_rebound * deg_to_rad(4.0)
	right_arm.rotation.z = deg_to_rad(10.0) + activity * deg_to_rad(2.0) - idle * deg_to_rad(0.9) + arm_lift * deg_to_rad(39.0) + arm_spread * deg_to_rad(12.0) - landing_squash * deg_to_rad(10.5) - landing_tail * deg_to_rad(4.0) + landing_rebound * deg_to_rad(4.0)

	left_leg.position = LEFT_LEG_BASE + Vector3(side_left - leg_air_spread, lift_left * 0.018 + tuck * 0.110 - launch_stretch * 0.034 - extend_for_landing * 0.058 - landing_squash * 0.014 - landing_tail * 0.010 + landing_rebound * 0.014, stride_left * 0.028 + tuck * 0.026 - extend_for_landing * 0.058 + landing_squash * 0.010 + landing_tail * 0.006)
	right_leg.position = RIGHT_LEG_BASE + Vector3(side_right + leg_air_spread, lift_right * 0.018 + tuck * 0.106 - launch_stretch * 0.030 - extend_for_landing * 0.058 - landing_squash * 0.014 - landing_tail * 0.010 + landing_rebound * 0.014, stride_right * 0.028 - tuck * 0.026 - extend_for_landing * 0.052 + landing_squash * 0.010 + landing_tail * 0.006)
	left_leg.rotation.x = stride_left * deg_to_rad(22.0) - lift_left * deg_to_rad(7.0) - crouch * deg_to_rad(14.0) - launch_stretch * deg_to_rad(10.0) + tuck * deg_to_rad(35.0) + extend_for_landing * deg_to_rad(14.0) + landing_squash * deg_to_rad(22.0) + landing_tail * deg_to_rad(8.0) - landing_rebound * deg_to_rad(8.0)
	right_leg.rotation.x = stride_right * deg_to_rad(22.0) - lift_right * deg_to_rad(7.0) - crouch * deg_to_rad(14.0) - launch_stretch * deg_to_rad(8.0) + tuck * deg_to_rad(33.0) + extend_for_landing * deg_to_rad(13.0) + landing_squash * deg_to_rad(22.0) + landing_tail * deg_to_rad(8.0) - landing_rebound * deg_to_rad(8.0)
	left_leg.rotation.y = turn * deg_to_rad(5.0) + stride_left * deg_to_rad(3.0) + walk_side * deg_to_rad(5.0) - knee_fold * deg_to_rad(3.5)
	right_leg.rotation.y = turn * deg_to_rad(5.0) + stride_right * deg_to_rad(3.0) + walk_side * deg_to_rad(5.0) + knee_fold * deg_to_rad(3.5)
	left_leg.rotation.z = deg_to_rad(1.0) - turn * deg_to_rad(2.0) + lift_left * deg_to_rad(1.0) - walk_side * deg_to_rad(2.0) - knee_fold * deg_to_rad(8.5) - landing_brace * deg_to_rad(3.0)
	right_leg.rotation.z = deg_to_rad(-1.0) - turn * deg_to_rad(2.0) - lift_right * deg_to_rad(1.0) - walk_side * deg_to_rad(2.0) + knee_fold * deg_to_rad(8.5) + landing_brace * deg_to_rad(3.0)

	left_lower_leg.position = LOWER_LEG_BASE
	right_lower_leg.position = LOWER_LEG_BASE
	left_lower_leg.rotation.x = step_right * activity * deg_to_rad(5.0) - knee_fold * deg_to_rad(84.0) + knee_straighten * deg_to_rad(18.0) - landing_squash * deg_to_rad(11.0) - landing_tail * deg_to_rad(3.5) + landing_rebound * deg_to_rad(7.0)
	right_lower_leg.rotation.x = step_left * activity * deg_to_rad(5.0) - knee_fold * deg_to_rad(82.0) + knee_straighten * deg_to_rad(17.0) - landing_squash * deg_to_rad(11.0) - landing_tail * deg_to_rad(3.5) + landing_rebound * deg_to_rad(7.0)
	left_lower_leg.rotation.y = turn * deg_to_rad(2.5) + walk_side * deg_to_rad(2.5) + knee_fold * deg_to_rad(4.5)
	right_lower_leg.rotation.y = turn * deg_to_rad(2.5) + walk_side * deg_to_rad(2.5) - knee_fold * deg_to_rad(4.5)
	left_lower_leg.rotation.z = lift_left * deg_to_rad(1.0) - walk_side * deg_to_rad(2.0) + knee_fold * deg_to_rad(13.0) - landing_brace * deg_to_rad(3.0)
	right_lower_leg.rotation.z = -lift_right * deg_to_rad(1.0) - walk_side * deg_to_rad(2.0) - knee_fold * deg_to_rad(13.0) + landing_brace * deg_to_rad(3.0)

	left_foot.position = FOOT_LOCAL_BASE + Vector3(0.0, lift_left * 0.014 + tuck * 0.020 - launch_stretch * 0.014 - extend_for_landing * 0.024 + landing_squash * 0.016 + landing_tail * 0.010, stride_left * 0.018 + tuck * 0.014 - extend_for_landing * 0.034 + landing_squash * 0.012 + landing_tail * 0.006)
	right_foot.position = FOOT_LOCAL_BASE + Vector3(0.0, lift_right * 0.014 + tuck * 0.018 - launch_stretch * 0.012 - extend_for_landing * 0.024 + landing_squash * 0.016 + landing_tail * 0.010, stride_right * 0.018 - tuck * 0.014 - extend_for_landing * 0.028 + landing_squash * 0.012 + landing_tail * 0.006)
	left_foot.rotation.x = -stride_left * deg_to_rad(6.0) + lift_left * deg_to_rad(5.0) + crouch * deg_to_rad(7.0) + launch_stretch * deg_to_rad(8.0) + tuck * deg_to_rad(22.0) - extend_for_landing * deg_to_rad(12.0) + landing_squash * deg_to_rad(7.5) + landing_tail * deg_to_rad(3.0) - landing_rebound * deg_to_rad(5.0) - left_lower_leg.rotation.x * 0.36
	right_foot.rotation.x = -stride_right * deg_to_rad(6.0) + lift_right * deg_to_rad(5.0) + crouch * deg_to_rad(7.0) + launch_stretch * deg_to_rad(8.0) + tuck * deg_to_rad(21.0) - extend_for_landing * deg_to_rad(12.0) + landing_squash * deg_to_rad(7.5) + landing_tail * deg_to_rad(3.0) - landing_rebound * deg_to_rad(5.0) - right_lower_leg.rotation.x * 0.36
	left_foot.rotation.y = turn * deg_to_rad(7.0) + stride_left * deg_to_rad(3.0) + walk_side * deg_to_rad(4.0) - knee_fold * deg_to_rad(2.0)
	right_foot.rotation.y = turn * deg_to_rad(7.0) + stride_right * deg_to_rad(3.0) + walk_side * deg_to_rad(4.0) + knee_fold * deg_to_rad(2.0)
	left_foot.rotation.z = -turn * deg_to_rad(1.5) + planted_left * activity * deg_to_rad(0.7) - knee_fold * deg_to_rad(7.0) - landing_brace * deg_to_rad(2.0)
	right_foot.rotation.z = -turn * deg_to_rad(1.5) - planted_right * activity * deg_to_rad(0.7) + knee_fold * deg_to_rad(7.0) + landing_brace * deg_to_rad(2.0)
	_animate_head_sprout(walk_side, walk_forward, turn, rising, falling, apex, tuck, landing_amount, takeoff_amount)
	_update_player_shadow(crouch, jump_amount)


func _update_player_shadow(crouch: float, airborne: float) -> void:
	if player_shadow == null:
		return
	var height_lift := clampf(maxf(global_position.y, 0.0) / 2.0, 0.0, 1.0)
	var lift_factor := maxf(height_lift, clampf(airborne, 0.0, 1.0) * 0.24)
	var width := lerpf(1.06, 1.24, crouch)
	var depth := lerpf(1.26, 1.36, crouch)
	var alpha := lerpf(0.38, 0.15, lift_factor)
	player_shadow.update_shadow(global_position, sun_direction, width, depth, alpha, lift_factor)


func _animate_head_sprout(walk_side: float, walk_forward: float, turn: float, rising: float, falling: float, apex: float, tuck: float, landing: float, takeoff: float) -> void:
	if sprout_root == null:
		return

	var idle_sway := sin(animation_time * 1.85) * deg_to_rad(1.6)
	var walk_sway := sin(turn_phase * 1.15) * walk_activity * deg_to_rad(5.0)
	var spring := takeoff * deg_to_rad(-10.0) + rising * deg_to_rad(-4.0) + falling * deg_to_rad(9.0) + landing * deg_to_rad(13.0)
	var side_sway := -walk_side * deg_to_rad(8.5) - turn * deg_to_rad(7.0) + idle_sway + walk_sway
	var forward_sway := -walk_forward * deg_to_rad(2.5) + spring

	sprout_root.position = Vector3(0.0, 0.348 + takeoff * 0.014 + apex * 0.010 - landing * 0.024, -0.010)
	sprout_root.rotation = Vector3(forward_sway, 0.0, side_sway)

	if sprout_stem != null:
		sprout_stem.rotation = Vector3(0.0, 0.0, deg_to_rad(1.0) + side_sway * 0.22)

	var leaf_flutter := sin(animation_time * 3.4 + turn_phase * 0.35) * deg_to_rad(1.15)
	var stretch := takeoff * deg_to_rad(4.0) - apex * deg_to_rad(2.5)
	var landing_fold := landing * deg_to_rad(6.0)
	var air_spread := tuck * deg_to_rad(2.5)

	if left_sprout_leaf != null:
		left_sprout_leaf.rotation = Vector3(
			falling * deg_to_rad(2.0),
			deg_to_rad(-6.0) - side_sway * 0.24,
			deg_to_rad(-39.0) + side_sway * 0.46 - leaf_flutter - stretch - air_spread + landing_fold
		)
	if right_sprout_leaf != null:
		right_sprout_leaf.rotation = Vector3(
			falling * deg_to_rad(2.0),
			deg_to_rad(6.0) - side_sway * 0.24,
			deg_to_rad(39.0) + side_sway * 0.46 + leaf_flutter + stretch + air_spread - landing_fold
		)


func _animate_eyes(delta: float) -> void:
	_update_sun_gaze(delta)
	blink_timer -= delta
	if blink_timer <= 0.0:
		blink_timer = _next_blink_interval()
		if _sun_blink_intensity() > 0.0 or target == null:
			_start_blink()
	_update_blink_cycle(delta)

	eye_dart_timer -= delta
	if eye_dart_timer <= 0.0:
		if target != null:
			eye_dart_timer = 0.55 + absf(sin(animation_time * 1.9)) * 0.55
			eye_dart = Vector2.ZERO
		else:
			eye_dart_timer = 1.6 + absf(sin(animation_time * 1.9)) * 1.4
			eye_dart = Vector2(sin(animation_time * 8.1), cos(animation_time * 6.4)) * 0.10

	var target_focus := _target_eye_focus()
	target_focus.x += clampf(turn_intensity * 0.18 + turn_yaw_error * 0.10, -0.24, 0.24)
	var idle_dart_weight := 0.30 if target == null else 0.0
	target_focus += eye_dart * idle_dart_weight
	eye_focus = eye_focus.lerp(target_focus, 1.0 - exp(-9.0 * delta))

	var idle_amount := 1.0 - gaze_activity
	var eye_idle := Vector2(sin(animation_time * 0.55) * 0.010, sin(animation_time * 0.75) * 0.006) * idle_amount
	var focus := eye_focus + eye_idle
	var eye_shift_x := lerpf(0.040, 0.105, gaze_activity)
	var eye_shift_y := lerpf(0.022, 0.060, gaze_activity)
	var eye_shift_z := lerpf(0.006, 0.018, gaze_activity)
	var convergence := gaze_activity * 0.018
	var eye_offset := Vector3(focus.x * eye_shift_x, focus.y * eye_shift_y, -0.030 - absf(focus.x) * eye_shift_z)
	left_eye.position = LEFT_EYE_BASE + eye_offset + Vector3(convergence, 0.0, 0.0)
	right_eye.position = RIGHT_EYE_BASE + eye_offset + Vector3(-convergence, 0.0, 0.0)

	left_eye_glint.position = left_eye.position + Vector3(-0.014 + focus.x * 0.006, 0.014 + focus.y * 0.004, -0.014)
	right_eye_glint.position = right_eye.position + Vector3(-0.014 + focus.x * 0.006, 0.014 + focus.y * 0.004, -0.014)
	_apply_eye_scale()


func _start_blink() -> void:
	if blink_closing or blink_hold_timer > 0.0 or blink_amount > 0.35:
		return
	blink_closing = true


func _update_blink_cycle(delta: float) -> void:
	var sun_intensity := _sun_blink_intensity()
	if blink_closing:
		var close_speed := lerpf(BLINK_CLOSE_SPEED, SUN_BLINK_CLOSE_SPEED, sun_intensity)
		blink_amount = minf(blink_amount + delta * close_speed, 1.0)
		if blink_amount >= 1.0:
			blink_closing = false
			blink_hold_timer = lerpf(BLINK_HOLD_SECONDS, SUN_BLINK_HOLD_SECONDS, sun_intensity)
		return

	if blink_hold_timer > 0.0:
		blink_hold_timer = maxf(blink_hold_timer - delta, 0.0)
		return

	var open_speed := lerpf(BLINK_OPEN_SPEED, SUN_BLINK_OPEN_SPEED, sun_intensity)
	blink_amount = maxf(blink_amount - delta * open_speed, 0.0)


func _apply_eye_scale() -> void:
	var turn_squint := clampf(absf(turn_intensity) * 0.018 + turn_activity * 0.010, 0.0, 0.035)
	var focus_widen := clampf(absf(eye_focus.x) * 0.045, 0.0, 0.055)
	var open_scale := clampf(lerpf(1.0, 0.08, blink_amount) - turn_squint, 0.06, 1.0)
	left_eye.scale = Vector3(1.0 + focus_widen, open_scale, 0.16)
	right_eye.scale = Vector3(1.0 + focus_widen, open_scale, 0.16)
	if left_eye_white != null:
		left_eye_white.scale = Vector3(1.0, open_scale, 1.0)
	if right_eye_white != null:
		right_eye_white.scale = Vector3(1.0, open_scale, 1.0)
	var glint_open := clampf(open_scale * (1.0 - blink_amount), 0.0, 1.0)
	left_eye_glint.scale = Vector3(1.0, glint_open, 0.10)
	right_eye_glint.scale = Vector3(1.0, glint_open, 0.10)


func _target_eye_focus() -> Vector2:
	if target == null or head_root == null:
		return Vector2.ZERO

	var aim_position := _target_look_position()
	var local_target := head_root.to_local(aim_position)
	var depth := maxf(absf(local_target.z), 0.25)
	var gaze_gain_x := lerpf(1.15, 1.85, _target_presence())
	var gaze_gain_y := lerpf(0.85, 1.20, _target_presence())
	return Vector2(
		clampf(local_target.x / depth * gaze_gain_x, -1.0, 1.0),
		clampf(local_target.y / depth * gaze_gain_y, -0.75, 0.75)
	)


func get_look_target_position() -> Vector3:
	if head_root != null:
		return head_root.global_position
	return global_position + Vector3.UP * 1.55


func _target_look_position() -> Vector3:
	if target == null:
		return global_position

	return _look_position_for_node(target)


func _look_position_for_node(node: Node3D) -> Vector3:
	if node.has_method("get_look_target_position"):
		return node.get_look_target_position()

	var node_position := node.global_position + Vector3.UP * 1.55
	var node_head: Node = node.get_node_or_null("Head")
	if node_head is Node3D:
		node_position = node_head.global_position
	return node_position


func _target_presence() -> float:
	if target == null:
		return 0.0
	var source_position := get_look_target_position()
	var target_position := _target_look_position()
	var distance := source_position.distance_to(target_position)
	return clampf(1.0 - distance / EYE_LOOK_RADIUS, 0.0, 1.0)


func _update_sun_gaze(delta: float) -> void:
	var look_factor := _sun_look_factor()
	if look_factor > 0.0:
		sun_gaze_charge = minf(sun_gaze_charge + look_factor * delta / SUN_GAZE_CHARGE_SECONDS, 1.0)
	else:
		sun_gaze_charge = maxf(sun_gaze_charge - delta / SUN_GAZE_DECAY_SECONDS, 0.0)


func _sun_look_factor() -> float:
	if sun_direction.length_squared() < 0.0001:
		return 0.0
	var look_direction := _look_direction_for_sun()
	var sun_alignment := look_direction.dot(sun_direction.normalized())
	return clampf((sun_alignment - SUN_LOOK_DOT_START) / maxf(1.0 - SUN_LOOK_DOT_START, 0.001), 0.0, 1.0)


func _look_direction_for_sun() -> Vector3:
	var clamped_pitch := clampf(external_pitch, deg_to_rad(-84.0), deg_to_rad(84.0))
	var local_direction := Vector3(0.0, sin(clamped_pitch), -cos(clamped_pitch))
	var yaw_basis := Basis(Vector3.UP, rotation.y)
	return (yaw_basis * local_direction).normalized()


func _sun_blink_intensity() -> float:
	return clampf((sun_gaze_charge - 0.65) / 0.35, 0.0, 1.0)


func _next_blink_interval() -> float:
	var sun_intensity := _sun_blink_intensity()
	var slow_interval := BASE_BLINK_MIN + absf(sin(animation_time * 0.73 + 0.31)) * BASE_BLINK_VARIATION
	var fast_interval := SUN_BLINK_MIN + absf(sin(animation_time * 1.47 + 1.2)) * SUN_BLINK_VARIATION
	if target != null and sun_intensity <= 0.0:
		slow_interval += 8.0
	return lerpf(slow_interval, fast_interval, sun_intensity)


func _add_outlined_part(parent: Node, part_name: String, mesh: Mesh, part_position: Vector3, rotation: Vector3, part_scale: Vector3, color: Color, outline_scale: float) -> Node3D:
	var root := Node3D.new()
	root.name = part_name
	root.position = part_position
	root.rotation = rotation
	parent.add_child(root)

	var outline := MeshInstance3D.new()
	outline.name = "Outline"
	outline.mesh = mesh
	outline.scale = part_scale * outline_scale
	outline.material_override = _outline_material()
	root.add_child(outline)

	var fill := MeshInstance3D.new()
	fill.name = "Fill"
	fill.mesh = mesh
	fill.scale = part_scale
	fill.material_override = _material(color)
	root.add_child(fill)
	return root


func _make_part_root(parent: Node, part_name: String, part_position: Vector3) -> Node3D:
	var root := Node3D.new()
	root.name = part_name
	root.position = part_position
	parent.add_child(root)
	return root


func _add_part(parent: Node, part_name: String, mesh: Mesh, part_position: Vector3, rotation: Vector3, part_scale: Vector3, color: Color) -> MeshInstance3D:
	var part := MeshInstance3D.new()
	part.name = part_name
	part.mesh = mesh
	part.position = part_position
	part.rotation = rotation
	part.scale = part_scale
	part.material_override = _material(color)
	parent.add_child(part)
	return part


func _material(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.88
	return material


func _outline_material() -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = OUTLINE
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.cull_mode = BaseMaterial3D.CULL_FRONT
	return material


func _box_mesh(size: Vector3) -> BoxMesh:
	var mesh := BoxMesh.new()
	mesh.size = size
	return mesh


func _capsule_mesh(radius: float, height: float) -> CapsuleMesh:
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = height
	mesh.radial_segments = 18
	mesh.rings = 8
	return mesh


func _sphere_mesh(radius: float) -> SphereMesh:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 16
	mesh.rings = 8
	return mesh
