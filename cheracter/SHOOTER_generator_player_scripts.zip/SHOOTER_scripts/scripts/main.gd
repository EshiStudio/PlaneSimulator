extends Control

const WORLD_SCRIPT := preload("res://scripts/world.gd")
const HANDS_SCRIPT := preload("res://scripts/hands.gd")
const SUN_GLARE_SCRIPT := preload("res://scripts/sun_glare.gd")
const PANINI_SHADER := preload("res://shaders/panini.gdshader")
const INTERNAL_RENDER_SCALE := 1.5
const HANDS_RENDER_SCALE := 2.0

const ACTION_KEYS := {
	"move_forward": [KEY_W],
	"move_back": [KEY_S],
	"move_left": [KEY_A],
	"move_right": [KEY_D],
	"jump": [KEY_SPACE],
	"sprint": [KEY_SHIFT],
	"slide": [KEY_CTRL],
}
const ACTION_MOUSE_BUTTONS := {
	"attack_left": [MOUSE_BUTTON_LEFT],
	"attack_right": [MOUSE_BUTTON_RIGHT],
}

var game_viewport: SubViewport
var screen: TextureRect
var panini_material: ShaderMaterial
var world
var sun_glare_overlay
var hands_viewport: SubViewport
var hands_screen: TextureRect
var hands_overlay


func _ready() -> void:
	_ensure_input_actions()
	_build_render_pipeline()
	_resize_game_viewport()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED and game_viewport != null:
		_resize_game_viewport()


func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
			return

	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
			return

	if game_viewport != null:
		game_viewport.push_input(event)


func _build_render_pipeline() -> void:
	game_viewport = SubViewport.new()
	game_viewport.name = "GameViewport"
	game_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	game_viewport.transparent_bg = false
	game_viewport.own_world_3d = true
	add_child(game_viewport)

	world = WORLD_SCRIPT.new()
	world.name = "World"
	game_viewport.add_child(world)

	screen = TextureRect.new()
	screen.name = "PaniniScreen"
	screen.set_anchors_preset(Control.PRESET_FULL_RECT)
	screen.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	screen.stretch_mode = TextureRect.STRETCH_SCALE
	screen.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	screen.texture = game_viewport.get_texture()

	panini_material = ShaderMaterial.new()
	panini_material.shader = PANINI_SHADER
	screen.material = panini_material
	add_child(screen)

	sun_glare_overlay = SUN_GLARE_SCRIPT.new()
	sun_glare_overlay.name = "SunGlareOverlay"
	sun_glare_overlay.world = world
	sun_glare_overlay.game_viewport = game_viewport
	sun_glare_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	sun_glare_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(sun_glare_overlay)

	hands_viewport = SubViewport.new()
	hands_viewport.name = "HandsViewport"
	hands_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	hands_viewport.transparent_bg = true
	hands_viewport.own_world_3d = true
	add_child(hands_viewport)

	hands_overlay = HANDS_SCRIPT.new()
	hands_overlay.name = "StylizedHands"
	hands_overlay.world = world
	hands_overlay.render_scale = HANDS_RENDER_SCALE
	hands_overlay.debug_slide_preview = "--debug-slide-hands" in OS.get_cmdline_user_args()
	if hands_overlay is Control:
		hands_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
		hands_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hands_viewport.add_child(hands_overlay)

	hands_screen = TextureRect.new()
	hands_screen.name = "HandsScreen"
	hands_screen.set_anchors_preset(Control.PRESET_FULL_RECT)
	hands_screen.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	hands_screen.stretch_mode = TextureRect.STRETCH_SCALE
	hands_screen.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hands_screen.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	hands_screen.texture = hands_viewport.get_texture()
	add_child(hands_screen)


func _resize_game_viewport() -> void:
	var viewport_size := get_viewport_rect().size.round()
	viewport_size.x = maxf(viewport_size.x, 16.0)
	viewport_size.y = maxf(viewport_size.y, 16.0)
	game_viewport.size = Vector2i(int(viewport_size.x * INTERNAL_RENDER_SCALE), int(viewport_size.y * INTERNAL_RENDER_SCALE))
	if hands_viewport != null:
		hands_viewport.size = Vector2i(int(viewport_size.x * HANDS_RENDER_SCALE), int(viewport_size.y * HANDS_RENDER_SCALE))
	if hands_overlay != null:
		if hands_overlay.has_method("set_viewport_size"):
			hands_overlay.set_viewport_size(Vector2(hands_viewport.size))
	if panini_material != null:
		panini_material.set_shader_parameter("render_size", Vector2(game_viewport.size))


func _ensure_input_actions() -> void:
	for action in ACTION_KEYS:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for keycode in ACTION_KEYS[action]:
			_add_key_event_if_missing(action, keycode)
	for action in ACTION_MOUSE_BUTTONS:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for button_index in ACTION_MOUSE_BUTTONS[action]:
			_add_mouse_button_event_if_missing(action, button_index)


func _add_key_event_if_missing(action: String, keycode: Key) -> void:
	for event in InputMap.action_get_events(action):
		if event is InputEventKey and event.physical_keycode == keycode:
			return
	var input_event := InputEventKey.new()
	input_event.physical_keycode = keycode
	InputMap.action_add_event(action, input_event)


func _add_mouse_button_event_if_missing(action: String, button_index: MouseButton) -> void:
	for event in InputMap.action_get_events(action):
		if event is InputEventMouseButton and event.button_index == button_index:
			return
	var input_event := InputEventMouseButton.new()
	input_event.button_index = button_index
	InputMap.action_add_event(action, input_event)
