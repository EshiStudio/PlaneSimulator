class_name PaniniPlayer
extends CharacterBody3D

const PLAYER_SHADOW_SCRIPT := preload("res://scripts/player_shadow.gd")

@export var mouse_sensitivity := 0.0022
@export var auto_bhop := true

const HU_TO_GODOT := 0.025
const MAX_SPEED_HU := 250.0
const GRAVITY_HU := 800.0
const JUMP_SPEED_HU := 268.328
const STOP_SPEED_HU := 100.0
const GROUND_ACCELERATE := 10.0
const AIR_ACCELERATE := 10.0
const FRICTION := 4.0
const AIR_WISH_SPEED_CAP_HU := 30.0
const MAX_VELOCITY_HU := 2000.0
const STANDING_HEIGHT := 2.35
const VIEW_HEIGHT := 2.12
const SLIDE_HEIGHT := 1.18
const SLIDE_VIEW_HEIGHT := 1.02
const SLIDE_MIN_SPEED_HU := 170.0
const SLIDE_EXIT_SPEED_HU := 115.0
const SLIDE_BOOST_HU := 140.0
const SLIDE_MAX_ENTRY_BONUS_HU := 120.0
const SLIDE_ENTRY_SPEED_FACTOR := 0.42
const SLIDE_JUMP_BOOST_HU := 105.0
const SLIDE_MAX_TIME := 1.05
const SLIDE_FRICTION := 0.22
const SLIDE_STEER_ACCELERATE := 4.0
const SLIDE_CAMERA_PITCH_DEGREES := -4.0
const SKILL_SPEED_SOFT_CAP_HU := 620.0
const SKILL_SPEED_HARD_CAP_HU := 780.0
const SKILL_SPEED_OVER_CAP_DAMPING := 4.0
const STANCE_RESPONSE := 16.0
const CAMERA_LEAN_ROLL_DEGREES := 6.0
const CAMERA_LEAN_YAW_DEGREES := 1.8
const CAMERA_LEAN_PITCH_DEGREES := 1.1
const CAMERA_LEAN_RESPONSE := 10.0
const HAND_ATTACK_DURATION := 0.36
const HAND_ATTACK_COOLDOWN := 0.12
const HAND_ATTACK_WINDUP := 0.18
const HAND_ATTACK_IMPACT_START := 0.34
const HAND_ATTACK_IMPACT_END := 0.56
const HAND_ATTACK_RECOVERY_END := 1.0
const HAND_ATTACK_PITCH_DEGREES := 1.2
const HAND_ATTACK_ROLL_DEGREES := 2.1

var max_speed := MAX_SPEED_HU * HU_TO_GODOT
var gravity_strength := GRAVITY_HU * HU_TO_GODOT
var jump_speed := JUMP_SPEED_HU * HU_TO_GODOT
var stop_speed := STOP_SPEED_HU * HU_TO_GODOT
var air_wish_speed_cap := AIR_WISH_SPEED_CAP_HU * HU_TO_GODOT
var max_velocity := MAX_VELOCITY_HU * HU_TO_GODOT
var slide_min_speed := SLIDE_MIN_SPEED_HU * HU_TO_GODOT
var slide_exit_speed := SLIDE_EXIT_SPEED_HU * HU_TO_GODOT
var slide_boost := SLIDE_BOOST_HU * HU_TO_GODOT
var slide_max_entry_bonus := SLIDE_MAX_ENTRY_BONUS_HU * HU_TO_GODOT
var slide_jump_boost := SLIDE_JUMP_BOOST_HU * HU_TO_GODOT
var speed_soft_cap := SKILL_SPEED_SOFT_CAP_HU * HU_TO_GODOT
var speed_hard_cap := SKILL_SPEED_HARD_CAP_HU * HU_TO_GODOT
var sun_direction := Vector3(0.0, 1.0, -0.2)
var pitch := 0.0
var camera_pitch_offset := 0.0
var camera_yaw_offset := 0.0
var camera_roll_offset := 0.0
var filtered_input := Vector2.ZERO
var filtered_speed := 0.0
var slide_direction_local := Vector2(0.0, 1.0)
var slide_direction_world := Vector3.FORWARD
var slide_motion_speed := 0.0
var stance_amount := 0.0
var left_attack_age := 99.0
var right_attack_age := 99.0
var left_attack_amount := 0.0
var right_attack_amount := 0.0
var left_attack_impact := 0.0
var right_attack_impact := 0.0
var attack_pitch_offset := 0.0
var attack_roll_offset := 0.0
var attack_recoil := 0.0
var is_sliding := false
var slide_time_left := 0.0
var collision_shape: CollisionShape3D
var capsule_shape: CapsuleShape3D
var head: Node3D
var camera: Camera3D
var player_shadow


func _ready() -> void:
	_build_body()
	_build_camera()
	_build_player_shadow()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		pitch = clampf(pitch - event.relative.y * mouse_sensitivity, deg_to_rad(-84.0), deg_to_rad(84.0))
		_apply_camera_rotation()
	if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and event.is_action_pressed("attack_left"):
		trigger_hand_attack(1.0)
	if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and event.is_action_pressed("attack_right"):
		trigger_hand_attack(-1.0)


func _physics_process(delta: float) -> void:
	var wish := _get_wish()
	var wish_dir: Vector3 = wish[0]
	var wish_speed: float = wish[1]
	var wants_jump := Input.is_action_pressed("jump") if auto_bhop else Input.is_action_just_pressed("jump")
	var wants_slide := Input.is_action_pressed("slide")
	var just_pressed_slide := Input.is_action_just_pressed("slide")
	var horizontal_speed := Vector2(velocity.x, velocity.z).length()

	if wants_slide and not is_sliding and is_on_floor() and (just_pressed_slide or horizontal_speed >= slide_min_speed) and horizontal_speed >= slide_min_speed:
		_start_slide(wish_dir)

	if is_on_floor():
		if wants_jump:
			if is_sliding:
				_apply_slide_jump_boost(wish_dir)
			is_sliding = false
			velocity.y = jump_speed
			_air_move(wish_dir, wish_speed, delta)
		elif is_sliding:
			velocity.y = 0.0
			_slide_move(wish_dir, wish_speed, delta)
		else:
			velocity.y = 0.0
			_apply_friction(delta)
			_accelerate(wish_dir, wish_speed, GROUND_ACCELERATE, delta)
	else:
		is_sliding = false
		velocity.y -= gravity_strength * delta
		_air_move(wish_dir, wish_speed, delta)

	if is_sliding:
		slide_time_left -= delta
		var current_slide_speed := Vector2(velocity.x, velocity.z).length()
		if slide_time_left <= 0.0 or current_slide_speed < slide_exit_speed or not wants_slide:
			is_sliding = false

	_apply_skill_speed_limit(delta)
	_update_hand_attack_state(delta)
	_clamp_velocity()
	move_and_slide()
	_update_stance(delta, wants_slide)
	_update_slide_direction(delta)
	_update_camera_motion(delta)
	_update_input_filter(delta)
	_update_player_shadow()


func _get_wish() -> Array:
	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var forward := -global_transform.basis.z
	var right := global_transform.basis.x
	forward.y = 0.0
	right.y = 0.0
	forward = forward.normalized()
	right = right.normalized()

	var wish_velocity := right * input_dir.x + forward * -input_dir.y
	var wish_speed := clampf(input_dir.length(), 0.0, 1.0) * max_speed
	var wish_dir := wish_velocity.normalized() if wish_velocity.length_squared() > 0.000001 else Vector3.ZERO
	return [wish_dir, wish_speed]


func _apply_friction(delta: float) -> void:
	_apply_ground_friction(delta, FRICTION)


func _apply_ground_friction(delta: float, friction: float) -> void:
	var horizontal_velocity := Vector3(velocity.x, 0.0, velocity.z)
	var speed := horizontal_velocity.length()
	if speed < 0.001:
		velocity.x = 0.0
		velocity.z = 0.0
		return

	var control := stop_speed if speed < stop_speed else speed
	var drop := control * friction * delta
	var new_speed := maxf(speed - drop, 0.0)
	if new_speed != speed:
		new_speed /= speed
		velocity.x *= new_speed
		velocity.z *= new_speed


func _accelerate(wish_dir: Vector3, wish_speed: float, accel: float, delta: float) -> void:
	if wish_speed <= 0.0 or wish_dir == Vector3.ZERO:
		return

	var current_speed := velocity.dot(wish_dir)
	var add_speed := wish_speed - current_speed
	if add_speed <= 0.0:
		return

	var accel_speed := accel * delta * wish_speed
	if accel_speed > add_speed:
		accel_speed = add_speed
	velocity += wish_dir * accel_speed


func _air_move(wish_dir: Vector3, wish_speed: float, delta: float) -> void:
	if wish_speed <= 0.0 or wish_dir == Vector3.ZERO:
		return

	var wish_spd := minf(wish_speed, air_wish_speed_cap)
	var current_speed := velocity.dot(wish_dir)
	var add_speed := wish_spd - current_speed
	if add_speed <= 0.0:
		return

	var accel_speed := AIR_ACCELERATE * wish_speed * delta
	if accel_speed > add_speed:
		accel_speed = add_speed
	velocity += wish_dir * accel_speed


func _start_slide(wish_dir: Vector3) -> void:
	is_sliding = true
	slide_time_left = SLIDE_MAX_TIME
	var horizontal_velocity := Vector3(velocity.x, 0.0, velocity.z)
	var entry_speed := horizontal_velocity.length()
	var slide_dir := horizontal_velocity.normalized()
	if slide_dir == Vector3.ZERO and wish_dir != Vector3.ZERO:
		slide_dir = wish_dir
	if slide_dir != Vector3.ZERO:
		var speed_bonus := minf(maxf(entry_speed - slide_min_speed, 0.0) * SLIDE_ENTRY_SPEED_FACTOR, slide_max_entry_bonus)
		var total_boost := slide_boost + speed_bonus
		velocity.x += slide_dir.x * total_boost
		velocity.z += slide_dir.z * total_boost


func _slide_move(wish_dir: Vector3, wish_speed: float, delta: float) -> void:
	_apply_ground_friction(delta, SLIDE_FRICTION)
	if wish_dir != Vector3.ZERO:
		_accelerate(wish_dir, minf(wish_speed, max_speed * 0.85), SLIDE_STEER_ACCELERATE, delta)


func _apply_slide_jump_boost(wish_dir: Vector3) -> void:
	var horizontal_velocity := Vector3(velocity.x, 0.0, velocity.z)
	var boost_dir := horizontal_velocity.normalized()
	if boost_dir == Vector3.ZERO and wish_dir != Vector3.ZERO:
		boost_dir = wish_dir
	if boost_dir == Vector3.ZERO:
		return

	var alignment := maxf(boost_dir.dot(wish_dir), 0.0) if wish_dir != Vector3.ZERO else 0.0
	var total_boost := slide_jump_boost * (1.0 + alignment * 0.35)
	velocity.x += boost_dir.x * total_boost
	velocity.z += boost_dir.z * total_boost


func _clamp_velocity() -> void:
	velocity.x = clampf(velocity.x, -max_velocity, max_velocity)
	velocity.y = clampf(velocity.y, -max_velocity, max_velocity)
	velocity.z = clampf(velocity.z, -max_velocity, max_velocity)


func _apply_skill_speed_limit(delta: float) -> void:
	var horizontal_velocity := Vector3(velocity.x, 0.0, velocity.z)
	var speed := horizontal_velocity.length()
	if speed <= speed_soft_cap:
		return

	var target_speed := speed
	if speed > speed_hard_cap:
		target_speed = speed_hard_cap
	else:
		var over_cap_ratio := (speed - speed_soft_cap) / maxf(speed_hard_cap - speed_soft_cap, 0.001)
		var damp := SKILL_SPEED_OVER_CAP_DAMPING * over_cap_ratio * over_cap_ratio * delta
		target_speed = lerpf(speed, speed_soft_cap, clampf(damp, 0.0, 1.0))

	var scale := target_speed / speed
	velocity.x *= scale
	velocity.z *= scale


func _update_camera_motion(delta: float) -> void:
	var horizontal_speed := Vector2(velocity.x, velocity.z).length()
	var speed_factor := clampf(filtered_speed / max_speed, 0.0, 1.25)
	var input_dir := filtered_input
	var target_roll := -input_dir.x * deg_to_rad(CAMERA_LEAN_ROLL_DEGREES) * speed_factor
	var target_yaw := -input_dir.x * deg_to_rad(CAMERA_LEAN_YAW_DEGREES) * speed_factor
	var target_pitch := input_dir.y * deg_to_rad(CAMERA_LEAN_PITCH_DEGREES) * speed_factor
	target_pitch += stance_amount * deg_to_rad(SLIDE_CAMERA_PITCH_DEGREES)
	target_pitch += attack_pitch_offset
	target_roll += attack_roll_offset
	var blend := 1.0 - exp(-CAMERA_LEAN_RESPONSE * delta)

	camera_roll_offset = lerpf(camera_roll_offset, target_roll, blend)
	camera_yaw_offset = lerpf(camera_yaw_offset, target_yaw, blend)
	camera_pitch_offset = lerpf(camera_pitch_offset, target_pitch, blend)
	_apply_camera_rotation()


func _update_input_filter(delta: float) -> void:
	var raw_input := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var input_blend := 1.0 - exp(-14.0 * delta)
	filtered_input = filtered_input.lerp(raw_input, input_blend)
	var speed := Vector2(velocity.x, velocity.z).length()
	filtered_speed = lerpf(filtered_speed, speed, 1.0 - exp(-10.0 * delta))


func _update_slide_direction(delta: float) -> void:
	var horizontal_velocity := Vector3(velocity.x, 0.0, velocity.z)
	var speed := horizontal_velocity.length()
	var target_world := slide_direction_world
	var target_local := slide_direction_local

	if speed > 0.05:
		target_world = horizontal_velocity / speed
		var local_direction: Vector3 = global_transform.basis.inverse() * target_world
		target_local = Vector2(local_direction.x, -local_direction.z)
		if target_local.length_squared() > 1.0:
			target_local = target_local.normalized()

	if is_sliding:
		var raw_input := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
		var intent_local := Vector2(raw_input.x, -raw_input.y)
		if intent_local.length_squared() > 0.0001:
			target_local = target_local.lerp(intent_local.normalized(), 0.65)
			if target_local.length_squared() > 1.0:
				target_local = target_local.normalized()

	var blend := 1.0 - exp(-14.0 * delta)
	slide_direction_world = slide_direction_world.lerp(target_world, blend).normalized()
	slide_direction_local = slide_direction_local.lerp(target_local, blend)
	if slide_direction_local.length_squared() > 1.0:
		slide_direction_local = slide_direction_local.normalized()
	slide_motion_speed = lerpf(slide_motion_speed, speed, 1.0 - exp(-12.0 * delta))


func _update_stance(delta: float, wants_slide: bool) -> void:
	var target_stance := 1.0 if is_sliding or wants_slide else 0.0
	var blend := 1.0 - exp(-STANCE_RESPONSE * delta)
	stance_amount = lerpf(stance_amount, target_stance, blend)
	var current_height := lerpf(STANDING_HEIGHT, SLIDE_HEIGHT, stance_amount)
	var current_view_height := lerpf(VIEW_HEIGHT, SLIDE_VIEW_HEIGHT, stance_amount)

	if capsule_shape != null:
		capsule_shape.height = current_height
	if collision_shape != null:
		collision_shape.position.y = current_height * 0.5
	if head != null:
		head.position.y = current_view_height


func _apply_camera_rotation() -> void:
	if head == null:
		return
	head.rotation = Vector3(pitch + camera_pitch_offset, camera_yaw_offset, camera_roll_offset)


func _build_body() -> void:
	collision_shape = CollisionShape3D.new()
	capsule_shape = CapsuleShape3D.new()
	capsule_shape.radius = 0.32
	capsule_shape.height = STANDING_HEIGHT
	collision_shape.shape = capsule_shape
	collision_shape.position = Vector3(0.0, STANDING_HEIGHT * 0.5, 0.0)
	add_child(collision_shape)


func _build_camera() -> void:
	head = Node3D.new()
	head.name = "Head"
	head.position = Vector3(0.0, VIEW_HEIGHT, 0.0)
	add_child(head)

	camera = Camera3D.new()
	camera.name = "Camera3D"
	camera.current = true
	camera.keep_aspect = Camera3D.KEEP_HEIGHT
	camera.fov = 105.0
	camera.near = 0.04
	camera.far = 12000.0
	head.add_child(camera)


func _build_player_shadow() -> void:
	player_shadow = PLAYER_SHADOW_SCRIPT.new()
	player_shadow.name = "PlayerShadow"
	add_child(player_shadow)
	_update_player_shadow()


func _update_player_shadow() -> void:
	if player_shadow == null:
		return
	var lift_factor := clampf(global_position.y / 2.0, 0.0, 1.0)
	if not is_on_floor():
		lift_factor = maxf(lift_factor, 0.24)
	var stance_width := lerpf(0.96, 1.12, stance_amount)
	var stance_depth := lerpf(1.16, 1.28, stance_amount)
	var alpha := lerpf(0.34, 0.13, lift_factor)
	player_shadow.update_shadow(global_position, sun_direction, stance_width, stance_depth, alpha, lift_factor)


func trigger_hand_attack(side: float) -> void:
	if side > 0.0:
		if left_attack_age < HAND_ATTACK_COOLDOWN:
			return
		left_attack_age = 0.0
		left_attack_amount = 0.0
		left_attack_impact = 0.0
		attack_recoil = maxf(attack_recoil, 0.45)
	else:
		if right_attack_age < HAND_ATTACK_COOLDOWN:
			return
		right_attack_age = 0.0
		right_attack_amount = 0.0
		right_attack_impact = 0.0
		attack_recoil = maxf(attack_recoil, 0.45)


func _update_hand_attack_state(delta: float) -> void:
	left_attack_age += delta
	right_attack_age += delta

	left_attack_amount = _hand_attack_amount(left_attack_age)
	right_attack_amount = _hand_attack_amount(right_attack_age)
	left_attack_impact = _hand_attack_impact(left_attack_age)
	right_attack_impact = _hand_attack_impact(right_attack_age)

	var target_pitch := -((left_attack_impact + right_attack_impact) * deg_to_rad(HAND_ATTACK_PITCH_DEGREES))
	var target_roll := (left_attack_impact - right_attack_impact) * deg_to_rad(HAND_ATTACK_ROLL_DEGREES)
	attack_pitch_offset = lerpf(attack_pitch_offset, target_pitch, 1.0 - exp(-20.0 * delta))
	attack_roll_offset = lerpf(attack_roll_offset, target_roll, 1.0 - exp(-20.0 * delta))
	attack_recoil = lerpf(attack_recoil, 0.0, 1.0 - exp(-13.0 * delta))


func _hand_attack_amount(age: float) -> float:
	if age < 0.0 or age > HAND_ATTACK_DURATION:
		return 0.0
	var t := age / HAND_ATTACK_DURATION
	if t < HAND_ATTACK_WINDUP:
		return -sin((t / HAND_ATTACK_WINDUP) * PI * 0.5) * 0.26
	if t < HAND_ATTACK_IMPACT_START:
		return lerpf(-0.26, 0.0, (t - HAND_ATTACK_WINDUP) / maxf(HAND_ATTACK_IMPACT_START - HAND_ATTACK_WINDUP, 0.001))
	if t < HAND_ATTACK_IMPACT_END:
		var impact_t := (t - HAND_ATTACK_IMPACT_START) / maxf(HAND_ATTACK_IMPACT_END - HAND_ATTACK_IMPACT_START, 0.001)
		return lerpf(0.0, 1.0, 1.0 - pow(1.0 - impact_t, 2.5))
	var recovery_t := (t - HAND_ATTACK_IMPACT_END) / maxf(HAND_ATTACK_RECOVERY_END - HAND_ATTACK_IMPACT_END, 0.001)
	return lerpf(1.0, 0.0, pow(recovery_t, 1.8))


func _hand_attack_impact(age: float) -> float:
	if age < 0.0 or age > HAND_ATTACK_DURATION:
		return 0.0
	var t := age / HAND_ATTACK_DURATION
	if t < HAND_ATTACK_IMPACT_START or t > HAND_ATTACK_RECOVERY_END:
		return 0.0
	var impact_t := (t - HAND_ATTACK_IMPACT_START) / maxf(HAND_ATTACK_IMPACT_END - HAND_ATTACK_IMPACT_START, 0.001)
	if t <= HAND_ATTACK_IMPACT_END:
		return sin(impact_t * PI) * 1.0
	var recovery_t := (t - HAND_ATTACK_IMPACT_END) / maxf(HAND_ATTACK_RECOVERY_END - HAND_ATTACK_IMPACT_END, 0.001)
	return maxf(0.0, 1.0 - recovery_t)
