# Exact port of Planet Architect's OpenSimplexNoise (Kurt Spencer / A残缺)
class_name OpenSimplexNoise
extends RefCounted

const STRETCH_3D := -1.0 / 6.0
const SQUISH_3D := 1.0 / 3.0
const NORM_3D := 1.0 / 103.0

class Contribution3:
	var dx: float
	var dy: float
	var dz: float
	var xsb: int
	var ysb: int
	var zsb: int
	var next: Contribution3

	func _init(multiplier: float, p_xsb: int, p_ysb: int, p_zsb: int):
		xsb = p_xsb
		ysb = p_ysb
		zsb = p_zsb
		dx = float(-p_xsb) - multiplier * (1.0 / 3.0)
		dy = float(-p_ysb) - multiplier * (1.0 / 3.0)
		dz = float(-p_zsb) - multiplier * (1.0 / 3.0)

static var _gradients3d := PackedFloat64Array([
	-11.0, 4.0, 4.0, -4.0, 11.0, 4.0, -4.0, 4.0, 11.0, 11.0,
	4.0, 4.0, 4.0, 11.0, 4.0, 4.0, 4.0, 11.0, -11.0, -4.0,
	4.0, -4.0, -11.0, 4.0, -4.0, -4.0, 11.0, 11.0, -4.0, 4.0,
	4.0, -11.0, 4.0, 4.0, -4.0, 11.0, -11.0, 4.0, -4.0, -4.0,
	11.0, -4.0, -4.0, 4.0, -11.0, 11.0, 4.0, -4.0, 4.0, 11.0,
	-4.0, 4.0, 4.0, -11.0, -11.0, -4.0, -4.0, -4.0, -11.0, -4.0,
	-4.0, -4.0, -11.0, 11.0, -4.0, -4.0, 4.0, -11.0, -4.0, 4.0,
	-4.0, -11.0
])

static var _lookup3d: Array[Contribution3] = []

static func _static_init() -> void:
	if _lookup3d.size() > 0:
		return

	var array: Array = [
		[0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1],
		[2, 1, 1, 0, 2, 1, 0, 1, 2, 0, 1, 1, 3, 1, 1, 1],
		[1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 2, 1, 1, 0, 2, 1, 0, 1, 2, 0, 1, 1]
	]

	var array2 = PackedInt32Array([
		0, 0, 1, -1, 0, 0, 1, 0, -1, 0,
		0, -1, 1, 0, 0, 0, 1, -1, 0, 0,
		-1, 0, 1, 0, 0, -1, 1, 0, 2, 1,
		1, 0, 1, 1, 1, -1, 0, 2, 1, 0,
		1, 1, 1, -1, 1, 0, 2, 0, 1, 1,
		1, -1, 1, 1, 1, 3, 2, 1, 0, 3,
		1, 2, 0, 1, 3, 2, 0, 1, 3, 1,
		0, 2, 1, 3, 0, 2, 1, 3, 0, 1,
		2, 1, 1, 1, 0, 0, 2, 2, 0, 0,
		1, 1, 0, 1, 0, 2, 0, 2, 0, 1,
		1, 0, 0, 1, 2, 0, 0, 2, 2, 0,
		0, 0, 0, 1, 1, -1, 1, 2, 0, 0,
		0, 0, 1, -1, 1, 1, 2, 0, 0, 0,
		0, 1, 1, 1, -1, 2, 3, 1, 1, 1,
		2, 0, 0, 2, 2, 3, 1, 1, 1, 2,
		2, 0, 0, 2, 3, 1, 1, 1, 2, 0,
		2, 0, 2, 1, 1, -1, 1, 2, 0, 0,
		2, 2, 1, 1, -1, 1, 2, 2, 0, 0,
		2, 1, -1, 1, 1, 2, 0, 0, 2, 2,
		1, -1, 1, 1, 2, 0, 2, 0, 2, 1,
		1, 1, -1, 2, 2, 0, 0, 2, 1, 1,
		1, -1, 2, 0, 2, 0
	])

	var array3 = PackedInt32Array([
		0, 2, 1, 1, 2, 2, 5, 1, 6, 0,
		7, 0, 32, 2, 34, 2, 129, 1, 133, 1,
		160, 5, 161, 5, 518, 0, 519, 0, 546, 4,
		550, 4, 645, 3, 647, 3, 672, 5, 673, 5,
		674, 4, 677, 3, 678, 4, 679, 3, 680, 13,
		681, 13, 682, 12, 685, 14, 686, 12, 687, 14,
		712, 20, 714, 18, 809, 21, 813, 23, 840, 20,
		841, 21, 1198, 19, 1199, 22, 1226, 18, 1230, 19,
		1325, 23, 1327, 22, 1352, 15, 1353, 17, 1354, 15,
		1357, 17, 1358, 16, 1359, 16, 1360, 11, 1361, 10,
		1362, 11, 1365, 10, 1366, 9, 1367, 9, 1392, 11,
		1394, 11, 1489, 10, 1493, 10, 1520, 8, 1521, 8,
		1878, 9, 1879, 9, 1906, 7, 1910, 7, 2005, 6,
		2007, 6, 2032, 8, 2033, 8, 2034, 7, 2037, 6,
		2038, 7, 2039, 6
	])

	var numContribs = array2.size() / 9
	var contribs: Array[Contribution3] = []
	contribs.resize(numContribs)

	for i in range(0, array2.size(), 9):
		var ci = i / 9
		var arr_idx = array2[i]
		var arr5: Array = array[arr_idx]
		var head: Contribution3 = null
		var tail: Contribution3 = null
		for j in range(0, arr5.size(), 4):
			var c = Contribution3.new(
				float(arr5[j]),
				arr5[j + 1],
				arr5[j + 2],
				arr5[j + 3]
			)
			if head == null:
				head = c
			else:
				tail.next = c
			tail = c
		tail.next = Contribution3.new(
			float(array2[i + 1]),
			array2[i + 2],
			array2[i + 3],
			array2[i + 4]
		)
		tail.next.next = Contribution3.new(
			float(array2[i + 5]),
			array2[i + 6],
			array2[i + 7],
			array2[i + 8]
		)
		contribs[ci] = head

	_lookup3d.resize(2048)
	for k in range(0, array3.size(), 2):
		_lookup3d[array3[k]] = contribs[array3[k + 1]]


var perm = PackedByteArray()
var perm3d = PackedByteArray()


func _init(seed_val: int):
	_static_init()
	perm.resize(256)
	perm3d.resize(256)
	var source = PackedByteArray()
	source.resize(256)
	for i in 256:
		source[i] = i

	var s = _seed_to_pair(seed_val)
	s = _next_seed_pair(s)
	s = _next_seed_pair(s)
	s = _next_seed_pair(s)

	for n in range(255, -1, -1):
		s = _next_seed_pair(s)
		var nr = _positive_mod_signed_plus(s, 31, n + 1)
		perm[n] = source[nr]
		perm3d[n] = perm[n] % 24 * 3
		source[nr] = source[n]


static func _seed_to_pair(seed_value: int) -> Array[int]:
	if seed_value < 0:
		return [0xffffffff, seed_value & 0xffffffff]
	return [(seed_value >> 32) & 0xffffffff, seed_value & 0xffffffff]


static func _mul32(a: int, b: int) -> Array[int]:
	var a0 = a & 0xffff
	var a1 = (a >> 16) & 0xffff
	var b0 = b & 0xffff
	var b1 = (b >> 16) & 0xffff
	var p0 = a0 * b0
	var p1 = a0 * b1 + a1 * b0
	var p2 = a1 * b1
	var middle = (p0 >> 16) + (p1 & 0xffff)
	var lo = ((middle & 0xffff) << 16) | (p0 & 0xffff)
	var hi = (p2 + (p1 >> 16) + (middle >> 16)) & 0xffffffff
	return [hi, lo & 0xffffffff]


static func _next_seed_pair(pair: Array[int]) -> Array[int]:
	var a_hi := 0x5851f42d
	var a_lo := 0x4c957f2d
	var c_hi := 0x14057b7e
	var c_lo := 0xf767814f
	var s_hi = pair[0] & 0xffffffff
	var s_lo = pair[1] & 0xffffffff
	var ll = _mul32(s_lo, a_lo)
	var cross_lo = (_mul32(s_lo, a_hi)[1] + _mul32(s_hi, a_lo)[1]) & 0xffffffff
	var out_lo = ll[1]
	var out_hi = (ll[0] + cross_lo) & 0xffffffff
	var added_lo = out_lo + c_lo
	var carry = 1 if added_lo > 0xffffffff else 0
	out_lo = added_lo & 0xffffffff
	out_hi = (out_hi + c_hi + carry) & 0xffffffff
	return [out_hi, out_lo]


static func _pair_mod(pair: Array[int], divisor: int) -> int:
	if divisor <= 1:
		return 0
	var rem = 0
	var chunks = [
		(pair[0] >> 16) & 0xffff,
		pair[0] & 0xffff,
		(pair[1] >> 16) & 0xffff,
		pair[1] & 0xffff,
	]
	for chunk in chunks:
		rem = (rem * 65536 + chunk) % divisor
	return rem


static func _pow2_64_mod(divisor: int) -> int:
	var rem = 1 % divisor
	for i in 64:
		rem = (rem * 2) % divisor
	return rem


static func _positive_mod_signed_plus(pair: Array[int], addend: int, divisor: int) -> int:
	var hi = pair[0] & 0xffffffff
	var lo = pair[1] & 0xffffffff
	var added_lo = lo + addend
	var carry = 1 if added_lo > 0xffffffff else 0
	var plus_pair: Array[int] = [(hi + carry) & 0xffffffff, added_lo & 0xffffffff]
	var rem = _pair_mod(plus_pair, divisor)
	if (plus_pair[0] & 0x80000000) != 0:
		rem = (rem - _pow2_64_mod(divisor)) % divisor
	if rem < 0:
		rem += divisor
	return rem


static func _fast_floor(x: float) -> int:
	var n = int(x)
	if x < float(n):
		return n - 1
	return n


func evaluate(x: float, y: float, z: float) -> float:
	var stretch_offset = (x + y + z) * STRETCH_3D
	var xs = x + stretch_offset
	var ys = y + stretch_offset
	var zs = z + stretch_offset
	var xsb = _fast_floor(xs)
	var ysb = _fast_floor(ys)
	var zsb = _fast_floor(zs)
	var squish_offset = float(xsb + ysb + zsb) * SQUISH_3D
	var dx0 = x - (float(xsb) + squish_offset)
	var dy0 = y - (float(ysb) + squish_offset)
	var dz0 = z - (float(zsb) + squish_offset)
	var xins = xs - float(xsb)
	var yins = ys - float(ysb)
	var zins = zs - float(zsb)
	var in_sum = xins + yins + zins
	var lookup_index = int(yins - zins + 1.0)
	lookup_index |= int(xins - yins + 1.0) << 1
	lookup_index |= int(xins - zins + 1.0) << 2
	lookup_index |= int(in_sum) << 3
	lookup_index |= int(in_sum + zins) << 5
	lookup_index |= int(in_sum + yins) << 7
	lookup_index |= int(in_sum + xins) << 9
	if lookup_index < 0 or lookup_index >= _lookup3d.size():
		return 0.0
	var contribution = _lookup3d[lookup_index]
	var value = 0.0
	while contribution != null:
		var dx = dx0 + contribution.dx
		var dy = dy0 + contribution.dy
		var dz = dz0 + contribution.dz
		var attn = 2.0 - dx * dx - dy * dy - dz * dz
		if attn > 0.0:
			var px = xsb + contribution.xsb
			var py = ysb + contribution.ysb
			var pz = zsb + contribution.zsb
			var gi = int(perm3d[(int(perm[(int(perm[px & 0xff]) + py) & 0xff]) + pz) & 0xff])
			var extrapolation = _gradients3d[gi] * dx + _gradients3d[gi + 1] * dy + _gradients3d[gi + 2] * dz
			attn *= attn
			value += attn * attn * extrapolation
		contribution = contribution.next
	return value * NORM_3D
